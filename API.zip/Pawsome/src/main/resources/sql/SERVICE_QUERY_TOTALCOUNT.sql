 select count(svc.SERVICE_ID) as TOTALCOUNT
 from STUDENT.PS_SERVICE svc
 [where svc.NAME like :LIKE_NAME]