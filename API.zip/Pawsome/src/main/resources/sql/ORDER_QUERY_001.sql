 select *
 from STUDENT.PS_ORDER ORD
 left join STUDENT.PS_COMMCODE CODE 
 on ORD.ORDER_PROCESS = CODE.COMMCODE
 left join STUDENT.PS_CUSTOMER CUS
 on ORD.CUST_EMAIL = CUS.EMAIL
 where CODE.TYPE = 'ORDERPROCESS' 
 order by CODE.COMMCODE, ORD.CONFIRM_DATE
 offset :pageSizeIndex row
 fetch next :pageSize rows only