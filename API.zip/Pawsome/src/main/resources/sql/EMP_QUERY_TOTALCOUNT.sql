select count(EMP.EMAIL) as TOTALCOUNT
 from STUDENT.PS_EMP EMP
 left join STUDENT.PS_COMMCODE CODE 
  on EMP.PERMISSIONS = CODE.COMMCODE
  and CODE.TYPE = 'PERMISSIONS' 
 [where EMP.EMAIL = :request or EMP.NAME = :request or EMP.Tel = :request]