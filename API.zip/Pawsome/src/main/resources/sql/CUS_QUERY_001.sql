 select *
 from STUDENT.PS_CUSTOMER CUS
 order by CUS.EMAIL
 
 offset :pageSizeIndex row
 fetch next :pageSize rows only