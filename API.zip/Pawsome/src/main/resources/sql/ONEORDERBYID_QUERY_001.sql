select *
 from STUDENT.PS_ORDER PO
 left join STUDENT.PS_CUSTOMER PC 
  on PO.CUST_EMAIL = PC.EMAIL
 left join STUDENT.PS_COMMCODE CODE 
  on PO.ORDER_PROCESS = CODE.COMMCODE
  and CODE.TYPE = 'ORDERPROCESS' 
 where PO.ORDER_ID = :rq or PC.NAME = :rq or PC.TEL = :rq
 order by PO.ORDER_ID
 offset :pageSizeIndex row
 fetch next :pageSize rows only
