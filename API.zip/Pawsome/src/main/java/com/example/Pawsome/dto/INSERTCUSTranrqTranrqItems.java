package com.example.Pawsome.dto;

import java.util.Date;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class INSERTCUSTranrqTranrqItems {
    /** email 客戶信箱 */
    @NotBlank
    @Email
    @Size(message = "長度不得超過50", max = 50)
    private String email;

    /** password 客戶密碼 */
    @NotBlank
    @Size(message = "長度不得超過15", max = 15)
    private String password;

    /** name 客戶姓名 */
    @NotBlank
    @Size(message = "長度不得超過20", max = 20)
    private String name;

    /** tel 客戶電話 */
    @NotBlank
    @Size(message = "長度不得超過15", max = 15)
    private String tel;

    /** sex 客戶性別 */
    @Size(message = "長度不得超過", max = 1)
    private String sex;

    /** birthday 客戶 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private String birthday;
}
