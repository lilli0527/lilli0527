package com.example.Pawsome.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class INSERTSERVICETranrsMwheaderServiceId {

    @JsonProperty("serviceId")
    @NotBlank(message = "serviceId 不得為空")
    private int serviceId;
}
