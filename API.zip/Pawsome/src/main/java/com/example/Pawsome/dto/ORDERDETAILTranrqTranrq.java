package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;


@Data
public class ORDERDETAILTranrqTranrq {
    
    /** pageNumber 目前頁碼 */
    @NotNull(message = "目前頁碼不得為空")
    private int pageNumber;

    /** pageSize 每頁筆數 */
    @NotNull(message = "每頁筆數不得為空")
    private int pageSize;
    
    /** orderId 訂單編號 */
	@NotBlank
    @Size(message = "訂單編號長度不得超過20", max = 20)
    private String orderId;
    
}
