package com.example.Pawsome.service;

import java.io.IOException;

import com.example.Pawsome.dto.CARTTranrq;
import com.example.Pawsome.dto.CARTTranrs;
import com.example.Pawsome.dto.CARTrq;
import com.example.Pawsome.dto.CARTrs;
import com.example.Pawsome.dto.DELETECARTTranrq;
import com.example.Pawsome.dto.DELETECARTTranrs;
import com.example.Pawsome.dto.INSERTCARTTranrq;
import com.example.Pawsome.dto.INSERTCARTTranrs;
import com.example.Pawsome.dto.UPDATECARTTranrq;
import com.example.Pawsome.dto.UPDATECARTTranrs;
import com.example.Pawsome.exception.DataDuplicateException;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.DeleteFailException;
import com.example.Pawsome.exception.InsertFailException;
import com.example.Pawsome.exception.UpdateFailException;

/**
 * CartSvc
 * @author 00550176
 *
 */
public interface CartSvc {

    /**
     * 購物車資料查詢服務
     * @param tranrq
     * @return
     * @throws DataNotFoundException
     * @throws IOException 
     */
    public CARTTranrs query(CARTTranrq tranrq) throws DataNotFoundException, IOException;

    /**
     * 購物車資料新增服務
     * @param tranrq
     * @return
     * @throws DataDuplicateException 
     * @throws InsertFailException
     * @throws IOException
     */
    public INSERTCARTTranrs insert(INSERTCARTTranrq tranrq) throws DataDuplicateException, InsertFailException, IOException;

    /**
     * 購物車資料修改服務
     * @param tranrq
     * @return
     * @throws DataNotFoundException 
     * @throws UpdateFailException
     * @throws IOException 
     */
    public UPDATECARTTranrs update(UPDATECARTTranrq tranrq) throws DataNotFoundException, UpdateFailException, IOException;

    /**
     * 購物車資料刪除服務
     * @param tranrq
     * @return
     * @throws DataNotFoundException
     * @throws DeleteFailException
     * @throws IOException 
     */
    public DELETECARTTranrs delete(DELETECARTTranrq tranrq) throws DataNotFoundException, DeleteFailException, IOException;

    /**
     * 當送出訂單，查找會員及itemId後將isSubmit改為y
     * @param custEmail
     * @param itemId
     */
    public void markItemsAsSubmitted(String custEmail, String itemId);
    
	
    public CARTrs calendar(CARTrq tranrq) throws DataNotFoundException, IOException;

}
