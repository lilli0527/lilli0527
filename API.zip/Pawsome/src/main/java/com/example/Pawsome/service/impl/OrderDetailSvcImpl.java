package com.example.Pawsome.service.impl;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.dto.ONEORDERDETAILTranrq;
import com.example.Pawsome.dto.ONEORDERDETAILTranrqTranrq;
import com.example.Pawsome.dto.ONEORDERDETAILTranrs;
import com.example.Pawsome.dto.ONEORDERDETAILTranrsTranrs;
import com.example.Pawsome.dto.ONEORDERDETAILTranrsTranrsItems;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.repository.PsOrderDetailEntityRepository;
import com.example.Pawsome.service.OrderDetailSvc;
import com.example.Pawsome.service.sql.SqlAction;
import com.example.Pawsome.service.sql.SqlUtils;

@Service
public class OrderDetailSvcImpl implements OrderDetailSvc {

    /** SqlAction */
    @Autowired
    private SqlAction sqlAction;

    /** SqlUtils */
    @Autowired
    private SqlUtils sqlUtils;

    @Autowired
    private PsOrderDetailEntityRepository orderDetailRepo;

    /** ONEORDERDETAIL 訂單細項資料查詢服務 */
    private static final String ONEORDERDETAIL = "PAWSOME-ONEORDERDETAIL";

    /** 交易成功代碼 */
    private static final String SUCCESSCODE = ReturnCodeAndDescEnum.SUCCESS.getCode();

    /** 交易成功訊息 */
    private static final String SUCCESSDESC = ReturnCodeAndDescEnum.SUCCESS.getDesc();

    /** 查無資料代碼 */
    private static final String DATANOTFOUND = "E702";

    /** SQL_ORDERDETAIL */
    private static final String SQL_ONEORDERDETAIL = "ONEORDERDETAIL_QUERY_001.sql";

    /**
     * 判斷是否為空值
     * 
     * @param param
     * @return
     */
    private String isNull(Object param) {
        if (param != null) {
            return param.toString();
        }
        return null;
    }

    /** queryOneOrderDetail 單筆訂單細項資料查詢服務 */
    @Override
    public ONEORDERDETAILTranrs queryOneOrderDetail(ONEORDERDETAILTranrq request) throws DataNotFoundException, IOException {
        ONEORDERDETAILTranrqTranrq requestData = request.getTranrq();
        String orderId = request.getTranrq().getOrderId();
        String itemId = request.getTranrq().getItemId();
        // 當前頁數
        int pageNumber = requestData.getPageNumber();
        // 顯示筆數
        int pageSize = requestData.getPageSize();
        // 顯示筆數的 Index
        int pageSizeIndex = pageNumber * pageSize;

        Map<String, Object> mapQueryOrderDetail = new HashMap<>();
        mapQueryOrderDetail.put("orderId", orderId);
        mapQueryOrderDetail.put("itemId", itemId);
        mapQueryOrderDetail.put("pageSizeIndex", pageSizeIndex);
        mapQueryOrderDetail.put("pageSize", pageSize);
        String querySql = sqlUtils.getDynamicQuerySQL(SQL_ONEORDERDETAIL, mapQueryOrderDetail);
        List<Map<String, Object>> queryEntitys = sqlAction.queryForList(querySql, mapQueryOrderDetail);

        // 總筆數
        int totalCount = queryEntitys.size();
        int totalPage = (int) Math.ceil(totalCount / pageSize);

        if (queryEntitys.isEmpty()) {
            throw new DataNotFoundException(ONEORDERDETAIL, DATANOTFOUND);
        }

        List<ONEORDERDETAILTranrsTranrsItems> itemsList = new ArrayList<>();
        for (Map<String, Object> queryEntity : queryEntitys) {
            ONEORDERDETAILTranrsTranrsItems items = new ONEORDERDETAILTranrsTranrsItems();
            items.setServiceName(queryEntity.get("SERVICE_NAME").toString());
            items.setStartDate(queryEntity.get("START_DATE").toString());
            items.setEndDate(isNull(queryEntity.get("END_DATE")));
            items.setStartTime(queryEntity.get("START_TIME").toString());
            items.setPetId(queryEntity.get("PET_ID").toString());
            items.setPetName(queryEntity.get("PET_NAME").toString());
            items.setPetType(queryEntity.get("PET_TYPE").toString());
            items.setRemarks(isNull(queryEntity.get("REMARKS")));

            TimeUnit time = TimeUnit.DAYS;
            long duration;
            if (queryEntity.get("END_DATE") == null) {
                items.setPrice(String.valueOf(queryEntity.get("PRICE")));
            } else if (queryEntity.get("END_DATE").equals(queryEntity.get("START_DATE"))) {
                duration = TimeUnit.HOURS.toMillis(24);
                items.setPrice(String
                        .valueOf(Long.parseLong(String.valueOf(queryEntity.get("PRICE"))) * time.convert(duration, TimeUnit.MILLISECONDS)));
            } else {
                duration = Date.valueOf(queryEntity.get("END_DATE").toString().split(" ")[0]).getTime()
                        - Date.valueOf(queryEntity.get("START_DATE").toString().split(" ")[0]).getTime();
                items.setPrice(String
                        .valueOf(Long.parseLong(String.valueOf(queryEntity.get("PRICE"))) * time.convert(duration, TimeUnit.MILLISECONDS)));
            }

            if (queryEntity.get("END_DATE") == null) {
                items.setPrice(String.valueOf(queryEntity.get("PRICE")));
            } else if (queryEntity.get("END_DATE").equals(queryEntity.get("START_DATE"))) {
                duration = TimeUnit.HOURS.toMillis(24);
                items.setPrice(String
                        .valueOf(Long.parseLong(String.valueOf(queryEntity.get("PRICE"))) * time.convert(duration, TimeUnit.MILLISECONDS)));
            } else {
                duration = Date.valueOf(queryEntity.get("END_DATE").toString().split(" ")[0]).getTime()
                        - Date.valueOf(queryEntity.get("START_DATE").toString().split(" ")[0]).getTime();
                items.setPrice(String
                        .valueOf(Long.parseLong(String.valueOf(queryEntity.get("PRICE"))) * time.convert(duration, TimeUnit.MILLISECONDS)));
            }

            items.setOrderProcess(queryEntity.get("MSG").toString());
            items.setUpdateEmp(isNull(queryEntity.get("EMP_NAME")));
            items.setUpdateTime(isNull(queryEntity.get("UPDATE_TIME")));
            itemsList.add(items);
        }

        ONEORDERDETAILTranrsTranrs oneOrderDetailTranrsTranrs = new ONEORDERDETAILTranrsTranrs();
        oneOrderDetailTranrsTranrs.setTotalPage(totalPage);
        oneOrderDetailTranrsTranrs.setTotalCount(totalCount);
        oneOrderDetailTranrsTranrs.setPageNumber(pageNumber);
        oneOrderDetailTranrsTranrs.setPageSize(pageSize);
        oneOrderDetailTranrsTranrs.setItems(itemsList);

        TranrsMwheader oneOrderDetailTranrsMwheader = new TranrsMwheader();
        oneOrderDetailTranrsMwheader.setMsgid(ONEORDERDETAIL);
        oneOrderDetailTranrsMwheader.setReturnCode(SUCCESSCODE);
        oneOrderDetailTranrsMwheader.setReturnDesc(SUCCESSDESC);

        ONEORDERDETAILTranrs oneOrderDetailTranrs = new ONEORDERDETAILTranrs();
        oneOrderDetailTranrs.setMwheader(oneOrderDetailTranrsMwheader);
        oneOrderDetailTranrs.setTranrs(oneOrderDetailTranrsTranrs);

        return oneOrderDetailTranrs;
    }
}
