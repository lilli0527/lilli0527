package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ONESERVICETranrsMwheaderTranrs {

    @Valid
    @JsonProperty("datas")
    private List<ONESERVICETranrsMwheaderTranrsDatas> Datas;
}
