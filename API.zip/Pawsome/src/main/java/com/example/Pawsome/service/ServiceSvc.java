package com.example.Pawsome.service;

import com.example.Pawsome.dto.DELETESERVICETranrq;
import com.example.Pawsome.dto.INSERTSERVICETranrq;
import com.example.Pawsome.dto.INSERTSERVICETranrs;
import com.example.Pawsome.dto.ONESERVICETranrq;
import com.example.Pawsome.dto.ONESERVICETranrs;
import com.example.Pawsome.dto.SERVICEALLTranrq;
import com.example.Pawsome.dto.SERVICEALLTranrs;
import com.example.Pawsome.dto.SERVICEDETAILTranrq;
import com.example.Pawsome.dto.SERVICEDETAILTranrs;
import com.example.Pawsome.dto.SERVICETranrq;
import com.example.Pawsome.dto.SERVICETranrs;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.dto.UPDATESERVICETranrq;
import com.example.Pawsome.exception.DataNotFoundException;

public interface ServiceSvc {

    SERVICETranrs serviceByTypeAndIsAvaliable(SERVICETranrq request) throws DataNotFoundException, Exception;

    SERVICEDETAILTranrs serviceByName(SERVICEDETAILTranrq request) throws DataNotFoundException, Exception;

    ONESERVICETranrs serviceByNameFuzzyAndIsAvaliable(ONESERVICETranrq request) throws DataNotFoundException, Exception;

    TranrsMwheader updateService(UPDATESERVICETranrq request) throws DataNotFoundException, Exception;

    TranrsMwheader deleteService(DELETESERVICETranrq request) throws DataNotFoundException, Exception;

    INSERTSERVICETranrs insertService(INSERTSERVICETranrq request) throws Exception;

    SERVICEALLTranrs serviceAll(SERVICEALLTranrq request) throws DataNotFoundException, Exception;
}
