package com.example.Pawsome.dto;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@Data
public class UPDATEORDERDETAILTranrs {
    
    /** MWHEADER */
    @JsonProperty("MWHEADER")
    @Valid
    private TranrsMwheader mwheader;

    /** TRANRS */
    @JsonProperty("TRANRS")
    @Valid
    private Object tranrs;

}
