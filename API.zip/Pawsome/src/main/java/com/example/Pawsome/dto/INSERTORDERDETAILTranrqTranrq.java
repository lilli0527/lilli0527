package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.Valid;

import lombok.Data;

@Data
public class INSERTORDERDETAILTranrqTranrq {

    /** List<INSERTORDERDETAILTranrqTranrqItems> */
    @Valid
    private List<INSERTORDERDETAILTranrqTranrqItems> items;
    
}
