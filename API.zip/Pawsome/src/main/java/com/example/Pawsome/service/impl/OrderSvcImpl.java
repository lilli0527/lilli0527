package com.example.Pawsome.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.dto.INSERTORDERTranrq;
import com.example.Pawsome.dto.INSERTORDERTranrqTranrq;
import com.example.Pawsome.dto.INSERTORDERTranrqTranrqItems;
import com.example.Pawsome.dto.INSERTORDERTranrs;
import com.example.Pawsome.dto.INSERTORDERTranrsTranrs;
import com.example.Pawsome.dto.ORDERBYCUSTOMERRq;
import com.example.Pawsome.dto.ORDERBYCUSTOMERRs;
import com.example.Pawsome.dto.ORDERBYCUSTOMERTranrsItems;
import com.example.Pawsome.dto.ORDERTranrq;
import com.example.Pawsome.dto.ORDERTranrqTranrq;
import com.example.Pawsome.dto.ORDERTranrs;
import com.example.Pawsome.dto.ORDERTranrsTranrs;
import com.example.Pawsome.dto.ORDERTranrsTranrsItems;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.dto.UPDATEORDERRq;
import com.example.Pawsome.dto.UPDATEORDERRs;
import com.example.Pawsome.dto.UPDATEORDERTranrq;
import com.example.Pawsome.entity.PsCommCodeEntity;
import com.example.Pawsome.entity.PsOrderDetailEntity;
import com.example.Pawsome.entity.PsOrderEntity;
import com.example.Pawsome.entity.PsShoppingCartEntity;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.InsertFailException;
import com.example.Pawsome.repository.PsCommCodeEntityRepository;
import com.example.Pawsome.repository.PsEmpEntityRepository;
import com.example.Pawsome.repository.PsOrderDetailEntityRepository;
import com.example.Pawsome.repository.PsOrderEntityRepository;
import com.example.Pawsome.repository.PsShoppingCartEntityRepository;
import com.example.Pawsome.service.CartSvc;
import com.example.Pawsome.service.OrderSvc;
import com.example.Pawsome.service.sql.SqlAction;
import com.example.Pawsome.service.sql.SqlUtils;

@Service
public class OrderSvcImpl implements OrderSvc {

	/** PsOrderEntityRepository */
	/** SqlAction */
	@Autowired
	private SqlAction sqlAction;

	/** SqlUtils */
	@Autowired
	private SqlUtils sqlUtils;

	@Autowired
	private PsOrderEntityRepository orderRepo;

	@Autowired
	private PsOrderDetailEntityRepository orderDetailRepo;

	/** PsOrderDetailEntityRepository */
	@Autowired
	private PsOrderDetailEntityRepository detailRepo;

	/** CartSvc */
	@Autowired
	private CartSvc cartSvc;

	/** PsCommCodeEntityRepository */
	@Autowired
	private PsCommCodeEntityRepository commCodeRepo;

	/** ReturnCodeAndDescEnum.SUCCESS */
	ReturnCodeAndDescEnum success = ReturnCodeAndDescEnum.SUCCESS;

	/** UPDATEORDERDETAIL 訂單細項資料修改服務 */
	private static final String UPDATEORDERDETAIL = "PAWSOME-UPDATEORDERDETAIL";

	/** 更新失敗代碼 */
	private static final String UPDATEFAIL = "E002";

	/** SQL_ORDERDETAIL_2 */
	private static final String SQL_ORDERDETAIL_2 = "ORDERDETAIL_QUERY_002.sql";

	@Override
	public UPDATEORDERRs updateOrder(UPDATEORDERRq tranrq) throws DataNotFoundException, IOException {
		UPDATEORDERTranrq dataEntity = tranrq.getTranrq();
		String orderId = dataEntity.getOrderId();

		// 根據訂單ID查詢資料
		Optional<PsOrderEntity> petsWithEmail = orderRepo.findById(orderId);
		if (petsWithEmail.isPresent()) {
			PsOrderEntity entity = new PsOrderEntity();
			entity.setOrderId(orderId);
			entity.setCustEmail(dataEntity.getCustEmail());
			entity.setTotal(dataEntity.getTotal());
			entity.setOrderProcess(dataEntity.getOrderProcess());
			entity.setConfirmDate(Date.valueOf(LocalDate.now()));
			orderRepo.save(entity);

			// 如果取消訂單，將其訂單明細的訂單狀態全部改為 "已取消"
			Map<String, Object> mapQueryOrderDetail = new HashMap<>();
			mapQueryOrderDetail.put("orderId", orderId);
			String queryOrderDetailSql = sqlUtils.getDynamicQuerySQL(SQL_ORDERDETAIL_2, mapQueryOrderDetail);
			List<Map<String, Object>> queryOrderDetailEntitys = sqlAction.queryForList(queryOrderDetailSql,
					mapQueryOrderDetail);

			for (Map<String, Object> queryEntity : queryOrderDetailEntitys) {
				String itemId = queryEntity.get("ITEM_ID").toString();
				Optional<PsOrderDetailEntity> orderDetailEtityOptional = orderDetailRepo.findByOrderIdAndItemId(orderId, itemId);

				if (!orderDetailEtityOptional.isPresent()) {
					throw new DataNotFoundException(UPDATEORDERDETAIL, UPDATEFAIL);
				}

				// 更新特定訂單細項訂單狀態為 "已取消"
				PsOrderDetailEntity updateOrderDetailEtity = orderDetailEtityOptional.get();
				updateOrderDetailEtity.setOrderProcess("3");;
				orderDetailRepo.save(updateOrderDetailEtity);
			}

			// 返回成功的回應
			TranrsMwheader mwheader = new TranrsMwheader();
			UPDATEORDERRs rs = new UPDATEORDERRs();
			mwheader.setMsgid("PAWSOME-UPDATEORDER");
			ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
			mwheader.setReturnCode(traSuccess.getCode());
			mwheader.setReturnDesc(traSuccess.getDesc());
			rs.setMwheader(mwheader);
			return rs;
		}
		ReturnCodeAndDescEnum traDataNotFound = ReturnCodeAndDescEnum.DATA_NOT_FOUND;
		throw new DataNotFoundException("PAWSOME-UPDATEORDER", traDataNotFound.getCode());
	}

	/**
	 * 訂單資料新增服務
	 */
	@Override
	@Transactional
	public INSERTORDERTranrs insert(INSERTORDERTranrq tranrq) throws InsertFailException, IOException {
		INSERTORDERTranrqTranrq tranrqTranrq = tranrq.getRqTranrq();
		List<INSERTORDERTranrqTranrqItems> itemsList = tranrqTranrq.getItems();
		List<PsOrderEntity> orderEntities = new ArrayList<>();
		List<PsOrderDetailEntity> detailEntities = new ArrayList<>();
		Random random = new Random();
		String randomNum = String.valueOf(String.format("%05d", random.nextInt(100000)));
		String orderId = getformattedOrderId() + randomNum;
		int total = 0;
		for (INSERTORDERTranrqTranrqItems items : itemsList) {
			PsOrderEntity orderEntity = new PsOrderEntity();
			orderEntity.setCustEmail(items.getCustEmail());
			orderEntity.setOrderId(orderId);
			total += Integer.valueOf(items.getServiceTotalPrice());
			orderEntity.setTotal(total);
			orderEntity.setOrderProcess(items.getOrderProcess());
			orderEntity.setConfirmDate(formatDate(items.getConfirmDate()));
			orderEntities.add(orderEntity);
			PsOrderDetailEntity detailEntity = new PsOrderDetailEntity();
			detailEntity.setOrderId(orderId);
			detailEntity.setItemId(items.getItemId());
			detailEntity.setOrderProcess(items.getOrderProcess());
			detailEntity.setUpdateTime(formatDate(items.getConfirmDate()));
			detailEntities.add(detailEntity);
			cartSvc.markItemsAsSubmitted(items.getCustEmail(), items.getItemId());
		}
		try {
			orderRepo.saveAll(orderEntities);
			detailRepo.saveAll(detailEntities);
		} catch (Exception e) {
			throw new InsertFailException("INSERTORDER", "E003");
		}
		INSERTORDERTranrsTranrs tranrsTranrs = new INSERTORDERTranrsTranrs();
		tranrsTranrs.setOrderId(orderId);
		TranrsMwheader mwheader = new TranrsMwheader();
		mwheader.setMsgid(tranrq.getRqMwheader().getMsgid());
		mwheader.setReturnCode(success.getCode());
		mwheader.setReturnDesc(success.getDesc());
		INSERTORDERTranrs tranrs = new INSERTORDERTranrs();
		tranrs.setRsMwheader(mwheader);
		tranrs.setRsTranrs(tranrsTranrs);
		return tranrs;
	}

	/**
	 * 取得以當下日期時間作為訂單編號前綴yyyyMMddHHmmss
	 * 
	 * @return
	 */
	public static final String getformattedOrderId() {
		return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
	}

	/**
	 * 將String轉為Date
	 * 
	 * @param date
	 * @return
	 */
	public Date formatDate(String date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate localDate = LocalDate.parse(date, formatter);
		return Date.valueOf(localDate);
	}

	/** EMP 員工資料查詢服務 */
	private static final String ORDER = "PAWSOME-ORDER";

	/** 交易成功代碼 */
	private static final String SUCCESSCODE = ReturnCodeAndDescEnum.SUCCESS.getCode();

	/** 交易成功訊息 */
	private static final String SUCCESSDESC = ReturnCodeAndDescEnum.SUCCESS.getDesc();

	/** 查無資料 */
	private static final String DATANOTFOUND = "E702";

	/** SQL_CUS */
	private static final String SQL_ORDER_TOTALCOUNT = "ORDER_QUERY_TOTALCOUNT.sql";

	/** SQL_CUS */
	private static final String SQL_ORD = "ORDER_QUERY_001.sql";

	@Override
	public ORDERTranrs order(ORDERTranrq request) throws DataNotFoundException, IOException {
		ORDERTranrqTranrq requestData = request.getTranrq();
		// 總筆數
		Map<String, Object> mapTotalCount = new HashMap<>();

		String queryTotalCountSql = sqlUtils.getDynamicQuerySQL(SQL_ORDER_TOTALCOUNT, mapTotalCount);

		List<Map<String, Object>> queryTotalCountEntity = sqlAction.queryForList(queryTotalCountSql, mapTotalCount);

		// 當前頁數
		int pageNumber = requestData.getPageNumber();

		// 顯示筆數
		int pageSize = (int) requestData.getPageSize();

		// 顯示筆數的 Index
		int pageSizeIndex = pageNumber * pageSize;

		// 總筆數
		double totalCount = ((BigDecimal) queryTotalCountEntity.get(0).get("TOTALCOUNT")).intValue();

		// 總頁數 (無條件進位)
		int totalPage = (int) Math.ceil(totalCount / pageSize);

		Map<String, Object> mapQueryORD = new HashMap<>();

		mapQueryORD.put("pageSizeIndex", pageSizeIndex);
		mapQueryORD.put("pageSize", pageSize);

		String querySql = sqlUtils.getDynamicQuerySQL(SQL_ORD, mapQueryORD);
		List<Map<String, Object>> queryEntitys = sqlAction.queryForList(querySql, mapQueryORD);

		if (queryEntitys.isEmpty()) {
			throw new DataNotFoundException(ORDER, DATANOTFOUND);
		}

		List<ORDERTranrsTranrsItems> itemsList = new ArrayList<>();
		for (Map<String, Object> queryEntity : queryEntitys) {
			ORDERTranrsTranrsItems items = new ORDERTranrsTranrsItems();
			items.setOrderId(queryEntity.get("ORDER_ID").toString());
			items.setCustEmail(queryEntity.get("CUST_EMAIL").toString());
			items.setConfirmDate(queryEntity.get("CONFIRM_DATE").toString());
			items.setCustName(queryEntity.get("NAME").toString());
			items.setCustTel(queryEntity.get("TEL").toString());
			items.setOrderProcess(queryEntity.get("MSG").toString());
			items.setTotal(Integer.valueOf(queryEntity.get("TOTAL").toString()));
			itemsList.add(items);
		}

		ORDERTranrsTranrs orderTranrsTranrs = new ORDERTranrsTranrs();
		orderTranrsTranrs.setOrderNumber(totalCount);
		orderTranrsTranrs.setPageNumber(pageNumber);
		orderTranrsTranrs.setPageSize(pageSize);
		orderTranrsTranrs.setTotalPage(totalPage);
		orderTranrsTranrs.setItems(itemsList);

		TranrsMwheader OrdTranrsMwheader = new TranrsMwheader();
		OrdTranrsMwheader.setMsgid(ORDER);
		OrdTranrsMwheader.setReturnCode(SUCCESSCODE);
		OrdTranrsMwheader.setReturnDesc(SUCCESSDESC);
		ORDERTranrs tranrs = new ORDERTranrs();
		tranrs.setTranrs(orderTranrsTranrs);
		tranrs.setMwheader(OrdTranrsMwheader);
		return tranrs;
	}

	/** 會員管理裡面的預約管理清單 */
	@Override
	public ORDERBYCUSTOMERRs orderByCustomer(ORDERBYCUSTOMERRq tranrq) throws DataNotFoundException {
		String custEmail = tranrq.getTranrq().getCustEmail();
		// 根據 custEmail 查詢資料
		List<PsOrderEntity> ordersWithEmail = orderRepo.findByCustEmail(custEmail);
		if (ordersWithEmail.isEmpty()) {
			throw new DataNotFoundException("PAWSOME-ORDERBYCUSTOMER", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
		}
		List<ORDERBYCUSTOMERTranrsItems> datas = new ArrayList<>();
		// 查出來的Data全部變成data並存進List裡
		for (PsOrderEntity order : ordersWithEmail) {
			ORDERBYCUSTOMERTranrsItems data = new ORDERBYCUSTOMERTranrsItems();
			data.setOrderId(order.getOrderId());
			data.setCustEmail(order.getCustEmail());
			data.setTotal(String.valueOf(order.getTotal()));
			PsCommCodeEntity dataComm = commCodeRepo.findByTypeAndCommCode("ORDERPROCESS", order.getOrderProcess())
					.get();
			data.setOrderProcess(dataComm.getMsg());
			data.setConfirmDate(order.getConfirmDate().toString());
			datas.add(data);
		}

		// 返回成功的回應
		TranrsMwheader mwheader = new TranrsMwheader();
		ORDERBYCUSTOMERRs rs = new ORDERBYCUSTOMERRs();
		mwheader.setMsgid("PAWSOME-ONEPETBYCUSTOMER");
		ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
		mwheader.setReturnCode(traSuccess.getCode());
		mwheader.setReturnDesc(traSuccess.getDesc());
		rs.setMwheader(mwheader);
		rs.setTranrs(datas);
		return rs;
	}

}
