package com.example.Pawsome.dto;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DELETEPETRs {
	/** MWHEADER */
    @JsonProperty("MWHEADER")
    @Valid
    private TranrsMwheader mwheader;

    /** TRANRS */
    @JsonProperty("TRANRS")
    private Empty empty;
}
