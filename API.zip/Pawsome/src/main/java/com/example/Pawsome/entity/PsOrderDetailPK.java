package com.example.Pawsome.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;

@Data
@Embeddable
public class PsOrderDetailPK implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "ORDER_ID")
    private String orderId;

    @Column(name = "ITEM_ID")
    private String itemId;

}
