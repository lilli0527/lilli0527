package com.example.Pawsome.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.dto.ADMINTranrq;
import com.example.Pawsome.dto.ADMINTranrs;
import com.example.Pawsome.dto.EMPTranrq;
import com.example.Pawsome.dto.EMPTranrs;
import com.example.Pawsome.dto.INSERTEMPTranrq;
import com.example.Pawsome.dto.INSERTEMPTranrs;
import com.example.Pawsome.dto.LOGINEMPTranrq;
import com.example.Pawsome.dto.LOGINEMPTranrs;
import com.example.Pawsome.dto.ONEORDERBYIDTranrq;
import com.example.Pawsome.dto.ONEORDERBYIDTranrs;
import com.example.Pawsome.dto.ORDERDETAILTranrq;
import com.example.Pawsome.dto.ORDERDETAILTranrs;
import com.example.Pawsome.dto.UPDATEEMPTranrq;
import com.example.Pawsome.dto.UPDATEEMPTranrs;
import com.example.Pawsome.dto.UPDATEORDERDETAILTranrq;
import com.example.Pawsome.dto.UPDATEORDERDETAILTranrs;
import com.example.Pawsome.exception.DataDuplicateException;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.ErrorInputException;
import com.example.Pawsome.exception.PasswordException;
import com.example.Pawsome.service.EmpSvc;

@RestController
@CrossOrigin("http://localhost:4200")
public class EmpController {

    @Autowired
    private EmpSvc empSvc;

    /** EMP 員工資料查詢服務(單多筆) */
    private static final String EMP = "PAWSOME-EMP";

    /** UPDATEEMP 員工資料修改服務 */
    private static final String UPDATEEMP = "PAWSOME-UPDATEEMP";

    /** INSERTEMP 員工資料新增服務 */
    private static final String INSERTEMP = "PAWSOME-INSERTEMP";
    
    /** ADMIN 最高權限員工資料查詢服務 */
    private static final String ADMIN = "PAWSOME-ADMIN";

    /** ONEORDERBYID 單筆訂單查詢服務 */
    private static final String ONEORDERBYID = "PAWSOME-ONEORDERBYID";

    /** ORDERDETAIL 訂單細項資料查詢服務 */
    private static final String ORDERDETAIL = "PAWSOME-ORDERDETAIL";

    /** UPDATEORDERDETAIL 訂單細項資料修改服務 */
    private static final String UPDATEORDERDETAIL = "PAWSOME-UPDATEORDERDETAIL";

    /** LOGIN 員工登入查詢服務 */
    private static final String LOGINEMP = "PAWSOME-loginCustomer";

    /** 必填欄位不完整 */
    private static final String ERRORINPUT = "E001";

    /**
     * queryEmp
     * 員工資料查詢服務(單多筆) PAWSOME-EMP
     * @param request
     * @param errors
     * @return
     * @throws ErrorInputException
     * @throws DataNotFoundException
     * @throws IOException
     */
    @PostMapping(value = "/emp")
    public EMPTranrs queryEmp(@Valid
    @RequestBody
    EMPTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException, IOException {
        // 檢查上行 Errors 是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException(EMP + sb, ERRORINPUT);
        }
        return empSvc.queryEmp(request);
    }

    /**
    * updateEmp
    * 員工資料修改服務 PAWSOME-UPDATEEMP
    * @param request
    * @param errors
    * @return
    * @throws ErrorInputException
    * @throws DataNotFoundException
    */
    @PostMapping(value = "/updateEmp")
    public UPDATEEMPTranrs updateEmp(@Valid
    @RequestBody
    UPDATEEMPTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException {
        // 檢查上行 Errors 是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException(UPDATEEMP + sb, ERRORINPUT);
        }
        return empSvc.updateEmp(request);
    }

    /**
     * insertEmp
     * 員工資料新增服務 PAWSOME-INSERTEMP
     * @param request
     * @param errors
     * @return
     * @throws ErrorInputException
     * @throws DataDuplicateException
     */
    @PostMapping(value = "/insertEmp")
    public INSERTEMPTranrs insertEmp(@Valid
    @RequestBody
    INSERTEMPTranrq request, Errors errors) throws ErrorInputException, DataDuplicateException {
        // 檢查上行 Errors 是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException(INSERTEMP + sb, ERRORINPUT);
        }
        return empSvc.insertEmp(request);
    }
    
    /**
     * queryAdmin
     * 最高權限員工資料查詢服務 PAWSOME-ADMIN
     * @param request
     * @param errors
     * @return
     * @throws ErrorInputException
     * @throws DataNotFoundException
     */
    @PostMapping(value = "/admin")
    public ADMINTranrs queryAdmin(@Valid
    @RequestBody
    ADMINTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException {
        // 檢查上行 Errors 是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException(ADMIN + sb, ERRORINPUT);
        }
        return empSvc.queryAdmin(request);
    }

    /**
     * queryOrderByID
     * 單筆訂單資料查詢服務 PAWSOME-ONEORDERBYID
     * @param request
     * @param errors
     * @return
     * @throws ErrorInputException
     * @throws DataNotFoundException
     * @throws IOException
     */
    @PostMapping(value = "/oneOrderById")
    public ONEORDERBYIDTranrs queryOrderByID(@Valid
    @RequestBody
    ONEORDERBYIDTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException, IOException {
        // 檢查上行 Errors 是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException(ONEORDERBYID + sb, ERRORINPUT);
        }
        return empSvc.queryOrderByID(request);
    }

    /**
     * queryOrderDetail
     * 訂單細項資料查詢服務 PAWSOME-ORDERDETAIL
     * @param request
     * @param errors
     * @return
     * @throws ErrorInputException
     * @throws DataNotFoundException
     * @throws IOException
     */
    @PostMapping(value = "/orderDetail")
    public ORDERDETAILTranrs queryOrderDetail(@Valid
    @RequestBody
    ORDERDETAILTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException, IOException {
        // 檢查上行 Errors 是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException(ORDERDETAIL + sb, ERRORINPUT);
        }
        return empSvc.queryOrderDetail(request);
    }

    /**
     * updateOrderDetail
     * 訂單細項資料修改服務 PAWSOME-UPDATEORDERDETAIL
     * @param request
     * @param errors
     * @return
     * @throws ErrorInputException
     * @throws DataNotFoundException
     * @throws IOException
     */
    @PostMapping(value = "/updateOrderDetail")
    public UPDATEORDERDETAILTranrs updateOrderDetail(@Valid
    @RequestBody
    UPDATEORDERDETAILTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException, IOException {
        // 檢查上行 Errors 是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException(UPDATEORDERDETAIL + sb, ERRORINPUT);
        }
        return empSvc.updateOrderDetail(request);
    }

    @PostMapping(value = "loginEmp")
    public LOGINEMPTranrs loginEmp(@Valid
    @RequestBody
    LOGINEMPTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException, PasswordException {
        if (errors.hasErrors()) {
            throw new ErrorInputException(LOGINEMP, ERRORINPUT);
        }
        return empSvc.loginEmp(request);
    }

}
