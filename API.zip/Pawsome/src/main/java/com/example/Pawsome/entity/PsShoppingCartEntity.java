package com.example.Pawsome.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonAlias;

import lombok.Data;

@Data
@Entity
@Table(name = "PS_SHOPPING_CART")
public class PsShoppingCartEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @NotBlank
    @JsonAlias("ITEM_ID")
    @Column(name = "ITEM_ID")
    private String itemId;

    @NotBlank
    @JsonAlias("CUST_EMAIL")
    @Column(name = "CUST_EMAIL")
    private String custEmail;

    @NotNull
    @JsonAlias("SERVICE_ID")
    @Column(name = "SERVICE_ID")
    private int serviceId;

    @NotNull
    @JsonAlias("START_DATE")
    @Column(name = "START_DATE")
    private Date startDate;

    @JsonAlias("END_DATE")
    @Column(name = "END_DATE")
    private Date endDate;

    @NotBlank
    @JsonAlias("START_TIME")
    @Column(name = "START_TIME")
    private String startTime;

    @NotNull
    @JsonAlias("PET_ID")
    @Column(name = "PET_ID")
    private int petId;

    @JsonAlias("REMARKS")
    @Column(name = "REMARKS")
    private String remarks;

    @NotBlank
    @JsonAlias("ISSUBMIT")
    @Column(name = "ISSUBMIT")
    private String isSubmit;

}
