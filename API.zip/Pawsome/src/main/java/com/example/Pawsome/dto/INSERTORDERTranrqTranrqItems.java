package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class INSERTORDERTranrqTranrqItems {

    /** 會員信箱 */
    @NotBlank(message = "請登入/註冊會員")
    @Size(message = "會員信箱長度不得超過70", max = 70)
    private String custEmail;

    /** 單筆購物車ID */
    @NotBlank(message = "單筆購物車ID不得為空")
    @Size(message = "單筆購物車ID長度不得超過20", max = 20)
    private String itemId;

    /** 服務總金額 */
    @NotBlank(message = "服務總金額不得為空")
    @Size(message = "服務總金額長度不得超過20", max = 20)
    private String serviceTotalPrice;

    /** 訂單狀態 */
    @NotBlank(message = "訂單狀態不得為空")
    @Size(message = "訂單狀態長度不得超過5", max = 5)
    private String orderProcess;

    /** 訂單確認日期 */
    @NotBlank(message = "訂單確認日期不得為空")
    private String confirmDate;

}
