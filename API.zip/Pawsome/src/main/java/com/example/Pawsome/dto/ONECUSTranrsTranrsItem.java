package com.example.Pawsome.dto;

import java.util.Date;

import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class ONECUSTranrsTranrsItem {

    /** email 客戶信箱 */
    @Size(message = "長度不得超過50", max = 50)
    private String email;

    /** password 客戶密碼 */
    @Size(message = "長度不得超過15", max = 15)
    private String password;

    /** name 客戶姓名 */
    @Size(message = "長度不得超過20", max = 20)
    private String name;

    /** tel 客戶電話 */
    @Size(message = "長度不得超過15", max = 15)
    private String tel;

    /** sex 客戶性別 */
    @Size(message = "長度不得超過", max = 1)
    private String sex;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    /** birthday 客戶生日 */
    private String birthday;
}
