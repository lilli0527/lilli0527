package com.example.Pawsome.dto;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class INSERTORDERDETAILTranrq {

    /** MWHEADER */
    @Valid
    @JsonProperty("MWHEADER")
    private TranrqMwheader rqMwheader;

    /** TRANRQ */
    @Valid
    @JsonProperty("TRANRQ")
    private INSERTORDERDETAILTranrqTranrq rqTranrq;
    
}
