package com.example.Pawsome.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * DataNotFoundException
 * @author 00550283
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
public class DataNotFoundException extends Exception {

    /** 序列化 */
    private static final long serialVersionUID = 1L;

    /** action 程式名稱 */
    private String action;

    /** returnCode 處理結果代碼 */
    private String returnCode;

}
