package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SERVICEALLTranrqMwheaderTranrq {

    /** pageNumber 目前頁碼 */
    @NotNull(message = "目前頁碼不得為空")
    private int pageNumber;

    /** pageSize 每頁筆數 */
    @NotNull(message = "每頁筆數不得為空")
    private int pageSize;
    
    /** 服務名稱*/
    @JsonProperty("name")
    @Size(message = "name 長度不得超過20", max = 20)
    private String name;
    
    
}
