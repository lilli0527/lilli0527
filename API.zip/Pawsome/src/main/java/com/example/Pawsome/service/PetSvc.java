package com.example.Pawsome.service;

import com.example.Pawsome.dto.DELETEPETRq;
import com.example.Pawsome.dto.DELETEPETRs;
import com.example.Pawsome.dto.INSERTPETRq;
import com.example.Pawsome.dto.INSERTPETRs;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERRq;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERRs;
import com.example.Pawsome.dto.ONEPETBYIDRq;
import com.example.Pawsome.dto.ONEPETBYIDRs;
import com.example.Pawsome.dto.PETTranrq;
import com.example.Pawsome.dto.PETTranrs;
import com.example.Pawsome.dto.UPDATEPETRq;
import com.example.Pawsome.dto.UPDATEPETRs;
import com.example.Pawsome.exception.DataNotFoundException;

public interface PetSvc {
    INSERTPETRs insertPet(INSERTPETRq tranrq);

    UPDATEPETRs updatePet(UPDATEPETRq tranrq) throws DataNotFoundException;

    DELETEPETRs deletePet(DELETEPETRq tranrq) throws DataNotFoundException;

    ONEPETBYCUSTOMERRs onePetByCustomer(ONEPETBYCUSTOMERRq tranrq) throws DataNotFoundException;

    PETTranrs pet(PETTranrq request) throws DataNotFoundException;
    
    ONEPETBYIDRs onePetById(ONEPETBYIDRq tranrq) throws DataNotFoundException;

}
