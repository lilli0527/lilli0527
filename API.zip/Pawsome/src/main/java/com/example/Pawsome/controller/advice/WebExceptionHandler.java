package com.example.Pawsome.controller.advice;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.Pawsome.dto.ErrorMsg;
import com.example.Pawsome.dto.ErrorMsgMwheader;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataDuplicateException;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.DeleteFailException;
import com.example.Pawsome.exception.ErrorInputException;
import com.example.Pawsome.exception.InsertFailException;
import com.example.Pawsome.exception.PasswordException;
import com.example.Pawsome.exception.UpdateFailException;

@ControllerAdvice
public class WebExceptionHandler {

    private ErrorMsg errRs(String action, String returnCode, String returnDesc) {
        ErrorMsgMwheader errorMsgMwheader = new ErrorMsgMwheader();
        errorMsgMwheader.setMsgid(action);
        errorMsgMwheader.setReturnCode(returnCode);
        errorMsgMwheader.setReturnDesc(returnDesc);

        ErrorMsg errorMsg = new ErrorMsg();
        errorMsg.setMwheader(errorMsgMwheader);
        return errorMsg;
    }

    /**
     * handleException
     * @return
     */
//    @ResponseBody
//    @ExceptionHandler(Exception.class)
//    public ErrorMsg handleException() {
//        return errRs("Exception", ReturnCodeAndDescEnum.S9999.getCode(), ReturnCodeAndDescEnum.S9999.getDesc());
//    }

    /**
     * handleErrorInputException
     * 上行 request 輸入參數有錯誤
     * @param e
     * @return
     */
    @ResponseBody
    @ExceptionHandler(ErrorInputException.class)
    public ErrorMsg handleErrorInputException(ErrorInputException e) {
        return errRs(e.getAction(), ReturnCodeAndDescEnum.ERROR_INPUT.getCode(), ReturnCodeAndDescEnum.ERROR_INPUT.getDesc());
    }

    /**
     * handleDataNotFoundException
     * 查詢為空值
     * @param e
     * @return
     */
    @ResponseBody
    @ExceptionHandler(DataNotFoundException.class)
    public ErrorMsg handleDataNotFoundException(DataNotFoundException e) {
        return errRs(e.getAction(), ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode(), ReturnCodeAndDescEnum.DATA_NOT_FOUND.getDesc());
    }

    /**
     * handleInsertFailException
     * 新增失敗
     * @param e
     * @return
     */
    @ResponseBody
    @ExceptionHandler(InsertFailException.class)
    public ErrorMsg handleInsertFailException(InsertFailException e) {
        return errRs("InsertFailException", ReturnCodeAndDescEnum.INSERT_FAIL.getCode(), ReturnCodeAndDescEnum.INSERT_FAIL.getDesc());
    }

    /**
     * handleDeleteFailException
     * 刪除失敗
     * @param e
     * @return
     */
    @ResponseBody
    @ExceptionHandler(DeleteFailException.class)
    public ErrorMsg handleDeleteFailException(DeleteFailException e) {
        return errRs(e.getAction(), ReturnCodeAndDescEnum.DELETE_FAIL.getCode(), ReturnCodeAndDescEnum.DELETE_FAIL.getDesc());
    }


    /**
     * handleUpdateFailException
     * 更新失敗
     * @param e
     * @return
     */
    @ResponseBody
    @ExceptionHandler(UpdateFailException.class)
    public ErrorMsg handleUpdateFailException(UpdateFailException e) {
        return errRs(e.getAction(), ReturnCodeAndDescEnum.UPDATE_FAIL.getCode(), ReturnCodeAndDescEnum.UPDATE_FAIL.getDesc());
    }

    /**
     * handleDataDuplicateException
     * 資料重複
     * @param e
     * @return
     */
    @ResponseBody
    @ExceptionHandler(DataDuplicateException.class)
    public ErrorMsg handleDataDuplicateException(DataDuplicateException e) {
        return errRs(e.getAction(), ReturnCodeAndDescEnum.DATA_DUPLICATE.getCode(), ReturnCodeAndDescEnum.DATA_DUPLICATE.getDesc());
    }

    /**
     * handlePasswordException
     * 上行 request 輸入參數有錯誤
     * @param e
     * @return
     */
    @ResponseBody
    @ExceptionHandler(PasswordException.class)
    public ErrorMsg handlePasswordException(PasswordException e) {
        return errRs(e.getAction(), ReturnCodeAndDescEnum.PASSWORD_FAIL.getCode(), ReturnCodeAndDescEnum.PASSWORD_FAIL.getDesc());
    }

}
