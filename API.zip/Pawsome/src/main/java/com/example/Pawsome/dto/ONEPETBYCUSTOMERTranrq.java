package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class ONEPETBYCUSTOMERTranrq {

	@NotBlank(message = "會員信箱不可為空")
	@Size(message = "會員信箱不得超過50", max = 50)
	private String custEmail;
}
