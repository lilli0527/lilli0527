package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class INSERTORDERDETAILTranrqTranrqItems {

    /** 訂單編號 */
    @NotBlank(message = "訂單編號不能為空")
    @Size(message = "訂單編號長度不得超過20", max = 20)
    private String orderId;

    /** 單筆購物車ID */
    @NotBlank(message = "單筆購物車ID不得為空")
    @Size(message = "單筆購物車ID長度不得超過20", max = 20)
    private String itemId;

    /** 單筆訂單狀態 */
    @NotBlank(message = "單筆訂單狀態不得為空")
    @Size(message = "單筆訂單狀態長度不得超過5", max = 5)
    private String orderProcess;

    /** 單筆更新日期 */
    @NotBlank(message = "單筆更新日期不得為空")
    private String updateDate;
    
    /** 異動員工 */
    @NotBlank(message = "異動員工不得為空")
    private String updateEmp;

}
