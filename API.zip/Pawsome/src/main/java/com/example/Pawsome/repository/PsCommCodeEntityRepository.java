package com.example.Pawsome.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Pawsome.entity.PsCommCodeEntity;
import com.example.Pawsome.entity.PsCommCodePK;

@Repository
public interface PsCommCodeEntityRepository extends JpaRepository<PsCommCodeEntity, PsCommCodePK> {
    
    /**
     * 共用代號
     * @param type
     * @param commcode
     * @return
     */
    public Optional<PsCommCodeEntity> findByTypeAndCommCode(String type, String commcode);

    /**
     * 共用代號列表
     * @param type
     * @return
     */
    public List<PsCommCodeEntity> findByType(String type);

}
