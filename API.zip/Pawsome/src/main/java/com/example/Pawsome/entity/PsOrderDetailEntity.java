package com.example.Pawsome.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
@IdClass(value = PsOrderDetailPK.class)
@Table(name = "PS_ORDER_DETAIL")
public class PsOrderDetailEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @NotBlank
    @Column(name = "ORDER_ID")
    private String orderId;

    @Id
    @NotBlank
    @Column(name = "ITEM_ID")
    private String itemId;

    @NotBlank
    @Column(name = "ORDER_PROCESS")
    private String orderProcess;

    @NotNull
    @Column(name = "UPDATE_TIME")
    private Date updateTime;

    @Column(name = "UPDATE_EMP")
    private String updateEmp;

}
