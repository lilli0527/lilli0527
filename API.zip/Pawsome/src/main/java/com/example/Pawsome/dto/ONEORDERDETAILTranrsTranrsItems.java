package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class ONEORDERDETAILTranrsTranrsItems {

    /** serviceName 服務名稱 */
    @NotBlank
    @Size(message = "服務名稱長度不得超過20", max = 20)
    private String serviceName;

    /** startDate 服務開始日期 */
    @NotBlank
    private String startDate;

    /** endDate 服務結束日期 */
    private String endDate;

    /** startTime 服務開始時間 */
    @NotBlank
    private String startTime;

    /** petId 寵物ID */
    @NotBlank
    private String petId;

    /** petName 寵物名稱 */
    @NotBlank
    @Size(message = "寵物名稱長度不得超過20", max = 20)
    private String petName;

    /** petType 寵物類型 */
    @NotBlank
    private String petType;

    /** remarks 備註 */
    @NotBlank
    @Size(message = "備註長度不得超過50", max = 50)
    private String remarks;

    /** price 價格 */
    @NotBlank
    private String price;

    /** orderProcess 訂單狀態 */
    @NotBlank
    private String orderProcess;

    /**	updateEmp 異動人員 */
    @NotBlank
    private String updateEmp;

    /**	updateTime 異動時間 */
    @NotBlank
    private String updateTime;

}
