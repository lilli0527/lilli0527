package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SERVICETranrqMwheaderTranrq {

    /** 服務名稱*/
    @JsonProperty("type")
    @NotBlank(message = "type 不得為空")
    @Size(message = "type 長度不得超過20", max = 10)
    private String type;
    
    
}
