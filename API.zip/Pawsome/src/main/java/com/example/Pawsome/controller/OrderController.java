package com.example.Pawsome.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.dto.INSERTORDERTranrq;
import com.example.Pawsome.dto.INSERTORDERTranrs;
import com.example.Pawsome.dto.ORDERBYCUSTOMERRq;
import com.example.Pawsome.dto.ORDERBYCUSTOMERRs;
import com.example.Pawsome.dto.ORDERTranrq;
import com.example.Pawsome.dto.ORDERTranrs;
import com.example.Pawsome.dto.UPDATEORDERRq;
import com.example.Pawsome.dto.UPDATEORDERRs;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.ErrorInputException;
import com.example.Pawsome.exception.InsertFailException;
import com.example.Pawsome.service.OrderSvc;

@RestController
@CrossOrigin("http://localhost:4200")
public class OrderController {

    /** OrderSvc */
    @Autowired
    private OrderSvc orderSvc;
    
    /**
     * 修改訂單資料
     * @param tranrq
     * @param errors
     * @return
     * @throws DataNotFoundException
     * @throws ErrorInputException
     * @throws IOException 
     */
    @PostMapping(value = "/updateOrder")
    public UPDATEORDERRs updateOrder(@Valid
    @RequestBody
    UPDATEORDERRq tranrq, Errors errors) throws DataNotFoundException, ErrorInputException, IOException {
        //檢查errors是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            ReturnCodeAndDescEnum traErrorInput = ReturnCodeAndDescEnum.ERROR_INPUT;
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append(";");
            }
            throw new ErrorInputException("PAWSOME-UPDATEPET", traErrorInput.getCode());
        }
        return orderSvc.updateOrder(tranrq);
    }

    /** 必填欄位不完整 */
    private static final String ERRORINPUT = "E001";

    /**
     * API URL:order/insertOrder
     * 服務名稱：訂單資料新增服務
     * @param tranrq
     * @param errs
     * @return
     * @throws ErrorInputException
     * @throws InsertFailException
     * @throws IOException
     */
    @PostMapping("/insertOrder")
    public INSERTORDERTranrs insert(@Valid
    @RequestBody
    INSERTORDERTranrq tranrq, Errors errs) throws ErrorInputException, InsertFailException, IOException {
        if (errs.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errs.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException("INSERTORDER" + sb, ERRORINPUT);
        }
        return orderSvc.insert(tranrq);
    }

    /** OREDER 訂單資料查詢服務 */
    private static final String ORDER = "PAWSOME-ORDER";

    @PostMapping(value = "/order")
    public ORDERTranrs customer(@Valid
    @RequestBody
    ORDERTranrq request, Errors errors) throws DataNotFoundException, ErrorInputException, IOException {
        if (errors.hasErrors()) {
            throw new ErrorInputException(ORDER, ERRORINPUT);
        }
        return orderSvc.order(request);
    }

    @PostMapping(value = "/orderByCustomer")
    public ORDERBYCUSTOMERRs orderByCustomer(@Valid
    @RequestBody
    ORDERBYCUSTOMERRq tranrq, Errors errors) throws DataNotFoundException, ErrorInputException {
        //檢查errors是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            ReturnCodeAndDescEnum traErrorInput = ReturnCodeAndDescEnum.ERROR_INPUT;
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append(";");
            }
            throw new ErrorInputException("PAWSOME-UPDATEPET", traErrorInput.getCode());
        }
        return orderSvc.orderByCustomer(tranrq);
    }

    
    








}
