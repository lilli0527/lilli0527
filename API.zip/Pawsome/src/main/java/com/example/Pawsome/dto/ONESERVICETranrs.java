package com.example.Pawsome.dto;


import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ONESERVICETranrs {

    /** 放交易結果代號及訊息*/
    @Valid
    @JsonProperty("MWHEADER")
    private TranrsMwheader mwheader;
    
    /** 放服務名稱*/
    @Valid
    @JsonProperty("TRANRS")
    private ONESERVICETranrsMwheaderTranrs tranrs;
}
