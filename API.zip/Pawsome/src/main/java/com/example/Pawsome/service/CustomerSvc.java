package com.example.Pawsome.service;

import java.text.ParseException;

import java.io.IOException;

import com.example.Pawsome.dto.CUSTranrq;
import com.example.Pawsome.dto.CUSTranrs;
import com.example.Pawsome.dto.HASHCUSTranrq;
import com.example.Pawsome.dto.HASHCUSTranrs;
import com.example.Pawsome.dto.INSERTCUSTranrq;
import com.example.Pawsome.dto.INSERTCUSTranrs;
import com.example.Pawsome.dto.LOGINCUSTranrq;
import com.example.Pawsome.dto.LOGINCUSTranrs;
import com.example.Pawsome.dto.ONECUSTranrq;
import com.example.Pawsome.dto.ONECUSTranrs;
import com.example.Pawsome.dto.UPDATECUSTOMERRq;
import com.example.Pawsome.dto.UPDATECUSTOMERRs;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.InsertFailException;
import com.example.Pawsome.exception.PasswordException;

public interface CustomerSvc {
    UPDATECUSTOMERRs updateCustomer(UPDATECUSTOMERRq tranrq) throws DataNotFoundException, ParseException;

    ONECUSTranrs oneCustomer(ONECUSTranrq request) throws DataNotFoundException, IOException;

    LOGINCUSTranrs loginCustomer(LOGINCUSTranrq request) throws DataNotFoundException, PasswordException;

    INSERTCUSTranrs insertCustomer(INSERTCUSTranrq request) throws InsertFailException;

    CUSTranrs customer(CUSTranrq request) throws DataNotFoundException, IOException;

    HASHCUSTranrs hashCustomer(HASHCUSTranrq request) throws DataNotFoundException;

}
