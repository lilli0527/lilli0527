package com.example.Pawsome.service.impl;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.dto.CARTItems;
import com.example.Pawsome.dto.CARTTranrq;
import com.example.Pawsome.dto.CARTTranrqTranrq;
import com.example.Pawsome.dto.CARTTranrs;
import com.example.Pawsome.dto.CARTTranrsTranrs;
import com.example.Pawsome.dto.CARTTranrsTranrsItems;
import com.example.Pawsome.dto.CARTrq;
import com.example.Pawsome.dto.CARTrs;
import com.example.Pawsome.dto.DELETECARTTranrq;
import com.example.Pawsome.dto.DELETECARTTranrqTranrq;
import com.example.Pawsome.dto.DELETECARTTranrs;
import com.example.Pawsome.dto.INSERTCARTTranrq;
import com.example.Pawsome.dto.INSERTCARTTranrqTranrq;
import com.example.Pawsome.dto.INSERTCARTTranrs;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.dto.UPDATECARTTranrq;
import com.example.Pawsome.dto.UPDATECARTTranrqTranrq;
import com.example.Pawsome.dto.UPDATECARTTranrs;
import com.example.Pawsome.entity.PsCommCodeEntity;
import com.example.Pawsome.entity.PsPetEntity;
import com.example.Pawsome.entity.PsServiceEntity;
import com.example.Pawsome.entity.PsShoppingCartEntity;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataDuplicateException;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.DeleteFailException;
import com.example.Pawsome.exception.InsertFailException;
import com.example.Pawsome.exception.UpdateFailException;
import com.example.Pawsome.repository.PsCommCodeEntityRepository;
import com.example.Pawsome.repository.PsPetEntityRepository;
import com.example.Pawsome.repository.PsServiceEntityRepository;
import com.example.Pawsome.repository.PsShoppingCartEntityRepository;
import com.example.Pawsome.service.CartSvc;

/**
 * CartSvcImpl
 * @author 00550176
 *
 */
@Service
public class CartSvcImpl implements CartSvc {

    /** PsShoppingCartEntityRepository */
    @Autowired
    private PsShoppingCartEntityRepository cartRepo;

    /** PsServiceEntityRepository */
    @Autowired
    private PsServiceEntityRepository serviceRepo;

    /** PsPetEntityRepository */
    @Autowired
    private PsPetEntityRepository petRepo;

    /** PsCommCodeEntityRepository */
    @Autowired
    private PsCommCodeEntityRepository commCodeRepo;

    /** ReturnCodeAndDescEnum.SUCCESS */
    private ReturnCodeAndDescEnum success = ReturnCodeAndDescEnum.SUCCESS;

    /** 查無資料 */
    private static final String DATANOTFOUND = "E702";

    /**
     * 購物車資料查詢服務
     */
    @Override
    public CARTTranrs query(CARTTranrq tranrq) throws DataNotFoundException, IOException {
        CARTTranrqTranrq tranrqTranrq = tranrq.getRqTranrq();
        String custEmail = tranrqTranrq.getCustEmail();
        String isSubmit = tranrqTranrq.getIsSubmit();
        if (cartRepo.findByCustEmail(custEmail).isEmpty()) {
            throw new DataNotFoundException("CART", DATANOTFOUND);
        }
        List<PsShoppingCartEntity> entities = cartRepo.findByCustEmailAndIsSubmitOrderByStartDate(custEmail, isSubmit);
        List<CARTTranrsTranrsItems> itemList = new ArrayList<>();
        for (PsShoppingCartEntity entity : entities) {
            CARTTranrsTranrsItems items = new CARTTranrsTranrsItems();
            items.setItemId(entity.getItemId());
            items.setCustEmail(custEmail);
            items.setServiceId(entity.getServiceId());
            Optional<PsServiceEntity> serviceOpt = serviceRepo.findByServiceId(entity.getServiceId());
            PsServiceEntity serviceEntity = serviceOpt.get();
            items.setServiceName(serviceEntity.getName());
            items.setStartDate(entity.getStartDate().toString());
            items.setEndDate(entity.getEndDate() == null ? null : entity.getEndDate().toString());
            items.setStartTime(entity.getStartTime());
            items.setPetId(entity.getPetId());
            Optional<PsPetEntity> petOpt = petRepo.findByPetId(entity.getPetId());
            PsPetEntity petEntity = petOpt.get();
            items.setPetName(petEntity.getName());
            Optional<PsCommCodeEntity> commCodeOpt = commCodeRepo.findByTypeAndCommCode("PET", petEntity.getType());
            if (commCodeOpt.isPresent()) {
                items.setPetType(commCodeOpt.get().getMsg());
            }
            TimeUnit time = TimeUnit.DAYS;
            long duration;
            if (entity.getEndDate() == null) {
                items.setServiceTotalPrice(String.valueOf(serviceEntity.getPrice()));
            } else if (entity.getEndDate().equals(entity.getStartDate())) {
                duration = TimeUnit.HOURS.toMillis(24);
                items.setServiceTotalPrice(
                    String.valueOf(Long.parseLong(serviceEntity.getPrice()) * time.convert(duration, TimeUnit.MILLISECONDS)));
            } else {
                duration = entity.getEndDate().getTime() - entity.getStartDate().getTime();
                items.setServiceTotalPrice(
                    String.valueOf(Long.parseLong(serviceEntity.getPrice()) * time.convert(duration, TimeUnit.MILLISECONDS)));
            }
            items.setRemarks(entity.getRemarks());
            itemList.add(items);
        }
        CARTTranrsTranrs tranrsTranrs = new CARTTranrsTranrs();
        tranrsTranrs.setTotalCount(itemList.size());
        tranrsTranrs.setItems(itemList);
        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid(tranrq.getRqMwheader().getMsgid());
        mwheader.setReturnCode(success.getCode());
        mwheader.setReturnDesc(success.getDesc());
        CARTTranrs tranrs = new CARTTranrs();
        tranrs.setRsMwheader(mwheader);
        tranrs.setRsTranrs(tranrsTranrs);
        return tranrs;
    }

    /**
     * 購物車資料新增服務
     * @throws  
     */
    @Override
    @Transactional
    public INSERTCARTTranrs insert(INSERTCARTTranrq tranrq) throws DataDuplicateException, InsertFailException, IOException {
        INSERTCARTTranrqTranrq tranrqTranrq = tranrq.getRqTranrq();
        String email = tranrqTranrq.getCustEmail();
        int serviceId = tranrqTranrq.getServiceId();
        Date startDate = formatDate(tranrqTranrq.getStartDate());
        String startTime = tranrqTranrq.getStartTime();
        Optional<PsShoppingCartEntity> entityOpt = cartRepo.findByCustEmailAndServiceIdAndStartDateAndStartTime(email, serviceId, startDate,
            startTime);
        if (entityOpt.isPresent()) {
            throw new DataDuplicateException("INSERTCART", "E703");
        }
        PsShoppingCartEntity entity = new PsShoppingCartEntity();
        int nextItemIdNum = cartRepo.findMaxItemIdNumber() + 1;
        entity.setItemId(String.valueOf(nextItemIdNum));
        entity.setCustEmail(email);
        entity.setServiceId(serviceId);
        entity.setStartDate(startDate);
        entity.setEndDate(tranrqTranrq.getEndDate() == "" ? null : formatDate(tranrqTranrq.getEndDate()));
        entity.setStartTime(startTime);
        entity.setPetId(tranrqTranrq.getPetId());
        entity.setRemarks(tranrqTranrq.getRemarks());
        entity.setIsSubmit(tranrqTranrq.getIsSubmit());
        try {
            cartRepo.save(entity);
        } catch (Exception e) {
            throw new InsertFailException("INSERTCART", "E003");
        }
        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid(tranrq.getRqMwheader().getMsgid());
        mwheader.setReturnCode(success.getCode());
        mwheader.setReturnDesc(success.getDesc());
        INSERTCARTTranrs tranrs = new INSERTCARTTranrs();
        tranrs.setRsMwheader(mwheader);
        return tranrs;
    }

    /**
     * 購物車資料修改服務
     */
    @Override
    @Transactional
    public UPDATECARTTranrs update(UPDATECARTTranrq tranrq) throws DataNotFoundException, UpdateFailException, IOException {
        UPDATECARTTranrqTranrq tranrqTranrq = tranrq.getRqTranrq();
        String itemId = tranrqTranrq.getItemId();
        Optional<PsShoppingCartEntity> entityOpt = cartRepo.findById(itemId);
        if (!entityOpt.isPresent()) {
            throw new DataNotFoundException("UPDATECART", DATANOTFOUND);
        }
        PsShoppingCartEntity entity = entityOpt.get();
        entity.setCustEmail(tranrqTranrq.getCustEmail());
        entity.setServiceId(tranrqTranrq.getServiceId());
        entity.setStartDate(formatDate(tranrqTranrq.getStartDate()));
        entity.setEndDate(tranrqTranrq.getEndDate() == "" ? null : formatDate(tranrqTranrq.getEndDate()));
        entity.setStartTime(tranrqTranrq.getStartTime());
        entity.setPetId(tranrqTranrq.getPetId());
        entity.setRemarks(tranrqTranrq.getRemarks());
        entity.setIsSubmit(tranrqTranrq.getIsSubmit());
        try {
            cartRepo.save(entity);
        } catch (Exception e) {
            throw new UpdateFailException("UPDATECART", "E002");
        }
        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid(tranrq.getRqMwheader().getMsgid());
        mwheader.setReturnCode(success.getCode());
        mwheader.setReturnDesc(success.getDesc());
        UPDATECARTTranrs tranrs = new UPDATECARTTranrs();
        tranrs.setRsMwheader(mwheader);
        return tranrs;
    }

    /**
     * 購物車資料刪除服務
     */
    @Override
    @Transactional
    public DELETECARTTranrs delete(DELETECARTTranrq tranrq) throws DataNotFoundException, DeleteFailException, IOException {
        DELETECARTTranrqTranrq tranrqTranrq = tranrq.getRqTranrq();
        String itemId = tranrqTranrq.getItemId();
        if (!cartRepo.existsById(itemId)) {
            throw new DataNotFoundException("DELETECART", DATANOTFOUND);
        }
        try {
            cartRepo.deleteById(itemId);
        } catch (Exception e) {
            throw new DeleteFailException("DELETECART", "E004");
        }
        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid(tranrq.getRqMwheader().getMsgid());
        mwheader.setReturnCode(success.getCode());
        mwheader.setReturnDesc(success.getDesc());
        DELETECARTTranrs tranrs = new DELETECARTTranrs();
        tranrs.setRsMwheader(mwheader);
        return tranrs;
    }

    /**
     * 當送出訂單，查找會員及itemId後將isSubmit改為y
     */
    @Transactional
    public void markItemsAsSubmitted(String userEmail, String itemId) {
        List<PsShoppingCartEntity> entities = cartRepo.findByCustEmailAndItemId(userEmail, itemId);
        for (PsShoppingCartEntity entity : entities) {
            entity.setIsSubmit("y");
        }
        cartRepo.saveAll(entities);
    }

    /**
     * 將string轉為DB格式後傳入
     * @param date
     * @return
     */
    public Date formatDate(String date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.parse(date, formatter);
        return Date.valueOf(localDate);
    }
    
    
    
    public CARTrs calendar(CARTrq tranrq) throws DataNotFoundException, IOException {
    	List<PsShoppingCartEntity> entities =  cartRepo.findByIsSubmit("y");
        List<CARTItems> itemList = new ArrayList<>();
        for (PsShoppingCartEntity entity : entities) {
        	CARTItems items = new CARTItems();
            items.setItemId(entity.getItemId());
            items.setCustEmail(entity.getCustEmail());
            items.setServiceId(entity.getServiceId());
            Optional<PsServiceEntity> serviceOpt = serviceRepo.findByServiceId(entity.getServiceId());
            PsServiceEntity serviceEntity = serviceOpt.get();
            items.setServiceName(serviceEntity.getName());
            items.setStartDate(entity.getStartDate().toString());
            items.setEndDate(entity.getEndDate() == null ? null : entity.getEndDate().toString());
            items.setStartTime(entity.getStartTime());
            items.setPetId(entity.getPetId());
            Optional<PsPetEntity> petOpt = petRepo.findByPetId(entity.getPetId());
            PsPetEntity petEntity = petOpt.get();
            items.setPetName(petEntity.getName());
            Optional<PsCommCodeEntity> commCodeOpt = commCodeRepo.findByTypeAndCommCode("PET", petEntity.getType());
            if (commCodeOpt.isPresent()) {
                items.setPetType(commCodeOpt.get().getMsg());
            }
            TimeUnit time = TimeUnit.DAYS;
            long duration;
            if (entity.getEndDate() == null) {
                items.setServiceTotalPrice(String.valueOf(serviceEntity.getPrice()));
            } else if (entity.getEndDate().equals(entity.getStartDate())) {
                duration = TimeUnit.HOURS.toMillis(24);
                items.setServiceTotalPrice(
                    String.valueOf(Long.parseLong(serviceEntity.getPrice()) * time.convert(duration, TimeUnit.MILLISECONDS)));
            } else {
                duration = entity.getEndDate().getTime() - entity.getStartDate().getTime();
                items.setServiceTotalPrice(
                    String.valueOf(Long.parseLong(serviceEntity.getPrice()) * time.convert(duration, TimeUnit.MILLISECONDS)));
            }
            items.setRemarks(entity.getRemarks());
            itemList.add(items);
        }
        
        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid(tranrq.getRqMwheader().getMsgid());
        mwheader.setReturnCode(success.getCode());
        mwheader.setReturnDesc(success.getDesc());
        
        CARTrs tranrs = new CARTrs();
        tranrs.setRsMwheader(mwheader);
        tranrs.setRsTranrs(itemList);
        return tranrs;
    }

}
