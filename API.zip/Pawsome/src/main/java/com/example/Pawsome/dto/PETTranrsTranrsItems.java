package com.example.Pawsome.dto;

import java.util.Date;

import javax.validation.constraints.Size;



import lombok.Data;

@Data
public class PETTranrsTranrsItems {
    
    /** 寵物ID */
    @Size(message = "長度不得超過20", max = 20)
    private String petId;

    /** 客戶ID */
    @Size(message = "長度不得超過50", max = 50)
    private String custEmail;

    /** 寵物姓名 */
    @Size(message = "長度不得超過20", max = 20)
    private String name;

    /** 寵物類別 */
    @Size(message = "長度不得超過5", max = 5)
    private String type;

    /** 寵物性別 */
    @Size(message = "長度不得超過1", max = 1)
    private String sex;
    
    /** 寵物年齡 */
    private String birth;
    
    /** 寵物體重 */
    @Size(message = "長度不得超過20", max = 20)
    private String weight;

    /** 備註 */
    @Size(message = "長度不得超過50", max = 50)
    private String remarks;
    
  
}
