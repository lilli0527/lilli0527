package com.example.Pawsome.service;

import java.io.IOException;

import com.example.Pawsome.dto.INSERTORDERTranrq;
import com.example.Pawsome.dto.INSERTORDERTranrs;
import com.example.Pawsome.dto.ORDERBYCUSTOMERRq;
import com.example.Pawsome.dto.ORDERBYCUSTOMERRs;
import com.example.Pawsome.dto.ORDERTranrq;
import com.example.Pawsome.dto.ORDERTranrs;
import com.example.Pawsome.dto.UPDATEORDERRq;
import com.example.Pawsome.dto.UPDATEORDERRs;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.InsertFailException;

public interface OrderSvc {

    UPDATEORDERRs updateOrder(UPDATEORDERRq tranrq) throws DataNotFoundException, IOException;

    /**
     * 訂單資料新增服務
     * @param tranrq
     * @return
     * @throws InsertFailException
     */
    public INSERTORDERTranrs insert(INSERTORDERTranrq tranrq) throws InsertFailException, IOException;

    ORDERTranrs order(ORDERTranrq request) throws DataNotFoundException, IOException;

    ORDERBYCUSTOMERRs orderByCustomer(ORDERBYCUSTOMERRq tranrq) throws DataNotFoundException;
}
