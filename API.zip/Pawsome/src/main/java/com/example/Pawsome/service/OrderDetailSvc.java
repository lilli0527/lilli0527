package com.example.Pawsome.service;

import java.io.IOException;

import com.example.Pawsome.dto.ONEORDERDETAILTranrq;
import com.example.Pawsome.dto.ONEORDERDETAILTranrs;
import com.example.Pawsome.exception.DataNotFoundException;

public interface OrderDetailSvc {
    
    ONEORDERDETAILTranrs queryOneOrderDetail(ONEORDERDETAILTranrq request) throws DataNotFoundException, IOException;

}
