package com.example.Pawsome.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.dto.CARTTranrq;
import com.example.Pawsome.dto.CARTTranrs;
import com.example.Pawsome.dto.CARTrq;
import com.example.Pawsome.dto.CARTrs;
import com.example.Pawsome.dto.DELETECARTTranrq;
import com.example.Pawsome.dto.DELETECARTTranrs;
import com.example.Pawsome.dto.INSERTCARTTranrq;
import com.example.Pawsome.dto.INSERTCARTTranrs;
import com.example.Pawsome.dto.UPDATECARTTranrq;
import com.example.Pawsome.dto.UPDATECARTTranrs;
import com.example.Pawsome.exception.DataDuplicateException;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.DeleteFailException;
import com.example.Pawsome.exception.ErrorInputException;
import com.example.Pawsome.exception.InsertFailException;
import com.example.Pawsome.exception.UpdateFailException;
import com.example.Pawsome.service.CartSvc;

/**
 * CartController
 * @author 00550176
 *
 */
@RestController
@CrossOrigin("http://localhost:4200")
public class CartController {

    /** CartSvc */
    @Autowired
    private CartSvc cartSvc;

    /** 必填欄位不完整 */
    private static final String ERRORINPUT = "E001";

    /**
     * API URL:/cart
     * 服務名稱：購物車資料查詢服務
     * @param tranrq
     * @param errs
     * @return
     * @throws ErrorInputException
     * @throws DataNotFoundException
     */
    @PostMapping("/cart")
    public CARTTranrs query(@Valid
    @RequestBody
    CARTTranrq tranrq, Errors errs) throws ErrorInputException, DataNotFoundException, IOException {
        if (errs.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errs.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException("CART" + sb, ERRORINPUT);
        }
        return cartSvc.query(tranrq);
    }

    /**
     * API URL:/insertCart
     * 服務名稱：購物車資料新增服務
     * @param tranrq
     * @param errs
     * @return
     * @throws ErrorInputException
     * @throws DataDuplicateException
     * @throws InsertFailException
     * @throws IOException
     */
    @PostMapping("/insertCart")
    public INSERTCARTTranrs insert(@Valid
    @RequestBody
    INSERTCARTTranrq tranrq, Errors errs) throws ErrorInputException, DataDuplicateException, InsertFailException, IOException {
        if (errs.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errs.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException("INSERTCART" + sb, ERRORINPUT);
        }
        return cartSvc.insert(tranrq);
    }

    /**
     * API URL:/updateCart
     * 服務名稱：購物車資料更新服務
     * @param tranrq
     * @param errs
     * @return
     * @throws ErrorInputException
     * @throws DataNotFoundException 
     * @throws UpdateFailException
     * @throws IOException 
     */
    @PostMapping("/updateCart")
    public UPDATECARTTranrs update(@Valid
    @RequestBody
    UPDATECARTTranrq tranrq, Errors errs) throws ErrorInputException, DataNotFoundException, UpdateFailException, IOException {
        if (errs.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errs.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException("UPDATECART" + sb, ERRORINPUT);
        }
        return cartSvc.update(tranrq);
    }

    /**
     * API URL:/deleteCart
     * 服務名稱：購物車資料刪除服務
     * @param tranrq
     * @param errs
     * @return
     * @throws ErrorInputException
     * @throws DataNotFoundException
     * @throws DeleteFailException
     * @throws IOException 
     */
    @PostMapping("/deleteCart")
    public DELETECARTTranrs delete(@Valid
    @RequestBody
    DELETECARTTranrq tranrq, Errors errs) throws ErrorInputException, DataNotFoundException, DeleteFailException, IOException {
        if (errs.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errs.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException("DELETECART" + sb, ERRORINPUT);
        }
        return cartSvc.delete(tranrq);
    }
    
    @PostMapping("/calendar")
    public CARTrs calendar(@Valid
    @RequestBody
    CARTrq tranrq, Errors errs) throws ErrorInputException, DataNotFoundException, IOException {
        if (errs.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errs.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException("CART" + sb, ERRORINPUT);
        }
        return cartSvc.calendar(tranrq);
    }
    

}
