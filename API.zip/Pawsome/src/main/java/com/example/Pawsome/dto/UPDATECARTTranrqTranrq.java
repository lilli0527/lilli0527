package com.example.Pawsome.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class UPDATECARTTranrqTranrq {

    /** 購物車ID */
    @NotBlank(message = "購物車ID不得為空")
    @Size(message = "購物車ID長度不得超過20", max = 20)
    private String itemId;

    /** 會員信箱 */
    @NotBlank(message = "會員信箱不得為空")
    @Size(message = "會員信箱長度不得超過70", max = 70)
    private String custEmail;

    /** 服務編號 */
    @NotNull(message = "服務編號不得為空")
    @Max(message = "服務編號不得>20", value = 20)
    private int serviceId;

    /** 開始日期 */
    @NotBlank(message = "開始日期不得為空")
    private String startDate;

    /** 結束日期 */
    private String endDate;

    /** 開始時間 */
    @NotBlank(message = "開始時間不得為空")
    @Size(message = "開始時間長度不得超過20", max = 20)
    private String startTime;

    /** 寵物ID */
    @NotNull(message = "請選擇欲接受服務的寵物")
    private int petId;

    /** 備註 */
    @Size(message = "remarks 長度不得超過50", max = 50)
    private String remarks;

    /** 是否送單 */
    @NotBlank(message = "送單狀態不得為空")
    @Size(message = "送單狀態長度不得超過5", max = 5)
    private String isSubmit;

}
