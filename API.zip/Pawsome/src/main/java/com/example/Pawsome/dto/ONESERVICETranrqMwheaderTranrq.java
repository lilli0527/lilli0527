package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ONESERVICETranrqMwheaderTranrq {

    /** 服務類別*/
    @JsonProperty("name")
    @NotBlank(message = "name 不得為空")
    @Size(message = "name 長度不得超過20", max = 20)
    private String name;
    
}
