package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DELETESERVICETranrqMwheaderTranrq {

    /** 服務序號*/
    @JsonProperty("serviceId")
    @NotNull(message = "serviceId 不得為空")
//    @Size(message = "serviceId 長度不得超過20", max = 20)
    private int serviceId;
    
}
