package com.example.Pawsome.dto;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PETTranrq {
    /** MWHEADER */
    @Valid
    @JsonProperty("MWHEADER")
    private TranrqMwheader mwheader;
}
