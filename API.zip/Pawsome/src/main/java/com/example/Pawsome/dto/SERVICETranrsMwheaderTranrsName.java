package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SERVICETranrsMwheaderTranrsName {

    /** 服務序號*/
    @JsonProperty("serviceId")
    @NotBlank(message = "serviceId 不得為空")
    private int serviceId;
    
    /** 服務名稱*/
    @JsonProperty("name")
    @NotBlank(message = "NAME 不得為空")
    @Size(message = "NAME 長度不得超過20", max = 20)
    private String name;
    
}
