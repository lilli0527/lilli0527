package com.example.Pawsome.dto;

import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class HASHCUSTranrsTranrs {
    /** email */
    @Size(message = "長度不得超過15", max = 15)
    private String email;
}
