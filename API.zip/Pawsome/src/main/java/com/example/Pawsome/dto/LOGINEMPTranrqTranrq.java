package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class LOGINEMPTranrqTranrq {

    /** email 員工信箱 */
    @NotBlank
    @Size(message = "信箱長度不可超過50字", max = 50)
    private String email;

    /** password 員工密碼 */
    @NotBlank
    @Size(message = "長度不可超過20字", max = 20)
    private String password;
}
