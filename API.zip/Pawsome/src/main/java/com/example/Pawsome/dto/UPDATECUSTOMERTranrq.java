package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class UPDATECUSTOMERTranrq {
    @NotBlank(message = "會員信箱不可為空")
    @Size(message = "會員信箱不得超過50", max = 50)
    private String custEmail;

    @NotBlank(message = "會員密碼不可為空")
    @Size(message = "會員密碼不得超過15", max = 15)
    private String password;

    @NotBlank(message = "會員姓名不可為空")
    @Size(message = "會員姓名不得超過20", max = 20)
    private String name;

    @NotBlank(message = "會員電話不可為空")
    @Size(message = "會員電話不得超過15", max = 15)
    private String tel;

    @Size(message = "會員性別不得超過1", max = 1)
    private String sex;

    private String birthday;
}
