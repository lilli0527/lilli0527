import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {
  DialogComponent,
  DialogData,
} from 'src/app/shared/components/dialog/dialog.component';
import {
  CommCodeItems,
  EmpDataItems,
  UpdateEmpDataTranrq,
} from 'src/app/shared/interfaces/EmpElement';
import { EmpDataService } from 'src/app/shared/service/emp-data.service';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-emp-edit',
  templateUrl: './emp-edit.component.html',
  styleUrls: ['./emp-edit.component.css'],
  providers: [DatePipe],
})
export class EmpEditComponent implements OnInit {
  /** 欲修改之員工信箱 */
  selectEmail: string | undefined;

  /** 欲修改之資料 */
  editData = {} as EmpDataItems;

  /** 密碼是否顯示 */
  hide = true;

  /** 員工性別選單 */
  sexList = [
    {
      key: 'F',
      value: '女',
    },
    {
      key: 'M',
      value: '男',
    },
  ];

  /** 欲修改之性別 */
  selectSex: string | undefined;

  /** 員工狀態選單 */
  isQuitList = [
    {
      key: 'n',
      value: '在職',
    },
    {
      key: 'y',
      value: '離職',
    },
  ];

  /** 欲修改之性別 */
  selectIsQuit: string | undefined;

  /** 最大生日日期 */
  maxDate = new Date();

  /** 員工權限選單 */
  permissionList: CommCodeItems[] = [];

  /** 異動日期 */
  currentDate: string | undefined | null;

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    name: [
      '',
      [
        Validators.required,
        Validators.pattern(/^\S*$/),
        Validators.maxLength(20),
      ],
    ],
    tel: [
      '',
      [
        Validators.required,
        Validators.pattern(/^\d*$/),
        Validators.maxLength(10),
      ],
    ],
    password: [
      '',
      [
        Validators.required,
        Validators.pattern(/^\w*$/),
        Validators.minLength(6),
        Validators.maxLength(20),
      ],
    ],
    sex: [''],
    birthday: [''],
    permissions: ['', [Validators.required]],
    isQuit: ['', [Validators.required]],
  });

  /**
   * 取得「員工名稱」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get name(): FormControl<string | null> {
    return this.form.controls.name;
  }

  /**
   * 取得「電話」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get tel(): FormControl<string | null> {
    return this.form.controls.tel;
  }

  /**
   * 取得「密碼」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get password(): FormControl<string | null> {
    return this.form.controls.password;
  }

  /**
   * 取得「性別」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get sex(): FormControl<string | null> {
    return this.form.controls.sex;
  }

  /**
   * 取得「生日」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get birthday(): FormControl<string | null> {
    return this.form.controls.birthday;
  }

  /**
   * 取得「權限」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get permissions(): FormControl<string | null> {
    return this.form.controls.permissions;
  }

  /**
   * 取得「狀態」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get isQuit(): FormControl<string | null> {
    return this.form.controls.isQuit;
  }

  constructor(
    private fb: FormBuilder,
    private empHttpService: EmpHttpService,
    private dataService: EmpDataService,
    private datePipe: DatePipe,
    public dialogRef: MatDialogRef<DialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) { }

  ngOnInit(): void {
    this.empHttpService.queryMsgCode('PERMISSIONS').subscribe((res) => {
      const responseData = res;
      this.permissionList = responseData.TRANRS.items;
    });

    this.selectEmail = this.dataService.empEmail;

    this.empHttpService.queryEmpData(0, 1, this.selectEmail, '', '', '').subscribe({
      next: (res) => {
        const responseData = res;
        this.editData = responseData.TRANRS.items[0];
        this.selectSex = this.sexList.find(
          (element) => element.key === this.editData.sex
        )?.value;
      },
      complete: () => {
        this.initialization();
        this.currentDate = this.datePipe.transform(new Date(), 'yyyy/MM/dd');
      },
    });
  }

  /** 修改員工資料 */
  editEmp() {
    const editSex = !this.form.value.sex
      ? ''
      : this.sexList.find((element) => element.key === this.form.value.sex)
        ?.value;
    const editBirthday = !this.form.value.birthday
      ? ''
      : new Date(this.form.value.birthday);
    const updaterq = {
      ...this.form.value,
      email: this.selectEmail,
      sex: editSex,
      birthday: editBirthday,
    } as UpdateEmpDataTranrq;

    this.empHttpService.editEmpData(updaterq).subscribe((res) => {
      const responseData = res;
      // 新增失敗跳出提示訊息
      if (responseData.MWHEADER.RETURNCODE !== '0000') {
        Swal.fire({
          icon: 'error',
          title: '修改失敗',
          text: responseData.MWHEADER.RETURNDESC,
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '確定',
        });
        return;
      }

      // 修改成功跳出提示訊息
      if (responseData.MWHEADER.RETURNCODE === '0000') {
        Swal.fire({
          icon: 'success',
          title: '修改成功',
          width: 350,
          padding: '3em',
          background: '#fff',
        });
        this.dialogRef.close();
      }
    });
  }

  /** 關閉談窗 */
  closeDialog() {
    this.dialogRef.close();
  }

  /** 初始化-將選取資料帶到畫面顯示 */
  initialization() {
    // 將選取資料帶到畫面顯示
    this.form.patchValue({
      ...this.editData,
      sex: this.selectSex,
    });
  }
}
