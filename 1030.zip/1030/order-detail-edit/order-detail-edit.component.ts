import { PetTypePipe } from './../../shared/pipes/pet-type.pipe';
import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CartService } from 'src/app/core/services/cart.service';
import { DialogComponent, DialogData } from 'src/app/shared/components/dialog/dialog.component';
import { CommCodeItems, EmpDataItems, OrderOneDetailDataItems, PetList, ServiceTime, UpdateOrderDetailDataTranrq } from 'src/app/shared/interfaces/EmpElement';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-order-detail-edit',
  templateUrl: './order-detail-edit.component.html',
  styleUrls: ['./order-detail-edit.component.css'],
  providers: [DatePipe, PetTypePipe],
})
export class OrderDetailEditComponent implements OnInit {

  /** 員工信箱 */
  empEmail = '';

  /** 欲修改之訂單編號 */
  selectOrderId: string | undefined;

  /** 欲修改之會員信箱 */
  selectCustEmail: string | undefined;

  /** 欲修改之訂單明細編號 */
  selectItemId: string | undefined;

  /** startDate 最小可選取日 */
  tomorrow = new Date();

  /** endDate 最小可選取日 */
  minEndDate = new Date();

  /** startDate 最大可選取日 */
  maxDate = new Date();

  /** endDate 最大可選取日 */
  maxEndDate = new Date();

  /** 欲修改之資料 */
  editData = {} as OrderOneDetailDataItems;

  /** 欲修改之服務 */
  selectService = '';

  /** 欲修改之服務單次(日)價格 */
  selectServicePrice = '';

  /** 欲修改之服務寵物類型 */
  selectServicePetType = '';

  /** 欲修改之服務寵物尺寸 */
  selectServicePetSizeRange = '';

  /** 預約時間選單 */
  timeOptions: ServiceTime[] = [
    { time: '08:00-09:00' },
    { time: '09:00-10:00' },
    { time: '10:00-11:00' },
    { time: '11:00-12:00' },
    { time: '13:00-14:00' },
    { time: '14:00-15:00' },
    { time: '15:00-16:00' },
    { time: '16:00-17:00' },
    { time: '17:00-18:00' },
    { time: '18:00-19:00' },
    { time: '19:00-20:00' },
    { time: '20:00-21:00' },
    { time: '21:00-22:00' },
  ];

  /** 欲修改之預約時間 */
  selectTime: string | undefined;

  /** 篩選符合的會員寵物列表 */
  petList: PetList[] = [];

  /** 訂單狀態選單 */
  orderProcessList: CommCodeItems[] = [];

  /** disabled 選擇之訂單狀態 */
  disableSelect = '';

  /** 異動人員資料 */
  updateEmpInfo = {} as EmpDataItems;

  /** 異動日期 */
  currentDate: string | undefined | null;

  /** 修改後之服務日 */
  editStartDate = '';

  /** 修改之結束日 */
  editEndDate = '';

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    startDate: ['', [Validators.required]],
    endDate: [''],
    startTime: ['', [Validators.required]],
    petName: ['', [Validators.required]],
    petType: [{ value: '', disabled: true }, Validators.required],
    remarks: [''],
    price: [{ value: '', disabled: true }, Validators.required],
    orderProcess: ['', [Validators.required]],
  });

  /**
   * 取得「預約日期(起)」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get startDate(): FormControl<string | null> {
    return this.form.controls.startDate;
  }

  /**
   * 取得「預約日期(訖)」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get endDate(): FormControl<string | null> {
    return this.form.controls.endDate;
  }

  /**
   * 取得「預約時間」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get startTime(): FormControl<string | null> {
    return this.form.controls.startTime;
  }

  /**
   * 取得「寵物名稱」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get petName(): FormControl<string | null> {
    return this.form.controls.petName;
  }

  /**
   * 取得「寵物種類」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get petType(): FormControl<string | null> {
    return this.form.controls.petType;
  }

  /**
   * 取得「備註」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get remarks(): FormControl<string | null> {
    return this.form.controls.remarks;
  }

  /**
   * 取得「價格」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get price(): FormControl<string | null> {
    return this.form.controls.price;
  }

  /**
   * 取得「訂單狀態」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get orderProcess(): FormControl<string | null> {
    return this.form.controls.orderProcess;
  }

  constructor(
    private fb: FormBuilder,
    private empHttpService: EmpHttpService,
    private cartService: CartService,
    private datePipe: DatePipe,
    private petTypePipe: PetTypePipe,
    public dialogRef: MatDialogRef<DialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) { }

  firstTime: boolean = true;

  ngOnInit(): void {
    this.selectOrderId = sessionStorage.getItem('orderId')!;
    this.selectCustEmail = sessionStorage.getItem('custEmail')!;
    this.selectItemId = sessionStorage.getItem('itemId')!;

    // 員工資料
    this.empHttpService.queryHashEmp(sessionStorage.getItem('hashempuser')!).subscribe({
      next: (rs) => {
        this.empEmail = rs.TRANRS.email;
      },
      complete: () => {
        this.empHttpService
          .queryEmpData(0, 1, this.empEmail, '', '', '')
          .subscribe((res) => {
            const responseData = res;
            this.updateEmpInfo = responseData.TRANRS.items[0];
          });
      }
    })

    // 訂單狀態選單
    this.empHttpService.queryMsgCode('ORDERPROCESS').subscribe((res) => {
      const responseData = res;
      this.orderProcessList = responseData.TRANRS.items;
    });

    // 訂單明細
    this.empHttpService
      .queryOneOrderDetail(0, 1, this.selectOrderId, this.selectItemId)
      .subscribe({
        next: (res) => {
          const responseData = res;
          this.editData = responseData.TRANRS.items[0];
          this.selectService = this.editData.serviceName;

        },
        complete: () => {
          this.currentDate = this.datePipe.transform(new Date(), 'yyyy/MM/dd');

          // 查詢服務資訊
          this.empHttpService
            .queryServiceDetail(this.selectService)
            .subscribe({
              next: (res) => {
                const responseData = res;
                this.selectServicePrice = responseData.TRANRS.datas[0].price;
                this.selectServicePetType = responseData.TRANRS.datas[0].petType;
                this.selectServicePetSizeRange = responseData.TRANRS.datas[0].petSizeRange;
              },
              complete: () => {
                // 會員寵物資料
                this.empHttpService
                  .queryOnePetByCust(this.selectCustEmail!)
                  .subscribe((res) => {
                    const responseData = res;
                    this.petList = responseData.TRANRS.map<PetList>((e) => ({
                      petId: e.pet_id.toString(),
                      petName: e.name,
                      petType: e.type,
                      petWeight: e.weight!
                    }));

                    // 判斷過濾寵物類型及體重
                    if (this.selectServicePetType === '狗狗') {
                      this.petList = this.petList.filter((pet) => pet.petType === '2' && +pet.petWeight <= +this.selectServicePetSizeRange);
                    } else if (this.selectServicePetType === '貓貓') {
                      this.petList = this.petList.filter((pet) => pet.petType === '1' && +pet.petWeight <= +this.selectServicePetSizeRange);
                    } else {
                      this.petList = this.petList.filter((pet) => +pet.petWeight <= +this.selectServicePetSizeRange);
                    }
                    // 篩選後就沒有寵物的話
                    if (this.petList.length === 0) {
                      Swal.fire({
                        icon: 'warning',
                        title: '未有不超過' + this.selectServicePetSizeRange + '公斤的' + this.selectServicePetType,
                        html: '請訂購人至其會員專區</br>修改或新增該類型毛孩以利後續預約',
                        width: 450,
                        padding: '3em',
                        color: '#5d3f0a',
                        background: '#fff',
                      })
                    }
                    this.initialization();
                  });
              }
            });
        },
      });

    this.tomorrow.setDate(this.tomorrow.getDate() + 1);
    this.maxDate.setDate(this.tomorrow.getDate() + 31);
    this.form.get('startDate')?.valueChanges.subscribe((date) => {
      const selectedDate = new Date(date);
      this.minEndDate = new Date(selectedDate);
      this.minEndDate.setDate(this.minEndDate.getDate() + 1);
      this.maxEndDate = new Date(selectedDate);
      this.maxEndDate.setDate(this.maxDate.getDate() + 91);
    });
  }

  /** 修改訂單狀態 */
  editOrderDetail() {
    this.editStartDate = this.datePipe.transform(this.form.controls.startDate.value, 'yyyy-MM-dd')!;
    if (this.form.value.endDate) {
      this.editEndDate = this.datePipe.transform(this.form.controls.endDate.value, 'yyyy-MM-dd')!;
    }
    const input = {
      ...this.form.value,
      orderId: this.selectOrderId,
      itemId: this.selectItemId,
      petId: this.editData.petId,
      startDate: this.editStartDate,
      endDate: this.editEndDate,
      orderProcess: this.orderProcessList.find(element => element.msg === this.form.value.orderProcess)?.commCode,
      updateEmp: this.updateEmpInfo.email,
    } as UpdateOrderDetailDataTranrq;

    const isSubmit: string = 'y'
    let hasWarning = false;

    // 已預約訂單
    this.cartService.queryCartIsSubmit(isSubmit).subscribe((res) => {
      res.TRANRS.items.map(itemsInOrder => {
        if (input.itemId !== itemsInOrder.itemId) { //是否是原訂單明細
          if (this.selectService === itemsInOrder.serviceName) { //是否與訂單中相同服務
            if (input.startDate === itemsInOrder.startDate) { //是否與訂單中相同預約日
              if (input.endDate === '') { //若為非過夜
                if (input.startTime === itemsInOrder.startTime) { //是否與訂單中相同時間
                  hasWarning = true;
                  Swal.fire({
                    icon: 'warning',
                    html: '請修改預約日期或預約時間</br>該日期之該時段已無空位',
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '確認',
                    confirmButtonColor: '#ffbd4a'
                  });
                }
              } else if (input.endDate) {  //只要相同預約日，不論結束日為何皆無空位
                hasWarning = true;
                Swal.fire({
                  icon: 'warning',
                  html: '請修改預約日期或預約時間</br>該日期之該時段已無空位',
                  padding: '3em',
                  color: '#5d3f0a',
                  background: '#fff',
                  confirmButtonText: '確認',
                  confirmButtonColor: '#ffbd4a'
                });
              }
            } else if (input.endDate !== '') {
              if (input.startDate! < itemsInOrder.startDate && input.endDate! > itemsInOrder.startDate) { //當預約日早於訂單預約日且結束日晚於訂單預約日（時間與訂單重疊）
                hasWarning = true;
                Swal.fire({
                  icon: 'warning',
                  html: '請修改預約日期或預約時間</br>該日期之該時段已無空位',
                  padding: '3em',
                  color: '#5d3f0a',
                  background: '#fff',
                  confirmButtonText: '確認',
                  confirmButtonColor: '#ffbd4a'
                });
              } else if (input.startDate! > itemsInOrder.startDate && input.startDate! < itemsInOrder.endDate) {  //當預約日晚於訂單預約日且早於訂單結束日（在訂單日期之間發生）
                hasWarning = true;
                Swal.fire({
                  icon: 'warning',
                  html: '請修改預約日期或預約時間</br>該日期之該時段已無空位',
                  padding: '3em',
                  color: '#5d3f0a',
                  background: '#fff',
                  confirmButtonText: '確認',
                  confirmButtonColor: '#ffbd4a'
                });
              }
            }
          }
        }
      });
      if (!hasWarning) {
        this.empHttpService.editOrderDetailData(input).subscribe(rs => {
          const returnCode = rs.MWHEADER.RETURNCODE;
          if (returnCode === '0000') {
            this.dialogRef.close(true);
            Swal.fire({
              icon: 'success',
              title: '修改完成',
              width: 350,
              padding: '3em',
              background: '#fff',
              confirmButtonText: '確認',
              confirmButtonColor: '#ffbd4a'
            });
            this.dialogRef.close();
          } else if (returnCode === 'E001') {
            Swal.fire({
              icon: 'warning',
              title: '必填欄位不得為空',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '確認',
              confirmButtonColor: '#ffbd4a'
            });
          } else if (returnCode === 'E002') {
            Swal.fire({
              icon: 'error',
              title: '更新失敗',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor: '#ffbd4a'
            });
          } else if (returnCode === 'E702') {
            Swal.fire({
              icon: 'warning',
              title: '查無該筆購物車資料',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor: '#ffbd4a'
            });
          } else {
            Swal.fire({
              icon: 'warning',
              title: '其他系統異常',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor: '#ffbd4a'
            });
          }
        });
      }
    });
  }

  /** 關閉談窗 */
  closeDialog() {
    this.dialogRef.close();
  }

  /** 初始化-將選取資料帶到畫面顯示 */
  initialization() {
    // 將選取資料帶到畫面顯示
    this.form.patchValue({
      ...this.editData,
      startDate: this.editData.startDate,
      endDate: this.editData.endDate ? this.editData.endDate : '',
      startTime: this.editData.startTime,
      petName: this.editData.petId,
      petType: this.petTypePipe.transform(this.editData.petType),
    });

    // 若有 endDate 多設必填 Validators
    if (this.editData.endDate) {
      this.form.controls.endDate.setValidators(Validators.required);
      this.form.get('endDate')?.updateValueAndValidity();
    }
  }

  /** 自動帶出寵物類別 */
  setPetType() {
    for (const pet of this.petList) {
      if (pet.petId === this.form.value.petName) {
        const typeName = this.petTypePipe.transform(pet.petType);
        this.form.controls.petType.patchValue(typeName);
      }
    }
  }

  /** 相差天數 */
  dateDiff(startDate: Date, endDate: Date) {
    const diff = Math.abs(endDate.getTime() - startDate.getTime());
    return diff / 1000 / 60 / 60 / 24;
  }

  /** 服務日變動 價格為單次(日)價格 */
  StartDateChange(event: MatDatepickerInputEvent<Date>) {
    const selectedDate = new Date(event.value as Date);
    this.minEndDate = new Date(selectedDate);
    this.minEndDate.setDate(this.minEndDate.getDate() + 1);
    this.maxEndDate = new Date(selectedDate);
    this.maxEndDate.setDate(this.maxDate.getDate() + 91);
    this.form.controls.endDate.setValue('');
    this.form.controls.price.patchValue(this.selectServicePrice);
  }

  /** 結束日變動 自動算出價格 */
  EndDateChange(event: MatDatepickerInputEvent<Date>) {
    const _startDate = new Date(this.datePipe.transform(this.form.controls.startDate.value, 'yyyy-MM-dd')!);
    _startDate.setHours(_startDate.getUTCHours());

    const _endDate = new Date(this.form.value.endDate!);
    _endDate.setDate(_endDate.getDate());

    const setPrice =
      this.dateDiff(_startDate, _endDate) * Number(this.selectServicePrice);
    this.form.controls.price.patchValue(setPrice.toString());
  }
}
