import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderDetailEditComponent } from './order-detail-edit.component';

describe('OrderDetailEditComponent', () => {
  let component: OrderDetailEditComponent;
  let fixture: ComponentFixture<OrderDetailEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrderDetailEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrderDetailEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
