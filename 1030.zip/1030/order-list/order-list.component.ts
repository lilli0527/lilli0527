import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { CommCodeItems, Order, UpdateOrderDataTranrq } from 'src/app/shared/interfaces/EmpElement';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import { OrderEditComponent } from '../order-edit/order-edit.component';
import { EmpDataService } from 'src/app/shared/service/emp-data.service';
import { MatDialog } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.css'],
  providers: [DatePipe],
})
export class OrderListComponent implements OnInit {
  /**
   * 分頁
   * @type {MatPaginator}
   * @memberof OrderListComponent
   */
  @ViewChild('paginator', { static: true }) paginator!: MatPaginator;

  /** 資料總筆數 */
  length = 0;

  /** 目前頁碼 預設為0 */
  pageIndex = 0;

  /** 每頁呈現幾筆 預設為5 */
  pageSize = 5;

  /** 總頁數 */
  totalPage: number | undefined;

  /** 允許切換的每頁資料筆數 */
  pageSizeOptions = [5, 10];

  /** 分頁結果 */
  pageEvent: PageEvent | undefined;

  /** 初始訂單列表全查 */
  queryOrderId: string | undefined;

  /** 查詢訂購人姓名 */
  queryName: string | undefined;

  /** 查詢訂購人電話 */
  queryTel: string | undefined;

  /** 查詢訂購時間(起) */
  queryStartDate: string | undefined | null;

  /** 查詢訂購時間(訖) */
  queryEndDate: string | undefined | null;

  /** 查詢訂購狀態 */
  queryOrderProcess: string | undefined;

  /** 取得訂單相關資訊 */
  getOrderInfo = {
    orderId: '',
    custEmail: '',
  };

  /** 欄位名稱 */
  displayedColumns = [
    'orderId',
    'custName',
    'custTel',
    'total',
    'confirmDate',
    'orderProcess',
    'edit',
  ];

  /** 表格資料 */
  dataSource: Order[] = [];

  /** 查無資料 */
  dataNotFound = false;

  /** 訂單狀態選單 */
  orderProcessList: CommCodeItems[] = [];

  /** 訂單狀態選單 */
  orderStatusList = [
    { msg: '已確認', code: '1' },
    { msg: '已完成', code: '2' },
    { msg: '已取消', code: '3' }
  ]

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    orderId: [''],
    name: [''],
    tel: [''],
    startDate: [''],
    endDate: [''],
    orderProcess: ['']
  });

  constructor(
    private fb: FormBuilder,
    private empHttpService: EmpHttpService,
    private dataService: EmpDataService,
    public dialog: MatDialog,
    public router: Router
  ) { }

  /**
   * 取得「訂單編號」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderListComponent
   */
  public get orderId(): FormControl<string | null> {
    return this.form.controls.orderId;
  }

  /**
  * 取得「訂購人姓名」輸入值
  * @readonly
  * @type {(FormControl<string | null>)}
  * @memberof EmpListComponent
  */
  public get name(): FormControl<string | null> {
    return this.form.controls.name;
  }

  /**
   * 取得「訂購人電話」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpListComponent
   */
  public get tel(): FormControl<string | null> {
    return this.form.controls.tel;
  }

  /**
   * 取得「訂購時間(起)」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpListComponent
   */
  public get startDate(): FormControl<string | null> {
    return this.form.controls.startDate;
  }

  /**
   * 取得「訂購時間(訖)」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpListComponent
   */
  public get endDate(): FormControl<string | null> {
    return this.form.controls.endDate;
  }

  /**
   * 取得「訂單狀態」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpListComponent
   */
  public get orderProcess(): FormControl<string | null> {
    return this.form.controls.orderProcess;
  }

  ngOnInit(): void {
    this.queryOrder();

    this.empHttpService.queryMsgCode('ORDERPROCESS').subscribe((res) => {
      const responseData = res;
      this.orderProcessList = responseData.TRANRS.items;
    });
  }

  /**
   * 分頁器
   * @param event
   */
  getPaginatorData(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.queryPageDatabtn(this.pageIndex, this.pageSize);
  }

  /** 查詢訂單按鈕 */
  queryOrder() {
    this.dataNotFound = false;
    this.pageIndex = 0;
    this.queryOrderId = this.form.value.orderId;
    this.queryName = this.form.value.name;
    this.queryTel = this.form.value.tel;
    this.queryStartDate = this.form.value.startDate ? this.form.value.startDate : null;
    this.queryEndDate = this.form.value.endDate ? this.form.value.endDate : null;
    this.queryOrderProcess = this.form.value.orderProcess;

    this.empHttpService.queryOrder(0, this.pageSize, this.queryName, this.queryTel, this.queryOrderId, this.queryOrderProcess, this.queryStartDate!, this.queryEndDate!).subscribe((res) => {
      const responseData = res;

      if (responseData.MWHEADER.RETURNCODE !== '0000') {
        this.dataSource = [];
        this.dataNotFound = true;
        return;
      }

      this.length = responseData.TRANRS.orderNumber;
      this.totalPage = responseData.TRANRS.totalPage;

      this.dataSource = responseData.TRANRS.items as Order[];
      this.dataSource = this.dataSource.map<Order>((e) => ({
        ...e,
      }));
    });
  }

  /**
   * 分頁查詢按鈕
   * @param pageIndex
   * @param pageSize
   */
  queryPageDatabtn(pageIndex: number, pageSize: number) {
    this.dataNotFound = false;
    this.empHttpService.queryOrder(pageIndex, pageSize, this.queryName, this.queryTel, this.queryOrderId, this.queryOrderProcess, this.queryStartDate!, this.queryEndDate!).subscribe((res) => {
      const responseData = res;

      this.length = responseData.TRANRS.orderNumber;
      this.totalPage = responseData.TRANRS.totalPage;

      this.dataSource = responseData.TRANRS.items as Order[];
      this.dataSource = this.dataSource.map<Order>((e) => ({
        ...e,
      }));
    });
  }

  /** 全查按鈕 */
  queryAllData() {
    this.dataNotFound = false;
    this.pageIndex = 0;
    this.form.patchValue({
      orderId: '',
      name: '',
      tel: '',
      startDate: '',
      endDate: '',
      orderProcess: ''
    });
    this.queryOrder();
  }

  /** 轉至訂單明細 */
  queryOrderDetail(i: number) {
    this.dataNotFound = false;
    this.getOrderInfo = {
      orderId: this.dataSource[i].orderId,
      custEmail: this.dataSource[i].custEmail,
    };
    this.dataService.orderInfo = this.getOrderInfo;
    sessionStorage.setItem('orderId', this.dataSource[i].orderId);
    sessionStorage.setItem('custEmail', this.dataSource[i].custEmail);
    this.router.navigate(['/empPawsome/orderDetailList']);
  }

  /** 開啟修改彈窗 */
  openEditDialog(i: number) {
    // 將訂單 Id 資料存至 dataService
    this.dataService.orderId = this.dataSource[i].orderId;

    const dialogRef = this.dialog.open(OrderEditComponent, {
      width: '55%',
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.queryPageDatabtn(this.pageIndex, this.pageSize);
    });
  }

}
