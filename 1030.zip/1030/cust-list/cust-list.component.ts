import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { Customer } from 'src/app/shared/interfaces/EmpElement';
import { EmpDataService } from 'src/app/shared/service/emp-data.service';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import { CustEditComponent } from '../cust-edit/cust-edit.component';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cust-list',
  templateUrl: './cust-list.component.html',
  styleUrls: ['./cust-list.component.css'],
})
export class CustListComponent implements OnInit {
  /**
   * 分頁
   * @type {MatPaginator}
   * @memberof EmpListComponent
   */
  @ViewChild('paginator', { static: true }) paginator!: MatPaginator;

  /** 資料總筆數 */
  length = 0;

  /** 目前頁碼 預設為0 */
  pageIndex = 0;

  /** 每頁呈現幾筆 預設為5 */
  pageSize = 5;

  /** 總頁數 */
  totalPage: number | undefined;

  /** 允許切換的每頁資料筆數 */
  pageSizeOptions = [5, 10];

  /** 分頁結果 */
  pageEvent: PageEvent | undefined;

  /** 查詢會員信箱 */
  queryEmail: string | undefined;

  /** 查詢會員姓名 */
  queryName: string | undefined;

  /** 查詢會員電話 */
  queryTel: string | undefined;

  /** 欄位名稱 */
  displayedColumns = ['name', 'email', 'tel', 'sex', 'birthday', 'edit'];

  /** 表格資料 */
  dataSource: Customer[] = [];

  /** 查無資料 */
  dataNotFound = false;

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    email: [''],
    name: [''],
    tel: [''],
  });
  datePipe: any;

  constructor(
    private fb: FormBuilder,
    private empHttpService: EmpHttpService,
    private dataService: EmpDataService,
    public dialog: MatDialog
  ) { }

  /**
   * 取得「會員信箱」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof CustListComponent
   */
  public get email(): FormControl<string | null> {
    return this.form.controls.email;
  }

  /**
   * 取得「會員姓名」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof CustListComponent
   */
  public get name(): FormControl<string | null> {
    return this.form.controls.name;
  }

  /**
   * 取得「會員電話」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof CustListComponent
   */
  public get tel(): FormControl<string | null> {
    return this.form.controls.tel;
  }

  ngOnInit(): void {
    this.queryCustData();
  }

  /**
   * 分頁器
   * @param event
   */
  getPaginatorData(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.queryPageDatabtn(this.pageIndex, this.pageSize);
  }

  /** 初始查詢按鈕 */
  queryCustData() {
    this.dataNotFound = false;
    this.pageIndex = 0;
    this.queryEmail = this.form.value.email;
    this.queryName = this.form.value.name;
    this.queryTel = this.form.value.tel;
    this.empHttpService.queryCustData(0, this.pageSize, this.queryEmail, this.queryName, this.queryTel).subscribe((res) => {
      const responseData = res;

      if (responseData.MWHEADER.RETURNCODE !== '0000') {
        this.dataSource = [];
        this.dataNotFound = true;
        return;
      }

      this.length = responseData.TRANRS.cusNumber;
      this.totalPage = responseData.TRANRS.totalPage;

      this.dataSource = responseData.TRANRS.items as Customer[];
      this.dataSource = this.dataSource.map<Customer>((e) => ({
        ...e,
      }));
    });
  }

  /**
   * 分頁查詢按鈕
   * @param pageIndex
   * @param pageSize
   */
  queryPageDatabtn(pageIndex: number, pageSize: number) {
    this.dataNotFound = false;
    this.empHttpService.queryCustData(pageIndex, pageSize, this.queryEmail, this.queryName, this.queryTel).subscribe((res) => {
      const responseData = res;

      this.length = responseData.TRANRS.cusNumber;
      this.totalPage = responseData.TRANRS.totalPage;

      this.dataSource = responseData.TRANRS.items as Customer[];
      this.dataSource = this.dataSource.map<Customer>((e) => ({
        ...e,
      }));
    });
  }

  /** 全查按鈕 重新載入表格 */
  queryAllData() {
    this.dataNotFound = false;
    this.pageIndex = 0;
    this.form.patchValue({
      email: '',
      name: '',
      tel: '',
    });
    this.queryCustData();
  }

  /** 開啟修改彈窗 */
  openEditDialog(i: number) {
    // 將會員信箱資料存至 dataService
    this.dataService.custEmail = this.dataSource[i].email;

    const dialogRef = this.dialog.open(CustEditComponent, {
      width: '35%',
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.queryEmail = '';
      this.queryPageDatabtn(this.pageIndex, this.pageSize);
    });
  }
}
