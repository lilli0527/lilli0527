import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DialogComponent, DialogData } from 'src/app/shared/components/dialog/dialog.component';
import { CustDataItems, UpdateCustDataTranrq } from 'src/app/shared/interfaces/EmpElement';
import { EmpDataService } from 'src/app/shared/service/emp-data.service';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cust-edit',
  templateUrl: './cust-edit.component.html',
  styleUrls: ['./cust-edit.component.css'],
  providers: [DatePipe]
})
export class CustEditComponent implements OnInit {

  /** 欲修改之會員信箱 */
  selectEmail: string | undefined;

  /** 欲修改之資料 */
  editData = {} as CustDataItems;

  /** 密碼是否顯示 */
  hide = true;

  /** 員工性別選單 */
  sexList = [
    {
      key: 'F',
      value: '女',
    },
    {
      key: 'M',
      value: '男',
    },
  ];

  /** 欲修改之性別 */
  selectSex: string | undefined;

  /** 最大生日日期 */
  maxDate = new Date();

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.pattern(/^\S*$/), Validators.maxLength(20)]],
    tel: ['', [Validators.required, Validators.pattern(/^\d*$/), Validators.maxLength(10)]],
    password: ['', [Validators.required, Validators.pattern(/^\w*$/), Validators.minLength(6), Validators.maxLength(20)]],
    sex: [''],
    birthday: ['']
  });

  /**
   * 取得「會員名稱」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof CustEditComponent
   */
  public get name(): FormControl<string | null> {
    return this.form.controls.name;
  }

  /**
     * 取得「電話」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof CustEditComponent
   */
  public get tel(): FormControl<string | null> {
    return this.form.controls.tel;
  }

  /**
   * 取得「密碼」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof CustEditComponent
   */
  public get password(): FormControl<string | null> {
    return this.form.controls.password;
  }

  /**
   * 取得「性別」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof CustEditComponent
   */
  public get sex(): FormControl<string | null> {
    return this.form.controls.sex;
  }

  /**
   * 取得「生日」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof CustEditComponent
   */
  public get birthday(): FormControl<string | null> {
    return this.form.controls.birthday;
  }

  constructor(
    private fb: FormBuilder,
    private empHttpService: EmpHttpService,
    private dataService: EmpDataService,
    private datePipe: DatePipe,
    public dialogRef: MatDialogRef<DialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
  ) { }

  ngOnInit(): void {
    this.selectEmail = this.dataService.custEmail;

    this.empHttpService.queryCustByEmailData(0, 1, this.selectEmail).subscribe({
      next: res => {
        const responseData = res;
        this.editData = responseData.TRANRS.items[0];
        this.selectSex = this.sexList.find(element => element.key === this.editData.sex)?.value;
      },
      complete: () => {
        this.initialization();
      }
    });

  }

  editCust() {
    const editSex = !this.form.value.sex ? '' : this.sexList.find(element => element.value === this.form.value.sex)?.key;
    const editBirthday = !this.form.value.birthday ? '' : new Date(this.form.value.birthday);
    const updaterq = {
      ...this.form.value,
      custEmail: this.selectEmail,
      sex: editSex,
      birthday: editBirthday
    } as UpdateCustDataTranrq;

    this.empHttpService.editCustData(updaterq).subscribe(
      res => {
        const responseData = res;
        // 修改失敗跳出提示訊息
        if (responseData.MWHEADER.RETURNCODE !== '0000') {
          Swal.fire({
            icon: 'error',
            title: '修改失敗',
            text: responseData.MWHEADER.RETURNDESC,
            width: 350,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonText: '再試試',
            confirmButtonColor: '#ffbd4a'
          })
          return;
        }

        // 修改成功跳出提示訊息
        if (responseData.MWHEADER.RETURNCODE === '0000') {
          Swal.fire({
            icon: 'success',
            title: '修改成功',
            width: 350,
            padding: '3em',
            background: '#fff',
            confirmButtonText: '確認',
            confirmButtonColor: '#ffbd4a'
          })
          this.dialogRef.close();
        }
      });
  }

  closeDialog() {
    this.dialogRef.close();
  }

  /** 初始化-將選取資料帶到畫面顯示 */
  initialization() {
    // 將選取資料帶到畫面顯示
    this.form.patchValue({
      ...this.editData,
      birthday: this.datePipe.transform(this.editData.birthday, 'yyyy-MM-dd') as string,
      sex: this.selectSex,
    });
  }
}
