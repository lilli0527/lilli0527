package com.example.Pawsome.service.impl;

import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.Pawsome.dto.EMPTranrq;
import com.example.Pawsome.dto.EMPTranrs;
import com.example.Pawsome.dto.EMPTranrsTranrs;
import com.example.Pawsome.dto.EMPTranrsTranrsItems;
import com.example.Pawsome.dto.ONEORDERBYIDTranrq;
import com.example.Pawsome.dto.ONEORDERBYIDTranrs;
import com.example.Pawsome.dto.ONEORDERBYIDTranrsTranrs;
import com.example.Pawsome.dto.ONEORDERBYIDTranrsTranrsItems;
import com.example.Pawsome.dto.ORDERDETAILTranrq;
import com.example.Pawsome.dto.ORDERDETAILTranrs;
import com.example.Pawsome.dto.ORDERDETAILTranrsTranrs;
import com.example.Pawsome.dto.ORDERDETAILTranrsTranrsItems;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.dto.UPDATEEMPTranrq;
import com.example.Pawsome.dto.UPDATEEMPTranrqTranrq;
import com.example.Pawsome.dto.UPDATEEMPTranrs;
import com.example.Pawsome.entity.PsEmpEntity;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.repository.PsEmpEntityRepository;
import com.example.Pawsome.repository.PsOrderEntityRepository;
import com.example.Pawsome.service.EmpSvc;
import com.example.Pawsome.service.sql.SqlAction;
import com.example.Pawsome.service.sql.SqlUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class EmpSvcImpl implements EmpSvc {

	/** SqlAction */
	@Autowired
	private SqlAction sqlAction;

	/** SqlUtils */
	@Autowired
	private SqlUtils sqlUtils;

	@Autowired
	private PsEmpEntityRepository empRepo;

	@Autowired
	private PsOrderEntityRepository orderRepo;

	/** ObjectMapper */
	@Autowired
	private ObjectMapper objectMapper;

	/** EMP 員工資料查詢服務(單多筆) */
	private static final String EMP = "PAWSOME-EMP";

	/** UPDATEEMP 員工資料修改新增服務 */
	private static final String UPDATEEMP = "PAWSOME-UPDATEEMP";

	/** ONEORDERBYID 單筆訂單查詢服務 */
	private static final String ONEORDERBYID = "PAWSOME-ONEORDERBYID";

	/** ORDERDETAIL 單筆訂單細節查詢服務 */
	private static final String ORDERDETAIL = "PAWSOME-ORDERDETAIL";

	/** 交易成功代碼 */
	private static final String SUCCESSCODE = ReturnCodeAndDescEnum.SUCCESS.getCode();

	/** 交易成功訊息 */
	private static final String SUCCESSDESC = ReturnCodeAndDescEnum.SUCCESS.getDesc();

	/** 查無資料 */
	private static final String DATANOTFOUND = "E702";

	/** 更新失敗 */
	private static final String UPDATEFAIL = "E002";

	/** 刪除失敗 */
	private static final String DELETEFAIL = "E004";

	/** SQL_EMP */
	private static final String SQL_EMP = "EMP_QUERY_001.sql";

	/** SQL_ONEORDERBYID */
	private static final String SQL_ONEORDERBYID = "ONEORDERBYID_QUERY_001.sql";

	/** SQL_ORDERDETAIL */
	private static final String SQL_ORDERDETAIL = "ORDERDETAIL_QUERY_001.sql";

	/** dtf */
	private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss");

	private static final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

	/**
	 * 判斷是否為空值
	 * 
	 * @param param
	 * @return
	 */
	private String isNull(Object param) {
		if (param != null) {
			return param.toString();
		}
		return null;
	}

	@Override
	public EMPTranrs queryEmp(EMPTranrq request) throws DataNotFoundException, IOException {

		Map<String, Object> mapQueryEMP = new HashMap<>();
		String email = request.getTranrq().getEmail();
		if (!email.isBlank()) {
			mapQueryEMP.put("email", email);
		}
		String querySql = sqlUtils.getDynamicQuerySQL(SQL_EMP, mapQueryEMP);
		List<Map<String, Object>> queryEntitys = sqlAction.queryForList(querySql, mapQueryEMP);

		// 查詢是否有資料
		if (queryEntitys.isEmpty()) {
			throw new DataNotFoundException(EMP, DATANOTFOUND);
		}

		List<EMPTranrsTranrsItems> itemsList = new ArrayList<>();
		for (Map<String, Object> queryEntity : queryEntitys) {
			PsEmpEntity entity = objectMapper.convertValue(queryEntity, PsEmpEntity.class);
			EMPTranrsTranrsItems items = new EMPTranrsTranrsItems();
			items.setEmail(entity.getEmail());
			items.setPassword(entity.getPassword());
			items.setName(entity.getName());
			items.setTel(entity.getTel());
			items.setSex(isNull(entity.getSex()));
			items.setBirthday(isNull(entity.getBirthday()));
			items.setPermissions(entity.getPermissions());
			items.setIsQuit(entity.getIsQuit());
			itemsList.add(items);
		}

		EMPTranrsTranrs empTranrsTranrs = new EMPTranrsTranrs();
		empTranrsTranrs.setItems(itemsList);

		TranrsMwheader empTranrsMwheader = new TranrsMwheader();
		empTranrsMwheader.setMsgid(EMP);
		empTranrsMwheader.setReturnCode(SUCCESSCODE);
		empTranrsMwheader.setReturnDesc(SUCCESSDESC);

		EMPTranrs empTranrs = new EMPTranrs();
		empTranrs.setMwheader(empTranrsMwheader);
		empTranrs.setTranrs(empTranrsTranrs);

		return empTranrs;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public UPDATEEMPTranrs updateEmp(UPDATEEMPTranrq request) {
		UPDATEEMPTranrqTranrq requestData = request.getTranrq();
		Optional<PsEmpEntity> entityOptional = empRepo.findById(requestData.getEmail());
//		Optional.ofNullable(entityOptional.orElseGet(() -> empRepo.save(upadteEMP(requestData))));

		PsEmpEntity updateEntity = entityOptional.isEmpty() ? new PsEmpEntity() : entityOptional.get();
		updateEntity.setEmail(requestData.getEmail());
		updateEntity.setPassword(requestData.getPassword());
		updateEntity.setName(requestData.getName());
		updateEntity.setTel(requestData.getTel());
		updateEntity.setSex(requestData.getSex());
		updateEntity.setBirthday(Date.valueOf(requestData.getBirthday()));
		updateEntity.setPermissions(requestData.getPermissions());
		updateEntity.setIsQuit(requestData.getIsQuit());
		empRepo.save(updateEntity);

		TranrsMwheader upateEmpTranrsMwheader = new TranrsMwheader();
		upateEmpTranrsMwheader.setMsgid(UPDATEEMP);
		upateEmpTranrsMwheader.setReturnCode(SUCCESSCODE);
		upateEmpTranrsMwheader.setReturnDesc(SUCCESSDESC);

		UPDATEEMPTranrs updateEmpTranrs = new UPDATEEMPTranrs();
		updateEmpTranrs.setMwheader(upateEmpTranrsMwheader);

		return updateEmpTranrs;
	}

	@Override
	public ONEORDERBYIDTranrs queryOrderByID(ONEORDERBYIDTranrq request) throws DataNotFoundException, IOException {

		Map<String, Object> mapQueryOrderByID = new HashMap<>();
		mapQueryOrderByID.put("orderId", request.getTranrq().getOrderId());
		String querySql = sqlUtils.getDynamicQuerySQL(SQL_ONEORDERBYID, mapQueryOrderByID);
		List<Map<String, Object>> queryEntitys = sqlAction.queryForList(querySql, mapQueryOrderByID);

		// 查詢是否有資料
		if (queryEntitys.isEmpty()) {
			throw new DataNotFoundException(ONEORDERBYID, DATANOTFOUND);
		}

		Map<String, Object> queryEntity = queryEntitys.get(0);
		ONEORDERBYIDTranrsTranrsItems items = new ONEORDERBYIDTranrsTranrsItems();
		items.setOrderId(queryEntity.get("ORDER_ID").toString());
		items.setCustName(queryEntity.get("NAME").toString());
		items.setCustTel(queryEntity.get("TEL").toString());
		items.setTotal(queryEntity.get("TOTAL").toString());
		items.setOrderProcess(queryEntity.get("MSG").toString());

		List<ONEORDERBYIDTranrsTranrsItems> itemsList = new ArrayList<>();
		itemsList.add(items);

		ONEORDERBYIDTranrsTranrs oneOrderByIdTranrsTranrs = new ONEORDERBYIDTranrsTranrs();
		oneOrderByIdTranrsTranrs.setItems(itemsList);

		TranrsMwheader oneOrderByIdTranrsMwheader = new TranrsMwheader();
		oneOrderByIdTranrsMwheader.setMsgid(ONEORDERBYID);
		oneOrderByIdTranrsMwheader.setReturnCode(SUCCESSCODE);
		oneOrderByIdTranrsMwheader.setReturnDesc(SUCCESSDESC);

		ONEORDERBYIDTranrs oneOrderByIdTranrs = new ONEORDERBYIDTranrs();
		oneOrderByIdTranrs.setMwheader(oneOrderByIdTranrsMwheader);
		oneOrderByIdTranrs.setTranrs(oneOrderByIdTranrsTranrs);

		return oneOrderByIdTranrs;
	}

	@Override
    public ORDERDETAILTranrs queryOrderDetail(ORDERDETAILTranrq request) throws DataNotFoundException, IOException {
    	
    	Map<String, Object> mapQueryOrderDetai = new HashMap<>();
    	mapQueryOrderDetai.put("orderId", request.getTranrq().getOrderId());
    	String querySql = sqlUtils.getDynamicQuerySQL(SQL_ORDERDETAIL, mapQueryOrderDetai);
    	List<Map<String, Object>> queryEntitys = sqlAction.queryForList(querySql, mapQueryOrderDetai);
    	
    	// 查詢是否有資料
    	if (queryEntitys.isEmpty()) {
    		throw new DataNotFoundException(ORDERDETAIL, DATANOTFOUND);
    	}
    	
		List<ORDERDETAILTranrsTranrsItems> itemsList = new ArrayList<>();
		for (Map<String, Object> queryEntity : queryEntitys) {
			ORDERDETAILTranrsTranrsItems items = new ORDERDETAILTranrsTranrsItems();
	    	items.setServiceName(queryEntity.get("SERVICE_NAME").toString());
	    	items.setStartDate(queryEntity.get("START_DATE").toString());
	    	items.setEndDate(isNull(queryEntity.get("END_DATE")));
	    	items.setStartTime(queryEntity.get("START_TIME").toString());
	    	items.setPetName(queryEntity.get("PET_NAME").toString());
	    	items.setPetType(queryEntity.get("PET_TYPE").toString());
	    	items.setRemarks(isNull(queryEntity.get("REMARKS")));
	    	items.setPrice(queryEntity.get("PRICE").toString());
	    	items.setOrderProcess(queryEntity.get("MSG").toString());
	    	items.setUpdateEmp(queryEntity.get("EMP_NAME").toString());
	    	items.setUpdateTime(isNull(queryEntity.get("UPDATE_TIME")));
	    	itemsList.add(items);
	    }
    	
    	ORDERDETAILTranrsTranrs orderDetailTranrsTranrs = new ORDERDETAILTranrsTranrs();
    	orderDetailTranrsTranrs.setItems(itemsList);
    	
    	TranrsMwheader orderDetailTranrsMwheader = new TranrsMwheader();
    	orderDetailTranrsMwheader.setMsgid(ORDERDETAIL);
    	orderDetailTranrsMwheader.setReturnCode(SUCCESSCODE);
    	orderDetailTranrsMwheader.setReturnDesc(SUCCESSDESC);
    	
    	ORDERDETAILTranrs orderDetailTranrs = new ORDERDETAILTranrs();
    	orderDetailTranrs.setMwheader(orderDetailTranrsMwheader);
    	orderDetailTranrs.setTranrs(orderDetailTranrsTranrs);
    	
    	return orderDetailTranrs;
    }

}
