package com.example.Pawsome.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonAlias;

import lombok.Data;

@Data
@Entity
@Table(name = "PS_EMP")
public class PsEmpEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @NotBlank
    @JsonAlias("EMAIL")
    @Column(name = "EMAIL")
    private String email;

    @NotBlank
    @JsonAlias("PASSWORD")
    @Column(name = "PASSWORD")
    private String password;
    
    @NotBlank
    @JsonAlias("NAME")
    @Column(name = "NAME")
    private String name;

    @NotBlank
    @JsonAlias("TEL")
    @Column(name = "TEL")
    private String tel;
    
    @JsonAlias("SEX")
    @Column(name = "SEX")
    private String sex;
    
    @JsonAlias("BIRTHDAY")
    @Column(name = "BIRTHDAY")
    private Date birthday;

    @NotBlank
    @JsonAlias("PERMISSIONS")
    @Column(name = "PERMISSIONS")
    private String permissions;
    
    @NotBlank
    @JsonAlias("ISQUIT")
    @Column(name = "ISQUIT")
    private String isQuit;
    
}
