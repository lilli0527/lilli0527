package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@Data
public class TranrsMwheader {
    
    /** MSGID */
    @JsonProperty("MSGID")
    @NotBlank(message = "MSGID 不得為空")
    @Size(message = "MSGID 長度不得超過20", max = 20)
    private String msgid;
    
    /** RETURNCODE 處理結果代碼 */
    @JsonProperty("RETURNCODE")
    @NotBlank(message = "處理結果代碼不得為空")
    @Size(message = "處理結果代碼長度不得超過4", max = 4)
    private String returnCode;
    
    /** RETURNDESC 處理結果訊息 */
    @JsonProperty("RETURNDESC")
    @NotBlank(message = "處理結果訊息不得為空")
    @Size(message = "處理結果訊息長度不得超過128", max = 128)
    private String returnDesc;

}
