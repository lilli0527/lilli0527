package com.example.Pawsome.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.repository.PsOrderDetailEntityRepository;
import com.example.Pawsome.service.OrderDetailSvc;

@Service
public class OrderDetailSvcImpl implements OrderDetailSvc {

    @Autowired
    private PsOrderDetailEntityRepository orderDetailRepo;
    
}
