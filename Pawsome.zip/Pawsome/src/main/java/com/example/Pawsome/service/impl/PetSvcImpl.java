package com.example.Pawsome.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.repository.PsPetEntityRepository;
import com.example.Pawsome.service.PetSvc;

@Service
public class PetSvcImpl implements PetSvc {

    @Autowired
    private PsPetEntityRepository petRepo;
    
}
