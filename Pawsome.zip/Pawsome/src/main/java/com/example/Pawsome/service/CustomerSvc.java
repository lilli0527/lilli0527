package com.example.Pawsome.service;

public interface CustomerSvc {

}
