package com.example.Pawsome.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
@Entity
@Table(name = "PS_COMMCODE")
public class PsCommCodeEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id  
    @NotBlank
    @Column(name = "COMMCODE")
    private String commCode;

    @Id 
    @NotBlank
    @Column(name = "TYPE")
    private String type;

    @NotBlank
    @Column(name = "MSG")
    private String msg;

}
