package com.example.Pawsome.entity;

import java.io.Serializable;

import javax.persistence.Column;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class PsOrderDetailPK implements  Serializable {

    private static final long serialVersionUID = 1L;
    
    @Column(name = "ORDER_ID")
    private String orderId;
    
    @Column(name = "ITEM_ID")
    private String itemId;
    
    public PsOrderDetailPK() {
    	
    }

}
