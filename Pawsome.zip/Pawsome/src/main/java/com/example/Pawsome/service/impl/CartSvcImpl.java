package com.example.Pawsome.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.repository.PsShoppingCartEntityRepository;
import com.example.Pawsome.service.CartSvc;

@Service
public class CartSvcImpl implements CartSvc {

    @Autowired
    private PsShoppingCartEntityRepository cartRepo;
    
}
