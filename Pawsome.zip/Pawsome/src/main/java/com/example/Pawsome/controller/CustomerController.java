package com.example.Pawsome.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.service.CustomerSvc;

@RestController
@RequestMapping("/api")
public class CustomerController {

    @Autowired
    private CustomerSvc customerSvc;
    
}
