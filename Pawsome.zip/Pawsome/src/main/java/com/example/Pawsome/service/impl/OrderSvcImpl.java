package com.example.Pawsome.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.repository.PsOrderEntityRepository;
import com.example.Pawsome.service.OrderSvc;

@Service
public class OrderSvcImpl implements OrderSvc {

    @Autowired
    private PsOrderEntityRepository orderRepo;
    
}
