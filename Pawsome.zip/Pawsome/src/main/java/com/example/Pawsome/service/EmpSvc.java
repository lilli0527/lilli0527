package com.example.Pawsome.service;

import java.io.IOException;

import com.example.Pawsome.dto.EMPTranrq;
import com.example.Pawsome.dto.EMPTranrs;
import com.example.Pawsome.dto.ONEORDERBYIDTranrq;
import com.example.Pawsome.dto.ONEORDERBYIDTranrs;
import com.example.Pawsome.dto.ORDERDETAILTranrq;
import com.example.Pawsome.dto.ORDERDETAILTranrs;
import com.example.Pawsome.dto.UPDATEEMPTranrq;
import com.example.Pawsome.dto.UPDATEEMPTranrs;
import com.example.Pawsome.exception.DataNotFoundException;

public interface EmpSvc {
    
	EMPTranrs queryEmp(EMPTranrq request) throws DataNotFoundException, IOException;
    
    UPDATEEMPTranrs updateEmp(UPDATEEMPTranrq request);
    
    ONEORDERBYIDTranrs queryOrderByID(ONEORDERBYIDTranrq request) throws DataNotFoundException, IOException;

    ORDERDETAILTranrs queryOrderDetail(ORDERDETAILTranrq request) throws DataNotFoundException, IOException;

}
