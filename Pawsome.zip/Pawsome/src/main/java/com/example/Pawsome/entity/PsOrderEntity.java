package com.example.Pawsome.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonAlias;

import lombok.Data;

@Data
@Entity
@Table(name = "PS_ORDER")
public class PsOrderEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @NotBlank
    @JsonAlias("ORDER_ID")
    @Column(name = "ORDER_ID")
    private String orderId;

    @NotBlank
    @JsonAlias("CUST_EMAIL")
    @Column(name = "CUST_EMAIL")
    private String custEmail;

    @NotNull
    @JsonAlias("TOTAL")
    @Column(name = "TOTAL")
    private int total;

    @NotBlank
    @JsonAlias("ORDER_PROCESS")
    @Column(name = "ORDER_PROCESS")
    private String orderProcess;

}
