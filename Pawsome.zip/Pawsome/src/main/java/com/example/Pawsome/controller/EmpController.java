package com.example.Pawsome.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.dto.EMPTranrq;
import com.example.Pawsome.dto.EMPTranrs;
import com.example.Pawsome.dto.ONEORDERBYIDTranrq;
import com.example.Pawsome.dto.ONEORDERBYIDTranrs;
import com.example.Pawsome.dto.ORDERDETAILTranrq;
import com.example.Pawsome.dto.ORDERDETAILTranrs;
import com.example.Pawsome.dto.UPDATEEMPTranrq;
import com.example.Pawsome.dto.UPDATEEMPTranrs;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.ErrorInputException;
import com.example.Pawsome.service.EmpSvc;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class EmpController {

    @Autowired
    private EmpSvc empSvc;

    /** EMP 員工資料查詢服務(單多筆) */
    private static final String EMP = "PAWSOME-EMP";
    
    /** UPDATEEMP 員工資料修改新增服務 */
    private static final String UPDATEEMP = "PAWSOME-UPDATEEMP";

    /** 必填欄位不完整 */
    private static final String ERRORINPUT = "E001";

    @PostMapping(value = "/emp")
    public EMPTranrs queryEmp2(@Valid
    		@RequestBody
    		EMPTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException, IOException {
    	// 檢查上行 Errors 是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException(EMP + sb, ERRORINPUT);
        }
    	return empSvc.queryEmp(request);
    } 
    
    @PostMapping(value = "/updateEmp")
    public UPDATEEMPTranrs updateEmp(@Valid
    		@RequestBody
    		UPDATEEMPTranrq request, Errors errors) throws ErrorInputException {
    	// 檢查上行 Errors 是否有錯
    	if (errors.hasErrors()) {
    		StringBuilder sb = new StringBuilder();
    		for (ObjectError error : errors.getAllErrors()) {
    			sb.append(error.getDefaultMessage()).append("; ");
    		}
    		throw new ErrorInputException(UPDATEEMP + sb, ERRORINPUT);
    	}
    	return empSvc.updateEmp(request);
    }
    
    @PostMapping(value = "/oneOrderByID")
    public ONEORDERBYIDTranrs queryOrderByID(@Valid
    @RequestBody
    ONEORDERBYIDTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException, IOException {
        return empSvc.queryOrderByID(request);
    }

    @PostMapping(value = "/orderDetail")
    public ORDERDETAILTranrs queryOrderDetail(@Valid
    @RequestBody
    ORDERDETAILTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException, IOException {
        return empSvc.queryOrderDetail(request);
    }
}
