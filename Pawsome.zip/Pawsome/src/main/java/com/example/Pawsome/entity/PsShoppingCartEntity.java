package com.example.Pawsome.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
@Entity
@Table(name = "PS_SHOPPING_CART")
public class PsShoppingCartEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @NotBlank
    @Column(name = "ITEM_ID")
    private String itemId;

    @NotBlank
    @Column(name = "CUST_EMAIL")
    private String custEmail;

    @NotBlank
    @Column(name = "SERVICE_ID")
    private String serviceId;

    @NotBlank
    @Column(name = "START_DATE")
    private Date startDate;

    @NotBlank
    @Column(name = "END_DATE")
    private Date endDate;

    @NotBlank
    @Column(name = "START_TIME")
    private String startTime;

    @NotBlank
    @Column(name = "PET_ID")
    private String petId;

    @Column(name = "REMARKS")
    private String remarks;
    
    @NotBlank
    @Column(name = "ISSUBMIT")
    private String isSubmit;

}
