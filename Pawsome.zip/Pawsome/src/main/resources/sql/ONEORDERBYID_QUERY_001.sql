--select *
-- from STUDENT.PS_ORDER PO
-- left join STUDENT.PS_CUSTOMER PC 
--  on PO.CUST_EMAIL = PC.EMAIL
-- left join STUDENT.PS_COMMCODE CODE 
--  on PO.ORDER_PROCESS = CODE.COMMCODE
--  and CODE.TYPE = 'ORDERPROCESS' 
-- order by PO.ORDER_ID
-- offset :pageSizeIndex row
-- fetch next :pageSize rows only
 
select *
 from PS_ORDER PO
 left join PS_CUSTOMER PC 
  on PO.CUST_EMAIL = PC.EMAIL
 left join PS_COMMCODE CODE 
  on PO.ORDER_PROCESS = CODE.COMMCODE
  and CODE.TYPE = 'ORDERPROCESS'
 where PO.ORDER_ID = :orderId
 order by PO.ORDER_ID
