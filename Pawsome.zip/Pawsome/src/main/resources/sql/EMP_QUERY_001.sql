--select *
-- from STUDENT.PS_EMP EMP
-- left join STUDENT.PS_COMMCODE CODE 
--  on EMP.PERMISSIONS = CODE.COMMCODE
--  and CODE.TYPE = 'PERMISSIONS' 
-- [where EMP.EMAIL like :email]
-- order by EMP.EMAIL
-- offset :pageSizeIndex row
-- fetch next :pageSize rows only
 
 select *
 from PS_EMP EMP
 left join PS_COMMCODE CODE 
  on EMP.PERMISSIONS = CODE.COMMCODE
  and CODE.TYPE = 'PERMISSIONS' 
 [where EMP.EMAIL like :email]
 order by EMP.EMAIL
