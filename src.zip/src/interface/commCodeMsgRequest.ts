export interface CommCodeMsgRequest {
  MWHEADER: Mwheader;
  TRANRQ:   Tranrq;
}

export interface Mwheader {
  MSGID: string;
}

export interface Tranrq {
  type: string;
}
