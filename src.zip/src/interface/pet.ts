export interface Pet {
  number: number;
  name: string;
  type: string;
  sex: string;
  birth: string;
  weight: string;
  remarks: string;
}



