import { DialogData } from "src/app/updatepet/updatepet.component";

export interface OnePetByIDRequest {
  MWHEADER: Mwheader;
  TRANRQ: Tranrq;
}

export interface Mwheader {
  MSGID: string;
}

export interface Tranrq {
  petId: number;
}
