export interface OrderDetailResponse {
  MWHEADER: Mwheader;
  TRANRS:   Tranrs;
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranrs {
  totalPage:  number;
  totalCount: number;
  pageNumber: number;
  pageSize:   number;
  items:      Item[];
}

export interface Item {
  serviceName:  string;
  startDate:    string;
  endDate:      string;
  startTime:    string;
  petName:      string;
  petType:      string;
  remarks:      string;
  price:        string;
  orderProcess: string;
  updateEmp:    string;
  updateTime:   string;
  itemId:       string;
}
