export interface OrderDetailRequest {
  MWHEADER: Mwheader;
  TRANRQ:   Tranrq;
}

export interface Mwheader {
  MSGID: string;
}

export interface Tranrq {
  pageNumber: number;
  pageSize:   number;
  orderId:    string;
}
