export interface UpdateCustomerRequest {
  MWHEADER: Mwheader;
  TRANRQ:   Tranrq;
}

export interface Mwheader {
  MSGID: string;
}

export interface Tranrq {
  custEmail: string;
  password:  string;
  name:      string;
  tel:       string;
  sex:       string;
  birthday:  string;
}
