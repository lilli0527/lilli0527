export interface UpdateOrderRequest {
  MWHEADER: Mwheader;
  TRANRQ:   Tranrq;
}

export interface Mwheader {
  MSGID: string;
}

export interface Tranrq {
  orderId:      string;
  custEmail:    string;
  total:        number;
  orderProcess: string;
}
