export interface InsertPetResponse {
  MWHEADER: Mwheader;
  TRANRS:   Tranrs;
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranrs {
}
