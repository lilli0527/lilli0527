import { Injectable, OnInit } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';
/**
 *
 * 員工路由守衛
 * @export
 * @class EmpauthGuard
 * @implements {CanActivate}
 */
@Injectable({
  providedIn: 'root'
})

export class EmpauthGuard implements CanActivate, OnInit {
  constructor(
    private router: Router,
    private loginService: LoginService
  ) { }

  responseData: any = {};
  EMPData: string[] = [];

  ngOnInit(): void {

  }

  //擋如果沒有登入empuser，打購物車/url會導至EMPLOGIN
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    let token = sessionStorage.getItem('empuser');
    sessionStorage.setItem
    // 當前近來的路徑
    let url: string = state.url;

    this.loginService.getEmp().subscribe({
      next: (response) => {
        if (response) {
          this.responseData = response;
          for(let i = 0; i < this.responseData.TRANRS.items.length; i++){
            this.EMPData.push(this.responseData.TRANRS.items[i].email);
          }
          console.log(this.EMPData);
        } else {
          console.log('未收到數據');
        }
      },
      error: (err) => {
        console.log('err', err);
      }
    });

    // 新增去查現有的憑證碼token
    if (!token || !this.EMPData.includes(token) ) {
      Swal.fire({
        icon: 'warning',
        title: '嘿嘿確認你有權限嗎?',
        width: 350,
        padding: '3em',
        background: '#fff',
      })
      this.router.navigate(['/loginemp']);
      return false;
    }
    else {
      return true;
    }

    // if (!token) {
    //   Swal.fire({
    //     icon: 'warning',
    //     title: '嘿嘿確認你有權限嗎?',
    //     width: 350,
    //     padding: '3em',
    //     background: '#fff',
    //   })
    //   this.router.navigate(['/loginemp']);
    //   return false;
    // }
    // else {
    //   return true;
    // }
  }




}
