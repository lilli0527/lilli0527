import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { InsertOrderTranrqItems } from '../interfaces/insertOrder/insertOrderTranrqItems.interface';
import { InsertOrderTranrq } from '../interfaces/insertOrder/insertOrderTranrq.interface';
import { InsertOrderTranrs } from '../interfaces/insertOrder/insertOrderTranrs.interface';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http: HttpClient) { }

  /**
   * 訂單資料新增服務
   * @param params
   * @returns
   */
  insert(params: InsertOrderTranrqItems[]) {
    const rqBody: InsertOrderTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-INSERTORDER'
      },
      TRANRQ: {
        items: params.map(param => ({
          custEmail: param.custEmail,
          itemId: param.itemId,
          serviceTotalPrice: param.serviceTotalPrice,
          orderProcess: param.orderProcess,
          confirmDate: param.confirmDate
        }))
      }
    };
    return this.http.post<InsertOrderTranrs>('http://localhost:8080/insertOrder', rqBody);
  }

}
