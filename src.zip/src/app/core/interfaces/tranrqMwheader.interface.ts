export interface TranrqMwheader {
  MSGID: string
}
