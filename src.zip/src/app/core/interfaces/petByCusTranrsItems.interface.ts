export interface PetByCusTranrsItems {
  pet_id: number,
  cust_email: string,
  name: string,
  type: string,
  sex: string,
  birth: string,
  weight: string,
  remarks: string
}
