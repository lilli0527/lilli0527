import { TranrsMwheader } from "../tranrsMwheader.interface"

export interface InsertOrderTranrs {
  MWHEADER: TranrsMwheader,
  TRANRS: {
    orderId: string
  }
}
