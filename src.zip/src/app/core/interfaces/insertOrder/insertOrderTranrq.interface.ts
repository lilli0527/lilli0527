import { TranrqMwheader } from "../tranrqMwheader.interface"
import { InsertOrderTranrqItems } from "./insertOrderTranrqItems.interface"

export interface InsertOrderTranrq {
  MWHEADER: TranrqMwheader,
  TRANRQ: {
    items: InsertOrderTranrqItems[]
  }
}
