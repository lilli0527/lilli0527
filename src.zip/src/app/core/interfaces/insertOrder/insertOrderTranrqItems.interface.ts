export interface InsertOrderTranrqItems {
  custEmail: string,
  itemId: string,
  serviceTotalPrice: string,
  orderProcess: string,
  confirmDate: string | null
}
