export interface InsertCartTranrqItems {
  custEmail: string,
  serviceId: number,
  startDate: string | null,
  endDate: string | null,
  startTime: string,
  petId: number,
  remarks: string,
  isSubmit: string,
}
