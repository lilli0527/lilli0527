import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberPetComponent } from './member-pet.component';

describe('MemberPetComponent', () => {
  let component: MemberPetComponent;
  let fixture: ComponentFixture<MemberPetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MemberPetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MemberPetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
