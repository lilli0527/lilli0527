import { Component, OnInit } from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { OrderByCustomerRequest } from 'src/interface/orderByCustomerRequest';
import { Tranr } from 'src/interface/orderByCustomerResponse';
import { UpdateOrderRequest } from 'src/interface/updateOrderRequest';
import { MemberService } from 'src/service/member.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-member-order',
  templateUrl: './member-order.component.html',
  styleUrls: ['./member-order.component.css']
})
export class MemberOrderComponent implements OnInit {

  constructor(private memberService: MemberService, private router: Router) { }
  /**TABLE欄位*/
  displayedColumns: string[] = [
    'number',
    'orderId',
    'total',
    'confirmDate',
    'orderProcess',
    'viewMore',
    'cancel',
  ];

  dataSource: Tranr[] = [];

  /** 分頁:總體頁數*/
  totalCount: number = 0;
  /** 分頁:從第幾筆顯示*/
  pageNumber: number = 0;
  /** 分頁:每頁顯示幾筆 */
  pageSize: number = 5;
  ngOnInit(): void {
    /** 會員訂單列表 */
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-ONEPETBYCUSTOMER"
      },
      TRANRQ: {
        custEmail: '123@gmail.com',
      }
    }
    this.memberService.orderByCustomer(request as OrderByCustomerRequest).subscribe(
      response => {
        console.log(response);
        this.dataSource = response.TRANRS;
      })

  }


  /** 查看更多按鈕 */
  viewMore(index: number) {
    this.router.navigate(['/orderDetail'], { queryParams: { orderId: this.dataSource[index].orderId }, skipLocationChange: true })
    // this.router.navigate(['/orderDetail'], { queryParams: { orderData: this.dataSource[index]} })
  }

  /** 會員管理-會員預約管理取消按鈕*/
  cancel(index: number) {
    /** 先詢問是否取消 */
    Swal.fire({
      title: '確定要取消這筆訂單嗎?',
      // showDenyButton: true,
      showCancelButton: true,
      confirmButtonText: '確定取消',
      denyButtonText: `取消`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      console.log(this.dataSource[index].orderId);

      if (result.isConfirmed) {
        const request = {
          MWHEADER: {
            MSGID: "PAWSOME-UPDATEORDER"
          },
          TRANRQ: {
            orderId: this.dataSource[index].orderId,
            custEmail: "123@gmail.com",
            total: this.dataSource[index].total,
            orderProcess: "3"
          }
        }
        this.memberService.updateOrder(request as UpdateOrderRequest).subscribe(
          response1 => {
            console.log(response1);

          })
        }
      })
       /** 會員訂單列表 */
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-ONEPETBYCUSTOMER"
      },
      TRANRQ: {
        custEmail: '123@gmail.com',
      }
    }
    this.memberService.orderByCustomer(request as OrderByCustomerRequest).subscribe(
      response => {
        console.log(response);
        this.dataSource = response.TRANRS;
      })
      Swal.fire('取消成功', '', 'success');
  }





  //當前頁變化時執行
  OnPageChange(pageEvent: PageEvent) {
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-ORDERBYCUSTOMER"
      },
      TRANRQ: {
        pageNumber: pageEvent.pageIndex, //設置當前頁
        pageSize: pageEvent.pageSize, //設置一項紀錄數
        orderId: "string",
        itemId: "string"
      }
    }
    // this.storeService.queryData(request as QueryRequest).subscribe(
    //   response => {
    //     if (response.TRANRS.items.store_name === null) {
    //       this.snackBar.open('查無資料', 'close', {
    //         duration: 5000,
    //         verticalPosition: 'top'
    //       });
    //       return;
    //     }
    //     this.dataSource = response.TRANRS.items;
    //     this.totalCount = response.TRANRS.totalCount;
    //   });

  }
}













