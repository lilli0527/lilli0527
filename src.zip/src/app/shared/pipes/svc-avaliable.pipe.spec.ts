import { SvcAvaliablePipe } from './svc-avaliable.pipe';

describe('SvcAvaliablePipe', () => {
  it('create an instance', () => {
    const pipe = new SvcAvaliablePipe();
    expect(pipe).toBeTruthy();
  });
});
