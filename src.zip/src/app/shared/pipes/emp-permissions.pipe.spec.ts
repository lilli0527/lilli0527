import { EmpPermissionsPipe } from './emp-permissions.pipe';

describe('EmpPermissionsPipe', () => {
  it('create an instance', () => {
    const pipe = new EmpPermissionsPipe();
    expect(pipe).toBeTruthy();
  });
});
