import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'svcAvaliable'
})
export class SvcAvaliablePipe implements PipeTransform {

  transform(isAvaliable :string): string {
    return isAvaliable === 'y' ? '上架中' : '下架中';
  }

}
