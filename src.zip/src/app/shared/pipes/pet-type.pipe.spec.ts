import { PetTypePipe } from './pet-type.pipe';

describe('PetTypePipe', () => {
  it('create an instance', () => {
    const pipe = new PetTypePipe();
    expect(pipe).toBeTruthy();
  });
});
