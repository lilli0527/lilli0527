import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmpDataService {

  /** 員工信箱 */
  empEmail: string | undefined;

  /** 會員信箱 */
  custEmail: string | undefined;

  /** 訂單 Id */
  orderId: string | undefined;

  /** 取得訂單相關資訊 */
  orderInfo = {
    orderId: '',
    custEmail: ''
  };

  /** 訂單明細 itemId */
  orderDetailItemId: string | undefined;

  constructor() { }
}
