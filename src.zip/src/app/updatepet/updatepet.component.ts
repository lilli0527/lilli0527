import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { typeArrInterface } from 'src/interface/commCodeMsgResponse';
import { MemberService } from 'src/service/member.service';
import Swal from 'sweetalert2';

export interface DialogData {
  petId: string;
}

@Component({
  selector: 'app-updatepet',
  templateUrl: './updatepet.component.html',
  styleUrls: ['./updatepet.component.css']
})
export class UpdatepetComponent implements OnInit {
  typeArr: typeArrInterface[] = []
  form = this.fb.nonNullable.group({
    petName: ['', Validators.required],
    type: ['', Validators.required],
    sex: [''],
    birth: [''],
    weight: [''],
    remarks: ['']
  });
  constructor(private memberService: MemberService, private fb: FormBuilder, public dialogRef: MatDialogRef<UpdatepetComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) { }

  ngOnInit(): void {
    const request = {
      MWHEADER: {
        MSGID: 'PAWSOME-COMMCODEMSG'
      },
      TRANRQ: {
        type: 'PET'
      }
    }
    this.memberService.typeData(request).subscribe(
      response => {
        console.log(response.TRANRS.items);

        this.typeArr = response.TRANRS.items;

      });

      console.log(this.data.petId);

    /** 修改按鈕點進去要先載入選取的那筆資料剛剛的資料(用Dialog帶pet_id過來) */
    const request1 = {
      MWHEADER: {
        MSGID: 'PAWSOME-ONEPETBYID'
      },
      TRANRQ: {
        petId: Number(this.data.petId)
      }
    }
    this.memberService.onePetById(request1).subscribe(
      response1 => {
        console.log(response1);
        console.log(response1.TRANRS[0].birth);

        this.form.controls.petName.setValue(response1.TRANRS[0].name);
        this.form.controls.type.setValue(response1.TRANRS[0].type);
        this.form.controls.sex.setValue(response1.TRANRS[0].sex);
        this.form.controls.birth.setValue(response1.TRANRS[0].birth);
        this.form.controls.weight.setValue(response1.TRANRS[0].weight);
        this.form.controls.remarks.setValue(response1.TRANRS[0].remarks);

      });
  }
  /** 新增頁面的確定新增按鈕 */
  updateData() {
    const request = {
      MWHEADER: {
        "MSGID": "PAWSOME-UPDATEPET"
      },
      TRANRQ: {
        petId:  Number(this.data.petId),
        custEmail: "123@gmail.com",
        petName: this.form.value.petName,
        petType: this.form.value.type,
        sex: this.form.value.sex,
        birth: this.form.value.birth,
        weight: this.form.value.weight,
        remarks: this.form.value.remarks
      }
    }
    this.memberService.updatePet(request).subscribe(
      response => {
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: '修改成功',
          showConfirmButton: false,
          timer: 1500
        })

      });
  }

  /**新增頁面的回上一頁按鈕 */
  editBack() {

  }
  close() {
    this.dialogRef.close();
  }

  /** 修改按鈕要修改剛剛的資料(用Dialog帶pet_id過來) */


}
