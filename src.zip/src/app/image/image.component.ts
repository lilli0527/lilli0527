import { animate } from '@angular/animations';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { OneCustomerRequest } from 'src/interface/oneCustomerRequest';
import { MemberService } from 'src/service/member.service';

@Component({
  selector: 'app-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.css']
})
export class ImageComponent implements OnInit {
  imagePath: string = '';
  alttext: string = 'memberPhoto';
  constructor(private memberService: MemberService, public dialogRef: MatDialogRef<ImageComponent>) { }
  request: any;
  @ViewChild('fileInput') fileInput!: ElementRef;
  ngOnInit(): void {
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-ONECUSTOMER"
      },
      TRANRQ: {
        email: '123@gmail.com',
        pageNumber: 0,
        pageSize: 5
      }
    }
    this.memberService.oneCustomer(request as OneCustomerRequest).subscribe(
      response => {
        console.log(response);
        this.imagePath = response.TRANRS.imgData;
        console.log(response.TRANRS.items[0]);
      })
  }
  close() {
    this.dialogRef.close();
  }
  onFileSelected(event: any) {
    const fileToUpload: File | null = event.target.files[0] || null;
    if (fileToUpload) {
      this.uploadImg(fileToUpload, '123@gmail.com');
    }
  }

  triggerFileInput() {
    this.fileInput.nativeElement.click();
  }
  /** 上傳相片按鈕 */
  uploadImg(file: File, imageId: string) {
    /** 上傳圖片 */
    const formData: FormData = new FormData();
    formData.append('file', file);
    formData.append('imageId', '123@gmail.com');

    this.memberService.updateImage(file, imageId).subscribe(
      response => {
        console.log("上傳成功", response);

        /** 上傳完再打一次 */
        const request = {
          MWHEADER: {
            MSGID: "PAWSOME-ONECUSTOMER"
          },
          TRANRQ: {
            email: '123@gmail.com',
            pageNumber: 0,
            pageSize: 5
          }
        }
        this.memberService.oneCustomer(request as OneCustomerRequest).subscribe(
          response => {
            console.log(response);
            this.imagePath = response.TRANRS.imgData;
            console.log(response.TRANRS.items[0]);
          });
      },

    );



  }
  /** 移除目前大頭貼照片中的空白頭圖片拿取 */
  dataURLtoFile(dataUrl: string) {
    //去除前綴字
    dataUrl = dataUrl.replace('data:image/jpeg;base64,', '');
    //將Base64轉換成字節數組
    const byteArray = new Uint8Array(
      atob(dataUrl).split('').map((char) => char.charCodeAt(0))
    );
    const file = new Blob([byteArray], { type: 'image/jpeg.' });

    const imageFile = new File([file], 'image.jpg', { type: 'image/jpeg' })
    return imageFile;
  }



  /** 移除目前的大頭照功能 */
  clearImg() {
    /** 先打一支getImage為了拿到空白圖 */
    this.memberService.getImage().subscribe(
      response => {
        console.log(response.TRANRS);
        const imageString = response.TRANRS;
        const imageFile = this.dataURLtoFile(imageString);
        console.log('有跑到');
        if (imageFile) {
          this.uploadImg(imageFile, '123@gmail.com');
          console.log('有跑到2');

        }
      });
  }

}






