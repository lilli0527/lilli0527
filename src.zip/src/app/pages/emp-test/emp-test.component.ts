import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { PageEvent } from '@angular/material/paginator';


import { MatSnackBar } from '@angular/material/snack-bar';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import { EmpPermissionsPipe } from 'src/app/shared/pipes/emp-permissions.pipe';
import { EmpIsQuitPipe } from 'src/app/shared/pipes/emp-is-quit.pipe';
import { SnackbarComponent } from 'src/app/shared/components/snackbar/snackbar.component';
import { Emp } from 'src/app/shared/interfaces/EmpElement';
import { MatTableDataSource } from '@angular/material/table';


@Component({
  selector: 'app-emp-test',
  templateUrl: './emp-test.component.html',
  styleUrls: ['./emp-test.component.css'],
  providers: [EmpPermissionsPipe, EmpIsQuitPipe]
})
export class EmpTestComponent implements OnInit {

  /** 資料總筆數 */
  length = 0;

  /** 目前頁碼 預設為0 */
  pageIndex = 0;

  /** 每頁呈現幾筆 預設為5 */
  pageSize = 5;

  /** 總頁數 */
  totalPage: number | undefined;

  /** 允許切換的每頁資料筆數 */
  pageSizeOptions = [5, 10];

  /** 分頁結果 */
  pageEvent: PageEvent | undefined;

  /** 初始員工列表全查 */
  queryEmail: string | undefined;

  displayedColumns: string[] = ['order', 'name', 'email', 'tel', 'sex', 'birthday', 'permissions', 'isQuit', 'action'];

  /** 表格資料 */
  dataSource: Emp[] = [];

  empArray: any[] = [];

  VOForm!: FormGroup;
  isEditableNew: boolean = true;

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    email: ['', [Validators.email]]
  });

  constructor(
    private fb: FormBuilder,
    private _formBuilder: FormBuilder,
    private empHttpService: EmpHttpService,
    private empPermissionsPipe: EmpPermissionsPipe,
    private empIsQuitPipe: EmpIsQuitPipe,
    public snackBar: MatSnackBar,
  ) { }

  /**
   * 取得「員工信箱」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpTestComponent
   */
  public get email(): FormControl<string | null> {
    return this.form.controls.email;
  }

  ngOnInit(): void {

    this.queryEmpData();


  }

  getPaginatorData(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    // this.queryPageDatabtn(this.pageIndex, this.pageSize);
  }

  queryEmpData() {
    this.queryEmail = this.form.value.email;
    this.empHttpService.queryEmpData(0, this.pageSize, this.queryEmail).subscribe({
      next: res => {
        const responseData = res;

        if (responseData.MWHEADER.RETURNCODE !== '0000') {
          this.snackBar.openFromComponent(SnackbarComponent, {
            data: {
              title: 'Fail',
              message: `查詢失敗 : ${responseData.MWHEADER.RETURNDESC}`,
            },
            panelClass: ['custom-style'],
            duration: 2000,
            verticalPosition: 'bottom',
            horizontalPosition: 'right',
          });
          return;
        }

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as Emp[];
        this.dataSource = this.dataSource.map<Emp>(e => ({
          ...e,
          permissions: this.empPermissionsPipe.transform(e.permissions),
          isQuit: this.empIsQuitPipe.transform(e.isQuit),
          order: 0
        }));

      },
      complete: () => {

        // 原生
        this.empArray = [
          ...this.dataSource,
        ].map(v => ({ ...v, isEdit: false }));

        // material
        this.VOForm = this._formBuilder.group({
          VORows: this._formBuilder.array([])
        });

        // this.VOForm.patchValue({
        //   VORows: this.fb.array(this.dataSource.map(val => this.fb.group({
        //     order: new FormControl(val.order),
        //     name: new FormControl(val.name),
        //     email: new FormControl(val.email),
        //     tel: new FormControl(val.tel),
        //     sex: new FormControl(val.sex),
        //     birthday: new FormControl(val.birthday),
        //     permissions: new FormControl(val.permissions),
        //     isQuit: new FormControl(val.isQuit),
        //     action: new FormControl('existingRecord'),
        //     isEditable: new FormControl(true),
        //     isNewRow: new FormControl(false),
        //   })
        //   ))
        // });
        // this.dataSource = new MatTableDataSource((this.VOForm.get('VORows') as FormArray).controls);
        console.log(this.VOForm);


      }

    });
  }

  // this function will enabled the select field for editd
  EditSVO(VOFormElement: any, i: any) {
    // VOFormElement.get('VORows').at(i).get('name').disabled(false)
    VOFormElement.get('VORows').at(i).get('isEditable').patchValue(false);
    // this.isEditableNew = true;

  }

  // On click of correct button in table (after click on edit) this method will call
  SaveVO(VOFormElement: any, i: any) {
    VOFormElement.get('VORows').at(i).get('isEditable').patchValue(true);
  }

  // On click of cancel button in the table (after click on edit) this method will call and reset the previous data
  CancelSVO(VOFormElement: any, i: any) {
    VOFormElement.get('VORows').at(i).get('isEditable').patchValue(true);
  }

  onEdit(item: any) {
    // debugger;
    this.empArray.forEach((element: any) => {
      element.isEdit = false;
    });
    item.isEdit = true;
  }
}
