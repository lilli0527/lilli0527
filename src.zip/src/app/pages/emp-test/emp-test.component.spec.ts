import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpTestComponent } from './emp-test.component';

describe('EmpTestComponent', () => {
  let component: EmpTestComponent;
  let fixture: ComponentFixture<EmpTestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmpTestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmpTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
