import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberOrderdetailUpdateComponent } from './member-orderdetail-update.component';

describe('MemberOrderdetailUpdateComponent', () => {
  let component: MemberOrderdetailUpdateComponent;
  let fixture: ComponentFixture<MemberOrderdetailUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MemberOrderdetailUpdateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MemberOrderdetailUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
