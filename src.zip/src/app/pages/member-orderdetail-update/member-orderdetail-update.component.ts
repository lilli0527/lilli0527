import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { typeArrInterface } from 'src/interface/commCodeMsgResponse';
import { OneOrderDetailRequest } from 'src/interface/oneOrderDetailRequest';
import { OnePetByCustomerRequest } from 'src/interface/onePetByCustomerRequest';
import { Tranr } from 'src/interface/onePetByCustomerResponse';
import { UpdateOrderDetailRequest } from 'src/interface/updateOrderDetailRequest';
import { MemberService } from 'src/service/member.service';

export interface DialogData {
  pageNumber: number,
  pageSize: number,
  orderId: string,
  itemId: string
}

@Component({
  selector: 'app-member-orderdetail-update',
  templateUrl: './member-orderdetail-update.component.html',
  styleUrls: ['./member-orderdetail-update.component.css']
})
export class MemberOrderdetailUpdateComponent implements OnInit {
  petArr: Tranr[] = []
  form = this.fb.nonNullable.group({
    serviceName: [{ value: '', disabled: true }],
    startDate: ['', Validators.required],
    endDate: ['', Validators.required],
    startTime: ['', Validators.required],
    petName: ['', Validators.required],
    type: [{ value: '', disabled: true }],
    remarks: [''],
    price: [{ value: '', disabled: true }]
  });
  disabled: boolean = true;
  constructor(public dialogRef: MatDialogRef<MemberOrderdetailUpdateComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData, private memberService: MemberService, private fb: FormBuilder) { }

  ngOnInit(): void {
    /** 進頁面先帶訂單編號查詢到的資料*/
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-ONEORDERDETAIL"
      },
      TRANRQ: {
        pageNumber: this.data.pageNumber,
        pageSize: this.data.pageSize,
        orderId: this.data.orderId,
        itemId: this.data.itemId
      }
    }
    console.log(request);

    this.memberService.oneOrderDetail(request as OneOrderDetailRequest).subscribe(
      response => {
        console.log(response);
        this.form.controls.serviceName.setValue(response.TRANRS.items[0].serviceName);
        console.log(response.TRANRS.items[0].startDate);
        const startDate = new Date(response.TRANRS.items[0].startDate);
        const endDate = new Date(response.TRANRS.items[0].endDate);
        const datePipe = new DatePipe('en-US');
        const formattedStartDate = datePipe.transform(startDate, 'yyyy-MM-dd');
        const formattedEndtDate = datePipe.transform(endDate, 'yyyy-MM-dd');
        this.form.controls.startDate.setValue(formattedStartDate as string);
        this.form.controls.endDate.setValue(formattedEndtDate as string);
        this.form.controls.startTime.setValue(response.TRANRS.items[0].startTime);
        this.form.controls.petName.setValue(response.TRANRS.items[0].petName);
        console.log(response.TRANRS.items[0].petType);

        this.form.controls.type.setValue(response.TRANRS.items[0].petType);
        this.form.controls.remarks.setValue(response.TRANRS.items[0].remarks);
        this.form.controls.price.setValue(response.TRANRS.items[0].price);


      })

       /** 會員寵物列表 */
    const request1 = {
      MWHEADER: {
        MSGID: "PAWSOME-ONEPETBYCUSTOMER"
      },
      TRANRQ: {
        custEmail: '123@gmail.com',
      }
    }
    this.memberService.onePetByCustomer(request1 as OnePetByCustomerRequest).subscribe(
      response => {
        console.log(response);
        this.petArr = response.TRANRS
      })










  }


  close() {
    this.dialogRef.close();
  }




}




// const request = {
//       MWHEADER: {
//         MSGID: "PAWSOME-UPDATEORDERDETAIL"
//       },
//       TRANRQ: {
//         orderId: "string",
//         itemId: "string",
//         startDate: "string",
//         endDate: "string",
//         startTime: "string",
//         petId: "string",
//         remarks: "string",
//         orderProcess: "string"
//       }
//     }
//     this.memberService.updateOrderDetail(request as UpdateOrderDetailRequest).subscribe(
//       response1 => {
//         console.log(response1);

//       })

















