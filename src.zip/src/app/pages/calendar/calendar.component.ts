import { Component, OnInit } from '@angular/core';
import { CalendarOptions } from '@fullcalendar/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import { ServiceEvent } from 'src/app/shared/interfaces/EmpElement';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css']
})
export class CalendarComponent implements OnInit {

  /** 行事曆設定 */
  calendarOptions: CalendarOptions = {
    plugins: [dayGridPlugin, timeGridPlugin, listPlugin],
    initialView: 'dayGridMonth',
    locale: 'zh-tw',
    navLinks: true,
    slotMinTime: '08:00',
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
    },
    buttonText: {
      today: '今日',
      month: '月',
      week: '週',
      day: '日',
      list: 'Agenda'
    },
    eventColor: "#f5c26b",
    events: []
  };

  /** 預約資訊 */
  seviceEvent: ServiceEvent[] = [];

  constructor(
    private empHttpService: EmpHttpService,
  ) { }

  ngOnInit(): void {
    this.queryCalendar();
  }

  /** 查詢所有預約 */
  queryCalendar() {
    this.empHttpService.queryCalendar().subscribe((res) => {
      const responseData = res;

      this.seviceEvent = responseData.TRANRS.map<ServiceEvent>((e) => ({
        title: `${e.serviceName} (${e.petName})`,
        start: `${e.startDate}T${e.startTime.split('-')[0]}`,
        end: e.endDate ? `${e.endDate}T${e.startTime.split('-')[1]}` : `${e.startDate}T${e.startTime.split('-')[1]}`,
      }));

      this.calendarOptions.events = this.seviceEvent;
    });

  }
}
