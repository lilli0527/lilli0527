import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { Emp } from 'src/app/shared/interfaces/EmpElement';
import { EmpIsQuitPipe } from 'src/app/shared/pipes/emp-is-quit.pipe';
import { EmpPermissionsPipe } from 'src/app/shared/pipes/emp-permissions.pipe';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import { MatDialog } from '@angular/material/dialog';
import { EmpEditComponent } from '../emp-edit/emp-edit.component';
import { EmpAddComponent } from '../emp-add/emp-add.component';
import { EmpDataService } from 'src/app/shared/service/emp-data.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css'],
  providers: [EmpPermissionsPipe, EmpIsQuitPipe],
})
export class EmpListComponent implements OnInit {
  /**
   * 分頁
   * @type {MatPaginator}
   * @memberof EmpListComponent
   */
  @ViewChild('paginator', { static: true }) paginator!: MatPaginator;

  /** 資料總筆數 */
  length = 0;

  /** 目前頁碼 預設為0 */
  pageIndex = 0;

  /** 每頁呈現幾筆 預設為5 */
  pageSize = 5;

  /** 總頁數 */
  totalPage: number | undefined;

  /** 允許切換的每頁資料筆數 */
  pageSizeOptions = [5, 10];

  /** 分頁結果 */
  pageEvent: PageEvent | undefined;

  /** 初始員工列表全查 */
  queryEmail: string | undefined;

  /** 欄位名稱 */
  displayedColumns = [
    'name',
    'email',
    'tel',
    'sex',
    'birthday',
    'permissions',
    'isQuit',
    'updateTime',
    'edit',
  ];

  /** 表格資料 */
  dataSource: Emp[] = [];

  /** 查無資料 */
  dataNotFound = false;

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    email: ['', [Validators.pattern(/^\S*$/)]],
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private empHttpService: EmpHttpService,
    private dataService: EmpDataService,
    private empPermissionsPipe: EmpPermissionsPipe,
    private empIsQuitPipe: EmpIsQuitPipe,
    public dialog: MatDialog,
  ) { }

  /**
   * 取得「員工信箱」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpListComponent
   */
  public get email(): FormControl<string | null> {
    return this.form.controls.email;
  }

  ngOnInit(): void {
    // console.log();

    if (sessionStorage.getItem('permission') !== '1') {
      // 若權限不足轉至員工首頁
      this.router.navigate(['/emp']);
    }
    this.queryEmpData();
  }

  /**
   * 分頁器
   * @param event
   */
  getPaginatorData(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.queryPageDatabtn(this.pageIndex, this.pageSize);
  }

  /** 初始查詢按鈕 */
  queryEmpData() {
    this.dataNotFound = false;
    this.pageIndex = 0;
    this.queryEmail = this.form.value.email;
    this.empHttpService
      .queryEmpData(0, this.pageSize, this.queryEmail)
      .subscribe((res) => {
        const responseData = res;

        if (responseData.MWHEADER.RETURNCODE !== '0000') {
          this.dataSource = [];
          this.dataNotFound = true;
          return;
        }

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as Emp[];
        this.dataSource = this.dataSource.map<Emp>((e) => ({
          ...e,
          permissions: this.empPermissionsPipe.transform(e.permissions),
          isQuit: this.empIsQuitPipe.transform(e.isQuit),
        }));
      });
  }

  /**
   * 分頁查詢按鈕
   * @param pageIndex
   * @param pageSize
   */
  queryPageDatabtn(pageIndex: number, pageSize: number) {
    this.dataNotFound = false;
    this.empHttpService
      .queryEmpData(pageIndex, pageSize, this.queryEmail)
      .subscribe((res) => {
        const responseData = res;

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as Emp[];
        this.dataSource = this.dataSource.map<Emp>((e) => ({
          ...e,
          permissions: this.empPermissionsPipe.transform(e.permissions),
          isQuit: this.empIsQuitPipe.transform(e.isQuit),
        }));
      });
  }

  /** 全查按鈕 */
  queryAllData() {
    this.dataNotFound = false;
    this.pageIndex = 0;
    this.form.patchValue({
      email: '',
    });

    this.empHttpService.queryEmpData(0, this.pageSize, '').subscribe((res) => {
      const responseData = res;

      if (responseData.MWHEADER.RETURNCODE !== '0000') {
        this.dataSource = [];
        this.dataNotFound = true;
        return;
      }

      this.length = responseData.TRANRS.totalCount;
      this.totalPage = responseData.TRANRS.totalPage;

      this.dataSource = responseData.TRANRS.items as Emp[];
      this.dataSource = this.dataSource.map<Emp>((e) => ({
        ...e,
        permissions: this.empPermissionsPipe.transform(e.permissions),
        isQuit: this.empIsQuitPipe.transform(e.isQuit),
        order: 0,
      }));
    });
  }

  /** 開啟新增彈窗 */
  openAddDialog() {
    const dialogRef = this.dialog.open(EmpAddComponent, {
      width: '55%',
    });
    this.queryEmpData();
  }

  /** 開啟修改彈窗 */
  openEditDialog(i: number) {
    // 將員工信箱資料存至 dataService
    this.dataService.empEmail = this.dataSource[i].email;

    const dialogRef = this.dialog.open(EmpEditComponent, {
      width: '55%',
    });

    dialogRef.afterClosed().subscribe(() => {
      this.queryEmail = '';
      this.queryPageDatabtn(this.pageIndex, this.pageSize);
    });
  }
}
