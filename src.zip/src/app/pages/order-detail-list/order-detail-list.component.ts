import { DatePipe } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { OrderDetail } from 'src/app/shared/interfaces/EmpElement';
import { EmpDataService } from 'src/app/shared/service/emp-data.service';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import Swal from 'sweetalert2';
import { OrderDetailEditComponent } from '../order-detail-edit/order-detail-edit.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-detail-list',
  templateUrl: './order-detail-list.component.html',
  styleUrls: ['./order-detail-list.component.css'],
  providers: [DatePipe],
})
export class OrderDetailListComponent implements OnInit {
  /** 取得訂單相關資訊 */
  @Input() getOrderInfo = {};

  /** 重新更新訂單資訊 */
  //TODO 全部更新  只查單筆?
  @Output() queryEvent = new EventEmitter<boolean>();

  /**
   * 分頁
   * @type {MatPaginator}
   * @memberof OrderListComponent
   */
  @ViewChild('paginator', { static: true }) paginator!: MatPaginator;

  /** 資料總筆數 */
  length = 0;

  /** 目前頁碼 預設為0 */
  pageIndex = 0;

  /** 每頁呈現幾筆 預設為5 */
  pageSize = 5;

  /** 總頁數 */
  totalPage: number | undefined;

  /** 允許切換的每頁資料筆數 */
  pageSizeOptions = [5, 10];

  /** 分頁結果 */
  pageEvent: PageEvent | undefined;

  /** 欲修改之訂單編號 */
  selectOrderId: string | undefined;

  /** 訂購日期 */
  selectOrderDate = '';

  /** 訂單狀態 */
  selectOrderProcess = '';

  /** 欲修改之會員信箱 */
  selectCustEmail: string | undefined;

  /** 會員姓名 */
  selectCustName = '';

  /** 會員電話 */
  selectCustTel = '';

  /** 欄位名稱 */
  displayedColumns = [
    'serviceName',
    'startDate',
    'endDate',
    'startTime',
    'petName',
    'petType',
    'remarks',
    'price',
    'orderProcess',
    'updateEmp',
    'updateTime',
    'edit',
  ];

  /** 表格資料 */
  dataSource: OrderDetail[] = [];

  constructor(
    private empHttpService: EmpHttpService,
    private dataService: EmpDataService,
    private datePipe: DatePipe,
    public dialog: MatDialog,
    public router: Router
  ) { }

  ngOnInit(): void {
    window.scrollTo(0, document.body.scrollHeight);

    // 訂單資訊
    this.selectOrderId = this.dataService.orderInfo.orderId as string;
    this.selectCustEmail = this.dataService.orderInfo.custEmail as string;
    this.empHttpService
      .queryOrderById(0, 1, this.selectOrderId)
      .subscribe((res) => {
        const responseData = res;
        this.selectOrderDate = this.datePipe.transform(
          responseData.TRANRS.items[0].confirmDate,
          'yyyy-MM-dd'
        ) as string;
        this.selectOrderProcess = responseData.TRANRS.items[0].orderProcess;
      });

    // 訂購人資訊
    this.empHttpService
      .queryCustByEmailData(0, 1, this.selectCustEmail)
      .subscribe((res) => {
        const responseData = res;
        this.selectCustName = responseData.TRANRS.items[0].name;
        this.selectCustTel = responseData.TRANRS.items[0].tel;
      });

    this.queryOrderDetail();
  }

  /**
   * 分頁器
   * @param event
   */
  getPaginatorData(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.queryPageDatabtn(this.pageIndex, this.pageSize);
  }

  /** 初始查詢按鈕 */
  queryOrderDetail() {
    this.pageIndex = 0;
    this.empHttpService
      .queryOrderDetail(0, this.pageSize, this.selectOrderId as string)
      .subscribe((res) => {
        const responseData = res;

        if (responseData.MWHEADER.RETURNCODE !== '0000') {
          Swal.fire({
            icon: 'error',
            title: '查詢失敗',
            text: responseData.MWHEADER.RETURNDESC,
            width: 350,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonText: '確定',
          });
          return;
        }

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as OrderDetail[];
        this.dataSource = this.dataSource.map<OrderDetail>((e) => ({
          ...e,
        }));
      });
  }

  /**
   * 分頁查詢按鈕
   * @param pageIndex
   * @param pageSize
   */
  queryPageDatabtn(pageIndex: number, pageSize: number) {
    this.empHttpService
      .queryOrderDetail(pageIndex, pageSize, this.selectOrderId as string)
      .subscribe((res) => {
        const responseData = res;

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as OrderDetail[];
        this.dataSource = this.dataSource.map<OrderDetail>((e) => ({
          ...e,
        }));
      });
  }

  /** 開啟修改彈窗 */
  openEditDialog(i: number) {
    this.dataService.orderDetailItemId = this.dataSource[i].itemId;
    const dialogRef = this.dialog.open(OrderDetailEditComponent, {
      width: '55%',
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.queryPageDatabtn(this.pageIndex, this.pageSize);
      this.queryEvent.emit();
    });
  }

  backToOrder() {
    this.router.navigate(['/orderList'])
  }
}
