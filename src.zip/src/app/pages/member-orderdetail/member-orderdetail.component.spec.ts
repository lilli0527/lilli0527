import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberOrderdetailComponent } from './member-orderdetail.component';

describe('MemberOrderdetailComponent', () => {
  let component: MemberOrderdetailComponent;
  let fixture: ComponentFixture<MemberOrderdetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MemberOrderdetailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MemberOrderdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
