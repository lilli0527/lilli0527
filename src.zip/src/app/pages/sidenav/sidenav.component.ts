import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from 'src/app/core/services/cart.service';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css'],
})
export class SidenavComponent implements OnInit {
  emploginstatus = true;
  countInCart = 0;
  isAdmin = false;

  constructor(private router: Router, private cartService: CartService) { }

  ngOnInit(): void {
    if (sessionStorage.getItem('permission') === '1') {
      this.isAdmin = true;
    }
    if (sessionStorage.getItem('nav') === 'emplogin') {
      this.emploginstatus = false;
    }
    this.cartService.countInCart$.subscribe((count: number) => {
      this.countInCart = count;
    });
  }

  emplogout() {
    if (sessionStorage) {
      sessionStorage.clear();
      this.router.navigate(['/']);
      this.emploginstatus = true;
    }
  }
}
