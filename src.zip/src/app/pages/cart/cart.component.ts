import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { EditShareTranrs } from 'src/app/core/interfaces/editShareTranrs.interface';
import { InsertOrderTranrqItems } from 'src/app/core/interfaces/insertOrder/insertOrderTranrqItems.interface';
import { InsertOrderTranrs } from 'src/app/core/interfaces/insertOrder/insertOrderTranrs.interface';
import { QueryCartTranrqItems } from 'src/app/core/interfaces/queryCart/queryCartTranrqItems.interface';
import { QueryCartTranrs } from 'src/app/core/interfaces/queryCart/queryCartTranrs.interface';
import { QueryCartTranrsItems } from 'src/app/core/interfaces/queryCart/queryCartTranrsItems.interface';
import { CartService } from 'src/app/core/services/cart.service';
import { OrderService } from 'src/app/core/services/order.service';
import { EditDialogComponent } from 'src/app/dialogs/edit/edit-dialog/edit-dialog.component';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {

  /** 會員信箱 */
  custEmail: string = '';
  /** 是否送單 購物車只顯示為n的服務 */
  isSubmit: string = 'n';
  /** 總金額 */
  totalPrice: number = 0;
  /** 各項服務總金額 */
  serviceTotalPrice: string = '';
  /** 訂單狀態 預設皆為已確認 = 1 */
  orderProcess: string = '1';
  /** 訂單確認日期 */
  confirmDate: Date = new Date();
  /** 轉換訂單確認日期為後端要求格式 */
  transformedDate: string | null = '';
  /** 所有checkbox狀態 */
  allChecked: boolean = false;
  /** 單個checkbox狀態 */
  isChecked: boolean = false;
  /** 購物車ID */
  itemId: string = '';
  /** 總筆數 */
  totalCount: number = 0;
  /** 訂單編號 */
  orderId: string = '111';
  /** checkbox選取的資料 */
  selectedItems: QueryCartTranrsItems[] = [];
  /** 當天日期 */
  today: Date = new Date();

  constructor(private cartService: CartService, private orderService: OrderService, private router: Router, private dialog: MatDialog, private datePipe: DatePipe, private currencyPipe: CurrencyPipe) { }

  /** TABLE欄位 */
  displayedColumns: string[] = [
    // 'index',
    'chooseItem',
    'serviceName',
    'startDate',
    'endDate',
    'startTime',
    'petName',
    'petType',
    'remarks',
    'serviceTotalPrice',
    'edit',
    'delete'
  ];

  /** 會員購物車列表 */
  dataSource: QueryCartTranrsItems[] = [];

  /**
   * 傳入會員信箱查詢購物車
   * 轉換confirmDate為中台要求格式進入訂單DB
   */
  ngOnInit(): void {
    window.scrollTo(0, 0);
    if (sessionStorage.length !== 0) {
      this.custEmail = sessionStorage.getItem('user')!;
      this.onQuery(this.custEmail);
    } else {
      this.router.navigate(['/login']);
    }
    this.transformedDate = this.datePipe.transform(this.confirmDate, 'yyyy-MM-dd');
  }

  /**
   * 購物車資料查詢服務
   * @param custEmail
   */
  onQuery(custEmail: string) {
    const input: QueryCartTranrqItems = {
      custEmail: custEmail,
      isSubmit: this.isSubmit
    };
    this.cartService.query(input).subscribe((rs: QueryCartTranrs) => {
      const returnCode = rs.MWHEADER.RETURNCODE;
      const tranrs = rs.TRANRS;
      this.dataSource = tranrs.items;
      this.totalCount = tranrs.totalCount;
      this.cartService.setCountInCart(this.totalCount);
      if (returnCode === '0000' && this.totalCount !== 0) {
      } else if (returnCode === 'E001' || sessionStorage.length === 0) {
        this.router.navigate(['/login']); // 必填欄位不完整(需登入/註冊)
      } else if (returnCode === 'E702' || rs.TRANRS.totalCount === 0) {
        // 購物車為空
      } else {
        Swal.fire({
          icon: 'warning',
          title: '其他系統異常',
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '再試試',
        });
      }
    });
  }

  /**
   * 將按鈕所在的該筆資料存入cartService
   * 呼叫EditDialog
   * @param item
   */
  onEdit(item: QueryCartTranrsItems) {
    this.cartService.setEditItem(item);
    this.dialog.open(EditDialogComponent);
  }

  /**
   * 購物車資料刪除服務
   * @param item
   */
  onDelete(item: QueryCartTranrsItems) {
    this.itemId = item.itemId;
    const inputItemId: string = this.itemId;
    Swal.fire({
      icon: 'warning',
      title: '請確認是否要移除這筆服務？',
      text: `服務名稱：${item.serviceName}
      預約日期時間： ${item.startDate} ${item.startTime}`,
      showCancelButton: true,
      confirmButtonText: '刪除',
      cancelButtonText: '取消',
      padding: '3em',
      background: '#fff',
    }).then((result) => {
      if (result.isConfirmed) {
        this.cartService.delete(inputItemId).subscribe((rs: EditShareTranrs) => {
          const returnCode = rs.MWHEADER.RETURNCODE;
          if (returnCode === '0000') {
            this.onQuery(this.custEmail);
          } else if (returnCode === 'E001') {
            Swal.fire({
              icon: 'warning',
              title: '必填欄位不得為空',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '確認',
            });
          } else if (returnCode === 'E702') {
            Swal.fire({
              icon: 'warning',
              title: '查無該筆購物車資料',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
            });
          } else if (returnCode === 'E004') {
            Swal.fire({
              icon: 'error',
              title: '刪除購物車失敗',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
            });
          } else {
            Swal.fire({
              icon: 'warning',
              title: '其他系統異常',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
            });
          }
        });
      }
    });
  }

  /**
   * 回上一頁
   */
  return() {
    history.back();
  }

  /**
   * 訂單資料新增服務
   */
  insertOrder() {
    const input: InsertOrderTranrqItems[] = this.selectedItems.map(item => {
      return {
        custEmail: this.custEmail,
        itemId: item.itemId,
        serviceTotalPrice: item.serviceTotalPrice,
        orderProcess: this.orderProcess,
        confirmDate: this.transformedDate
      }
    });
    this.orderService.insert(input).subscribe((rs: InsertOrderTranrs) => {
      const returnCode = rs.MWHEADER.RETURNCODE;
      this.orderId = rs.TRANRS.orderId;
      if (returnCode === '0000') {
        this.onQuery(this.custEmail);
        Swal.fire({
          icon: 'success',
          title: '訂單成立',
          text: `訂單編號： ${this.orderId}`,
          width: 350,
          padding: '3em',
          background: '#fff',
        }).then(() => this.router.navigate(['/member']));
      } else if (returnCode === 'E003') {
        Swal.fire({
          icon: 'error',
          title: '訂單送出失敗',
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '再試試',
        });
      } else {
        Swal.fire({
          icon: 'warning',
          title: '其他系統異常',
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '再試試',
        });
      }
    });
  }

  allOnChecked(allCheckbox: MatCheckboxChange) {
    if (allCheckbox.checked) {
      this.allChecked = true;
      this.isChecked = true;
      this.dataSource.map(selectedItem => {
        this.onChecked(allCheckbox, selectedItem);
      });
    } else {
      this.isChecked = false;
      this.selectedItems.length = 0;
      this.totalPrice = 0;
    }
  }

  /**
   * 監聽checkbox事件
   * @param checkedbox
   * @param item
   */
  onChecked(checkbox: MatCheckboxChange, item: QueryCartTranrsItems) {
    if (checkbox.checked) {
      const selectedStartDate = new Date(item.startDate);
      if (selectedStartDate > this.today) {
        const input: QueryCartTranrqItems = {
          custEmail: this.custEmail,
          isSubmit: 'y'
        };
        this.cartService.query(input).subscribe(rs => {
          rs.TRANRS.items.map(itemsInOrder => {
            if (item.serviceId === itemsInOrder.serviceId) {
              if (item.startDate === itemsInOrder.startDate) {
                if (item.endDate === null) {
                  if (item.startTime === itemsInOrder.startTime) {
                    Swal.fire({
                      icon: 'warning',
                      html: '請修改預約日期或預約時間</br>該日期之該時段已無空位',
                      padding: '3em',
                      color: '#5d3f0a',
                      background: '#fff',
                      confirmButtonText: '確認',
                    }).then(() => {
                      this.totalPrice = 0;
                      this.selectedItems.length = 0;
                      this.isChecked = false;
                      this.onQuery(this.custEmail);
                    });
                  }
                } else if (item.startDate < itemsInOrder.endDate) {
                  Swal.fire({
                    icon: 'warning',
                    html: '請修改預約日期或預約時間</br>該日期之該時段已無空位',
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '確認',
                  }).then(() => {
                    this.totalPrice = 0;
                    this.selectedItems.length = 0;
                    this.isChecked = false;
                    this.onQuery(this.custEmail);
                  });
                }
              }
            }
          });
          this.selectedItems.push(item);
          this.totalPrice += parseInt(item.serviceTotalPrice);
        });
      } else {
        Swal.fire({
          icon: 'warning',
          html: '請修改預約日期</br>預約日期不得小於今日',
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '確認',
        }).then(() => {
          this.totalPrice = 0;
          this.selectedItems.length = 0;
          this.isChecked = false;
          this.allChecked = false;
          this.onQuery(this.custEmail);
        });
      }
    } else {
      const index = this.selectedItems.findIndex(selectedItem => selectedItem.itemId === item.itemId);
      if (index !== -1) {
        this.selectedItems.splice(index, 1);
        this.totalPrice -= parseInt(item.serviceTotalPrice);
      }
    }
  }

}
