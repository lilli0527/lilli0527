import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QueryCartTranrqItems } from 'src/app/core/interfaces/queryCart/queryCartTranrqItems.interface';
import { QueryCartTranrs } from 'src/app/core/interfaces/queryCart/queryCartTranrs.interface';
import { CartService } from 'src/app/core/services/cart.service';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css'],
  animations: [
    trigger('fadeIn', [
      state('void', style({ opacity: 0, transform: 'translateY(-20px)' })),
      transition('void => *', [
        animate('1000ms ease-out', style({ opacity: 1, transform: 'translateY(0)' })),
      ]),
    ]),
  ],
})

export class MainComponent implements OnInit {
  responseData: any = {};

  custEmail: string = '';

  countInCart: number | string = 0;

  constructor(
    private router: Router,
    private loginService: LoginService,
    private cartService: CartService
  ) { }


  petnumber: string = '';
  cusnumber: string = '';
  oredernumber: string = '';

  ngOnInit(): void {
    //首頁數字
    this.loginService.petNumber().subscribe({
      next: (response) => {
        if (response) {
          this.responseData = response;
          this.petnumber = this.responseData.TRANRS.petNumber;
        } else {
          console.log('未收到數據');
        }
      },
      error: (err) => {
        console.log('err', err);
      }
    });

    this.loginService.cusNumber().subscribe({
      next: (response) => {
        if (response) {
          this.responseData = response;
          this.cusnumber = this.responseData.TRANRS.cusNumber;
        } else {
          console.log('未收到數據');
        }
      },
      error: (err) => {
        console.log('err', err);
      }
    });

    this.loginService.orderNumber().subscribe({
      next: (response) => {
        if (response) {
          this.responseData = response;
          this.oredernumber = this.responseData.TRANRS.orderNumber;
        } else {
          console.log('未收到數據');
        }
      },
      error: (err) => {
        console.log('err', err);
      }
    });

    if (sessionStorage.length !== 0) {
      this.custEmail = sessionStorage.getItem('user')!;
    }
    const input: QueryCartTranrqItems = {
      custEmail: this.custEmail,
      isSubmit: 'n'
    };
    this.cartService.query(input).subscribe((rs: QueryCartTranrs) => {
      const returnCode = rs.MWHEADER.RETURNCODE;
      if (returnCode === '0000') {
        this.countInCart = rs.TRANRS.totalCount;
        this.cartService.setCountInCart(this.countInCart);
      }
    });
  }

  redirectLogin() {
    this.router.navigate(['/login']);
  }
}





