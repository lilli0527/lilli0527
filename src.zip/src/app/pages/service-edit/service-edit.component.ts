import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-edit',
  templateUrl: './service-edit.component.html',
  styleUrls: ['./service-edit.component.css']
})
export class ServiceEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
