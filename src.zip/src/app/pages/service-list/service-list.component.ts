import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Service } from 'src/app/interfaces/service';
import { ProductsService } from 'src/app/services/products.service';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { SvcAvaliablePipe } from 'src/app/shared/pipes/svc-avaliable.pipe';
import { ServiceAddComponent } from '../service-add/service-add.component';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-service-list',
  templateUrl: './service-list.component.html',
  styleUrls: ['./service-list.component.css'],
  providers: [SvcAvaliablePipe]

})
export class ServiceListComponent implements OnInit {

  /**
     * 分頁
     * @type {MatPaginator}
     * @memberof EmpListComponent
     */
  @ViewChild('paginator', { static: true }) paginator!: MatPaginator;

  /** 目前頁碼 預設為0 */
  pageIndex = 0;

  /** 每頁呈現幾筆 預設為5 */
  pageSize = 5;

  /** 資料總筆數 */
  length = 0;

  /** 表格資料 */
  dataSource: Service[] = [];

  /** 允許切換的每頁資料筆數 */
  pageSizeOptions = [5, 10];

  /** 欄位名稱 */
  displayedColumns = [
    'number',
    'type',
    'name',
    'brief',
    'petType',
    'petSizeRange',
    'price',
    'isavaliable',
    'edit',
  ];

  /** 欲搜尋服務名稱 */
  queryServiceName = '';

  searchForm = this.fb.nonNullable.group({
    serviceName: ['', [Validators.required]]
  });
  SvcAvaliablePipe: any;

  constructor(private fb: FormBuilder, private productsService: ProductsService, public dialog: MatDialog, private svcAvaliablePipe: SvcAvaliablePipe) { }

  ngOnInit(): void {
    this.queryServiceByName();

  }

  // 搜尋框
  queryServiceByName() {
    this.pageIndex = 0;
    this.queryServiceName = this.searchForm.controls.serviceName.value;
    this.productsService.postServiceAllQuery(0, this.pageSize, this.queryServiceName).subscribe(response => {

      if (response.MWHEADER.RETURNCODE === '0000') {
        this.length = response.TRANRS.totalCount;
        this.dataSource = response.TRANRS.datas as Service[];
        this.dataSource = this.dataSource.map<Service>(e => ({
          ...e,
          isavaliable: this.svcAvaliablePipe.transform(e.isavaliable),
          number: 0
        })
        )
      } else if (response.MWHEADER.RETURNCODE === 'E702') {
        Swal.fire({
          icon: 'warning',
          title: '查無相關服務內容',
          html:
            '請重新搜尋',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        })
      } else {
        Swal.fire({
          icon: 'warning',
          title: '系統發生異常',
          html:
            '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        })
      }

    })
  }

  // 分頁器搜尋
  queryPageDatabtn(pageIndex: number, pageSize: number) {
    this.productsService.postServiceAllQuery(pageIndex, pageSize, this.queryServiceName).subscribe(response => {

      if (response.MWHEADER.RETURNCODE === '0000') {
        this.length = response.TRANRS.totalCount;
        this.dataSource = response.TRANRS.datas as Service[];
        this.dataSource = this.dataSource.map<Service>(e => ({
          ...e,
          isavaliable: this.svcAvaliablePipe.transform(e.isavaliable),
          number: pageIndex * pageSize
        })
        )
      } else if (response.MWHEADER.RETURNCODE === 'E702') {
        Swal.fire({
          icon: 'warning',
          title: '查無相關服務內容',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        })
      } else {
        Swal.fire({
          icon: 'warning',
          title: '系統發生異常',
          html:
            '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        })
      }

    })
  }

  openAddDialog() {
    const dialogRef = this.dialog.open(ServiceAddComponent, {
      width: '60%'
    });
    dialogRef.afterClosed().subscribe(result => {
      this.queryPageDatabtn(this.pageIndex, this.pageSize);
    })
  }

  openEditDialog(i: number) {
    const dialogRef = this.dialog.open(ServiceAddComponent, {
      width: '60%',
      data: this.dataSource[i]
    });
    dialogRef.afterClosed().subscribe(result => {
      this.queryPageDatabtn(this.pageIndex, this.pageSize);

    })
  }

  getPaginatorData(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.queryPageDatabtn(this.pageIndex, this.pageSize);
  }

  queryServiceAll() {
    this.searchForm.controls.serviceName.patchValue('');
    this.queryServiceByName();
    this.searchForm.reset();



  }

}
