import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { logindata } from 'src/app/core/interface/login';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-loginemp',
  templateUrl: './loginemp.component.html',
  styleUrls: ['./loginemp.component.css']
})
export class LoginempComponent implements OnInit {

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private loginService: LoginService,
  ) { }

  responseData: any = {};

  hide: boolean = true;

  form = this.fb.nonNullable.group({
    /**檢核必填*/
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.maxLength(15)]],
  });


  ngOnInit(): void {
  }
  text(){
    this.form.controls.email.patchValue('admin@gmail.com');
    this.form.controls.password.patchValue('admin123');
  }
  loginemp() {
    const data: logindata = {
      email: this.form.controls.email.value,
      password: this.form.controls.password.value
    };

    this.loginService.loginemp(data).subscribe({
      next: (response) => {
        console.log(response)
        if (response) {
          this.responseData = response;
          if (this.responseData.MWHEADER.RETURNCODE === 'E001') {
            Swal.fire({
              icon: 'error',
              title: '欄位格式錯誤',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
            })
          }
          if (this.responseData.MWHEADER.RETURNCODE === 'E702') {
            Swal.fire({
              icon: 'warning',
              title: '此帳號尚未開通',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '返回',
            })
          }
          if (this.responseData.MWHEADER.RETURNCODE === 'E005') {
            Swal.fire({
              icon: 'error',
              title: '密碼錯誤',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
            })
          }
          if (this.responseData.MWHEADER.RETURNCODE === '0000') {
            Swal.fire({
              icon: 'success',
              title: '登入成功',
              width: 350,
              padding: '3em',
              background: '#fff',
            })
            this.router.navigate(['/emp']);
            if(this.responseData.TRANRS.items[0].email){
              sessionStorage.setItem('empuser', this.responseData.TRANRS.items[0].email);
              sessionStorage.setItem('permission', this.responseData.TRANRS.items[0].permissions);
            }
            sessionStorage.setItem('nav', 'emplogin')
          }
        }
      },
      error: (err) => {
        console.log('err', err);
      }
    });
  }

  // 聯絡資訊彈跳視窗
  contact() {
    Swal.fire({
      icon:'info',
      title: '請聯絡客服人員',
      html: '聯絡資訊: 02-55662218</br>地址: 台北市內湖區瑞光路510號',
      width: 450,
      padding: '3em',
      color: '#5d3f0a',
      background: '#fff',
      // confirmButtonText: '再試試',
    })
  }

}
