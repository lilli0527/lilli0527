export interface DELETESERVICETranrq {
  MWHEADER: {
    MSGID: string;
  }
  TRANRQ: {
    serviceId: number;
  }
}
