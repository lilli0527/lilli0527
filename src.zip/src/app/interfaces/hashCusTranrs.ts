export interface HASHCUSTranrs {
  MWHEADER: {
    MSGID: string;
    RETURNCODE: string;
    RETURNDESC: string;
  }
  TRANRS: {
    email: string;
  }
}
