export interface Service {
  serviceId: number;
  type: string;
  name: string;
  brief: string;
  petType: string;
  petSizeRange: string;
  price: string;
  isavaliable: string;
}
