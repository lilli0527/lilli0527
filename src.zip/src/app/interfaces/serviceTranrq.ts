export interface ServiceTranrq {
  MWHEADER: {
    MSGID: string;
  }
  TRANRQ: {
    type: string;
  }
}
