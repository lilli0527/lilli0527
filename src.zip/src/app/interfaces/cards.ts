export interface Cards {
    imageUrl:string;
    name:string;
}
