export interface ServiceDetailTranrq {
  MWHEADER: {
    MSGID: string;
  }
  TRANRQ: {
    name: string |null;
  }
}
