export interface UpdateServiceTranrq {
  MWHEADER: {
    MSGID: string;
  }
  TRANRQ: {
    serviceId: number;
    type: string;
    name: string;
    brief: string;
    petType: string;
    petSizeRange: string;
    price: string;
    isavaliable: string;
  }
}
