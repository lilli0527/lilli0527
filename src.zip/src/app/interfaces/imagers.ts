export interface Imagers {
  MWHEADER: {
    MSGID: string;
    RETURNCODE: string;
    RETURNDESC: string;
  }
  TRANRS: string;
}
