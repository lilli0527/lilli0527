export interface OneServiceTranrq {
  MWHEADER: {
    MSGID: string;
  }
  TRANRQ: {
    name: string|null;
  }
}
