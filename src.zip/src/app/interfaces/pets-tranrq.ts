export interface PetsTranrq {
  MWHEADER: {
    MSGID: string;
  }
  TRANRQ: {
    custEmail: string |null;
  }
}
